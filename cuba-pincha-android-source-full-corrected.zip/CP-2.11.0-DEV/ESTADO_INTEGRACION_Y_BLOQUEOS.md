# CubaPincha — estado de integración DEV (2026-11-22)

## Alcance de esta continuación

Se modificó únicamente la fuente Android en DEV para corregir FCM en instalación limpia e integrar el contrato de valoraciones que el usuario confirmó aplicado en staging (SQL 006 y Edge v9). No se modificó ni se desplegó Supabase. Por instrucción expresa, no se compiló ni se generó APK; la build y las pruebas de dispositivo quedan para Muse en el PC del usuario.

## Cambios Android

- La fuente pasa a `versionName 2.11.0` / `versionCode 26`.
- `PushManager` inicializa Firebase desde los recursos del plugin Google Services, en vez de exigir valores escritos en preferencias/perfil. El `google-services.json` de DEV ya contiene la configuración de `com.cubapincha.job` y coincide con el JSON Firebase de referencia en los metadatos de app/proyecto; no fue necesario sustituirlo.
- El token FCM continúa registrándose al obtenerse y tras iniciar sesión. El estado de Perfil ya no depende de una clave pegada manualmente.
- Se añadieron modelos y operaciones `getRatings` (pública, sin enviar JWT) y `rateApplication` (autenticada, con JWT). La valoración nunca se encola offline y la app envía solo `applicationId`, `stars` y comentario opcional.
- Se añadió el diálogo **“Valora este trabajo”** para candidaturas `hired`, con 1–5 estrellas, comentario limitado a 1000 caracteres, comprobación paginada de una valoración previa y manejo de respuestas de conflicto.
- Perfil propio muestra promedio, estrellas, total y lista paginada. Los detalles de candidato y el nombre de la empresa en una oferta permiten consultar valoraciones públicas.
- El enlace de compartir de la fuente DEV ya construía la URL web canónica de GitHub Pages; no se cambió. No se inspeccionó el APK instalado, así que no se puede confirmar qué fuente/version contiene ese APK.
- `gradlew` quedó con modo ejecutable `755`.

## Límites y verificaciones pendientes

- La compilación Gradle, Android Lint, la instalación limpia, recepción real de FCM y pruebas en el Motorola no se ejecutaron.
- No se envió una valoración real ni se escribieron datos de usuario.
- No se verificó JDK 21 en la máquina Muse.
- La integración Java con Edge v9 se basa en la guía local de contrato y en el estado comunicado por el usuario; no se consultó ni modificó el servidor.
- Confirmar con Muse los recursos de `local.properties` para Supabase/OAuth y la versión de JDK; después compilar/instalar y validar, antes de distribuir.

La revisión estática más reciente parseó el manifiesto y 156 XML de recursos, sin errores; los tres layouts afectados no tienen IDs duplicados. Se confirmó el paquete del JSON Firebase, el enlace canónico en `ShareUtils`, el permiso `755` de `gradlew` y la ausencia de `local.properties` en la fuente. También se ocultaron los campos/contenedores heredados de conexión y FCM que todavía dejaban etiquetas visibles en Perfil. Ninguna de estas revisiones equivale a compilar o probar la app.

## Seguridad

No se incorporó ninguna `service_role`, contraseña, keystore ni token privilegiado al APK o a la fuente. Una `service_role` fue pegada en el chat; debe considerarse comprometida y rotarse coordinadamente con sus consumidores. No se intentó rotarla ni se contactó el servidor.
