# CubaPincha — fuente Android DEV 2.11.0

Fuente de trabajo Android actualizada a `versionName 2.11.0` y `versionCode 26`, con integración cliente de valoraciones y FCM desde Google Services. El backend ya estaba aplicado por el usuario y no se tocó.

Lee `ESTADO_INTEGRACION_Y_BLOQUEOS.md`, luego `codigo-fuente/BUILD_REPORT.md` y `codigo-fuente/TEST_LOG.md`.

No hay APK/AAB nuevo y no se compiló por instrucción del usuario. Muse debe confirmar JDK 21, configurar `codigo-fuente/local.properties` localmente, ejecutar la build y validar instalación, push, valoraciones y enlaces en el dispositivo. No incluir `service_role`, claves privadas ni contraseñas en Android.
