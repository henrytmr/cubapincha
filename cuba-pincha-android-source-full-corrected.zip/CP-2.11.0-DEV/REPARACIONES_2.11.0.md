# CubaPincha 2.11.0 — reparaciones realizadas

## Corregido

- Se eliminó en `RatingUi` la comparación incorrecta entre `SessionManager.getUserId()` (`usuarios.id`) y `Application.workerId/companyId` (IDs de perfil). La UI usa el rol para elegir el destinatario y el servidor autoriza la candidatura real.
- Se añadieron `getRatings` (público) y `rateApplication` (autenticado) al router y a la Edge Function. El servidor exige estado `hired`, comprueba pertenencia de la candidatura, deduce ambos perfiles, limita estrellas a 1–5, limita comentario a 1000 caracteres y devuelve `CONFLICT` para duplicados.
- Se añadió `backend/sql/006_valoraciones.sql` con tabla, índices, unicidad por candidatura/autor y RLS.
- Se reemplazó `CONTRACT.md`, que describía Apps Script/Firebase antiguo, por el contrato vigente Supabase Edge 2.0.0.
- Se corrigió `app/build.gradle`: una release sin keystore ya no bloquea la evaluación de `assembleDebug`; la firma de producción se activa solo si el keystore configurado existe.
- Se mantuvo `checkReleaseBuilds` activo; no se desactivó lint para ocultar errores.

## Validaciones

- JSON Firebase válido.
- Manifiesto XML válido; Activity, Service y Provider tienen `android:exported` explícito.
- No quedan comparaciones UID/perfil ni `checkReleaseBuilds false`.
- Acciones y contrato de ratings presentes y coherentes.
- Gradle 8.9 se descargó y comenzó correctamente, pero el entorno no tiene Android SDK (`SDK location not found`), por lo que no fue posible generar APK aquí.
- No se hizo una escritura real contra Supabase ni una prueba con teléfono físico; requieren credenciales/despliegue y dispositivo autorizados.
- La corrección de la contraseña del alias del keystore no puede hacerse desde el código fuente: requiere actualizar la entrada en el gestor de contraseñas con la contraseña real del alias.
