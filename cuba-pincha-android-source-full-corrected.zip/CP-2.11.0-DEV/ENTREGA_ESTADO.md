# Entrega CubaPincha — 22 noviembre 2026

Esta carpeta conserva la fuente Android DEV y ahora incluye la integración cliente de valoraciones y la corrección de inicialización FCM para instalación limpia. La fuente está versionada como 2.11.0 / versionCode 26.

**No contiene APK/AAB ni se compiló.** El usuario pidió que Muse realice la build en su PC. No se modificó ni desplegó Supabase: se respetó el estado comunicado de SQL 006 y Edge v9 ya aplicados.

Antes de distribuir, Muse debe confirmar JDK 21 y las propiedades locales, compilar, instalar desde cero, probar FCM con permiso Android, valorar una candidatura de prueba con cuentas autorizadas y revisar los perfiles/links. No se hizo una escritura real de valoraciones en esta sesión.

Consulta `ESTADO_INTEGRACION_Y_BLOQUEOS.md`, `codigo-fuente/BUILD_REPORT.md` y `codigo-fuente/TEST_LOG.md`. La credencial `service_role` compartida en el chat no se usó ni se incorporó; debe rotarse coordinadamente.
