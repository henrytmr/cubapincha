# Overlay de CubaPincha DEV 2.11.0 para Muse

Este paquete contiene solo los archivos Android/DEV modificados y la documentación de handoff. Para aplicarlo, descomprime el ZIP sobre la carpeta `DEV/src/` que contiene tu `CP-2.11.0-DEV` y permite reemplazar únicamente las rutas incluidas. Si ya hay cambios locales propios, guárdalos y compáralos antes de sobrescribir.

El overlay **no incluye** `google-services.json` (el existente ya coincide con la app objetivo), `local.properties`, claves o credenciales, keystore, archivos de firma, APK/AAB, cachés o build outputs. Conserva el JSON Firebase de referencia que ya está en tu fuente; no compartas la `service_role` ni la pongas en Android.

La fuente queda en 2.11.0 / versionCode 26, con FCM desde recursos Google Services y ratings cliente para el contrato Edge v9. El usuario confirma SQL 006 y Edge v9 aplicados; no repetir migración ni despliegue. `gradlew` debe quedar ejecutable (`755`).

No se compiló ni probó en teléfono. En Muse, confirma JDK 21 como Gradle JDK, configura `local.properties` de forma local, sincroniza Gradle, compila e instala desde cero. Prueba FCM y las pantallas de ratings con cuentas/datos de prueba autorizados. No escribir una valoración real de usuario sin autorización explícita.

Revisa `ESTADO_INTEGRACION_Y_BLOQUEOS.md`, `codigo-fuente/BUILD_SETUP.md`, `codigo-fuente/BUILD_REPORT.md`, `codigo-fuente/TEST_LOG.md` y `CREDENCIALES.md`. La credencial privilegiada que se pegó en el chat se considera comprometida y debe rotarse coordinadamente por sus consumidores server-side; esta sesión no la usó ni la rotó.
