# CubaPincha — custodia de credenciales (sin secretos)

Este archivo documenta **dónde deben vivir los secretos**, pero no contiene valores, tokens, contraseñas, huellas privadas ni datos de cuenta.

## Supabase

La clave `anon`/publicable es una credencial de cliente y puede estar en la configuración local de build; debe seguir limitada por RLS y por las reglas de la Edge Function. La `service_role` es privilegiada: jamás debe incluirse en Android, `BuildConfig`, `local.properties`, repositorios, APK/AAB o mensajes. El token privilegiado compartido en el chat debe considerarse comprometido y rotarse coordinadamente, actualizando únicamente sus consumidores server-side. Esta sesión no lo usó ni lo rotó y no modificó Supabase.

## Firebase y Google OAuth

`app/google-services.json` es configuración de cliente Android; no es una cuenta de servicio y no sustituye a una clave server-side. No copiar el JSON de cuenta de servicio Firebase a la app. El OAuth usado por la aplicación es el cliente web configurado localmente; no colocar secretos OAuth en Android.

## Firma y build local

El keystore de producción y sus contraseñas deben guardarse en un gestor de contraseñas y en una copia cifrada separada. No subirlos al repo ni pegarlos en el chat. Mantener `local.properties` fuera del control de versiones y completarlo únicamente en el PC de Muse a partir de `codigo-fuente/local.properties.example`. La disponibilidad de JDK 21 en ese PC aún debe confirmarse.

## Estado de esta entrega

No se han agregado credenciales al código Android ni a este documento. La fuente está actualizada a 2.11.0 / versionCode 26; la compilación y las pruebas de dispositivo quedan pendientes en Muse.
