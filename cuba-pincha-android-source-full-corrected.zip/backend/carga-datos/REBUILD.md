# CubaPincha — Rebuild completo de staging (fresco, con datos reales)

**Fecha:** 2026-11-21 · **Proyecto:** cubapincha-staging (`ogimwehtnhegfoamiwzm`)
**Método:** solo SQL Editor de Supabase, sin contraseña de base ni CLI.
**Origen de datos:** `work/migracion/csv/` (18 CSV, hoja principal
"CubaPincha DB", 303 filas). `reportes.csv` ya trae `abierto`
(corregido solo en el CSV, no en Sheets).

**Verificado en local (Postgres 17.4, base fresca UTF-8):**
`000 + 001 + 002 + 004a + 004b + 003` aplicados con **0 errores**;
19 tablas, **296 filas**, `v_ofertas_publicas` 12, **0 huérfanos**,
RLS en 19 tablas, 22 políticas. El reset (`000`) también se probó
sobre la base ya cargada: deja 0 tablas, vista y sesiones eliminadas.
Un matiz local: en el Postgres local no existe `auth.users`, así que
la 003 salta §2 (FK) y §3 (trigger) con NOTICE; en staging sí existen
y se comportan como se describe en el paso 5.

---

## Paso 0 — Antes de empezar (leer)

- Esto **borra todo** el esquema `public` de staging y lo vuelve a
  crear con los datos reales. Es solo para staging. Nunca en producción.
- **No toca** `auth` (los usuarios de Supabase Auth sobreviven),
  `storage` (el bucket privado `archivos` sobrevive) ni `extensions`.
- La carga es de **una sola vez**. No re-ejecutar `004a`/`004b`:
  `auditoria` no tiene clave única y se duplicaría (42 → 84).
  Si algo falla a mitad, volver al paso 1 (`000_reset.sql`).
- **No crear los 14 `auth.users` antes de cargar.** El trigger de la
  003 crearía primero su fila con otro `id` y la carga legada se
  saltaría por `email_hash` duplicado, rompiendo las FK de perfiles.
  Primero cargar, después crear usuarios (paso 6).

## Paso 1 — Reset (SQL Editor)

Pegar y ejecutar `work/rebuild/000_reset.sql` (2,4 KB).

- Borra el esquema `public` completo (`DROP SCHEMA public CASCADE`),
  lo recrea vacío y restaura los permisos estándar de Supabase
  (`postgres`, `anon`, `authenticated`, `service_role`).
- Borra los trabajos pg_cron de CubaPincha si existen.
- Verificación: la última consulta devuelve `public_existe` con
  `usuarios_ausente = true` (0 tablas en public).

## Paso 2 — Esquema (SQL Editor)

Pegar y ejecutar `work/supabase/001_esquema.sql` (28 KB).
Resultado esperado: `Success. No rows returned`, sin errores.
Crea las 20 tablas y la vista `v_ofertas_publicas`.

## Paso 3 — Seguridad y funciones (SQL Editor)

Pegar y ejecutar `work/supabase/002_seguridad_y_funciones.sql` (21 KB).
Resultado esperado: `Success. No rows returned`, sin errores.
Activa RLS en las 20 tablas, crea las 22 políticas y las funciones
(`expresar_interes`, `consumir_limite`, `expirar_ofertas`, etc.).

## Paso 4 — Carga de datos (SQL Editor, dos archivos, en orden)

Pegar y ejecutar `work/rebuild/004a_carga_datos.sql` (46 KB, 212 INSERTs):
provincias (16), municipios (168), usuarios (14), perfiles_trabajador
(5), perfiles_empresa (9).

Pegar y ejecutar `work/rebuild/004b_carga_datos.sql` (43 KB, 84 INSERTs):
ofertas (12), postulaciones (4), ofertas_guardadas (4), notificaciones
(4), dispositivos_fcm (6), reportes (1), configuracion (11),
auditoria (42).

- Los INSERTs usan la **misma lógica** que
  `migrar_sheets_a_supabase.py :: transformar()` (mismo mapeo de
  columnas, mismos uuid5 deterministas para IDs legados no-UUID,
  mismos defaults de enums) y `ON CONFLICT DO NOTHING` donde el
  script lo usa. `auditoria` lleva INSERT simple, sin `ON CONFLICT`
  (no tiene clave única: correrla una sola vez).
- Las pestañas vacías en origen (filtros_guardados,
  candidatos_guardados, contacto_preferencias,
  acciones_sincronizacion, archivos, sesiones) no tienen INSERTs.
  `sesiones` no se migra por diseño: esos usuarios vuelven a
  iniciar sesión en el corte.
- La última consulta de `004b` devuelve los conteos. Esperado:
  provincias 16, municipios 168, usuarios 14, perfiles_trabajador 5,
  perfiles_empresa 9, ofertas 12, postulaciones 4, ofertas_guardadas 4,
  notificaciones 4, dispositivos_fcm 6, reportes 1, configuracion 11,
  auditoria 42, `v_ofertas_publicas` 12. Total: **296 filas**.

## Paso 5 — Identidad (SQL Editor)

Pegar y ejecutar `work/supabase/003_identidad.sql` (20 KB).
Resultado esperado: `Success. No rows returned`, sin errores.

- §1 recrea las 12 FK a `usuarios(id)` con `ON UPDATE CASCADE`.
- §2 **se salta la FK** `fk_usuarios_id_auth_users` con NOTICE
  (hay 14 filas legadas con id fuera de `auth.users` — es lo
  esperado, no es un error).
- §3 crea el trigger `on_auth_user_created` en `auth.users`.
- §4/§5/§6: `consumir_limite()` con bloqueo consultivo (S-04),
  `expresar_interes()` con empresa activa y anti-auto-postulación
  (S-05), `expirar_ofertas()` solo service_role (S-06).
- §7 borra `sesiones` y sus helpers (ya no existe tras el reset,
  así que no hace nada en el rebuild).
- Verificación (§8 del archivo): **19 tablas** en public,
  `fk_usuarios_id_auth_users = 0` todavía, trigger
  `on_auth_user_created = 1`, `sesiones` no existe.

## Paso 6 — Crear los 14 usuarios en Auth (después de cargar)

Crear los 14 `auth.users` por Admin API con `email_confirm=true`
(usuarios migrados, ya usaban el producto) o por enlace mágico
por usuario. El trigger `handle_new_user` re-apunta cada fila
legada a su `auth.uid()` por `email_hash`; perfiles, ofertas y
demás siguen por `ON UPDATE CASCADE`. Las contraseñas de Firebase
no se pueden exportar: cada usuario pone contraseña nueva
(por restablecimiento o enlace mágico).

## Paso 7 — Re-ejecutar la 003 (SQL Editor)

Volver a pegar y ejecutar `work/supabase/003_identidad.sql`
(es re-ejecutable). Ahora §2 **sí crea**
`fk_usuarios_id_auth_users` (0 huérfanas). Verificación:
19 tablas, FK = 1, trigger = 1, `sesiones` no existe.

## Paso 7b — Permisos de service_role (005, obligatorio tras el rebuild)

El `DROP SCHEMA public CASCADE` del paso 1 destruyó los privilegios
por defecto de Supabase: `service_role` quedó sin GRANT sobre las
tablas y la Edge Function falla con `permission denied for table`
aunque bypasee RLS. Ejecutar `work/supabase/005_permisos_service_role.sql`
(una sola vez, idempotente). Verificación: `service_role` con SELECT
en las 20 relaciones de public.

## Paso 8 — Verificación final

- Tablas: 19 en public, todas con los conteos del paso 4.
- `SELECT count(*) FROM v_ofertas_publicas;` → 12.
- Crear un usuario de prueba en Auth y comprobar que aparece
  su fila en `public.usuarios` (status `incomplete`).
- RLS: `anon` ve ofertas publicadas y catálogo, 0 filas de
  `usuarios`; un usuario autenticado ve solo sus filas.
- Contrato T01–T20 (ver `work/edge-function-2.10.0/README.md`).

## Después del rebuild

1. Desplegar la Edge Function (`work/edge-function-2.10.0/index.ts`,
   34/34 acciones, `deno check` OK). Secretos por nombre:
   `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
   (los pone Supabase), `ALLOWED_ORIGIN` (obligatorio),
   `FCM_SERVICE_ACCOUNT` (opcional, solo push),
   `CRON_SECRET` (opcional, resumen diario).
2. Activar Google en Auth › Providers (cliente OAuth Android en
   Google Cloud con la huella SHA-1 de producción
   `0D:C9:E9:A4:2A:BB:12:17:69:9F:55:3F:98:DF:D1:96:DD:63:6D:C5`).
3. Programar pg_cron: `expirar-ofertas-cada-hora`,
   `purga-limites-03-35` (ver 002; `purga-sesiones` ya no existe).
4. Compilar la app 2.10.0 y probarla en el teléfono real
   (ver `work/CONNECT_APP.md`).

## Archivos

| Archivo | Tamaño | Contenido |
|---|---|---|
| `work/rebuild/000_reset.sql` | 2,4 KB | Reset destructivo de `public` (staging solo) |
| `work/rebuild/004a_carga_datos.sql` | 46 KB | 212 INSERTs: catálogo, usuarios, perfiles |
| `work/rebuild/004b_carga_datos.sql` | 43 KB | 84 INSERTs: ofertas, postulaciones, resto + verificación |
| `work/rebuild/REBUILD.md` | este archivo | Pasos para staging |
| `work/supabase/001_esquema.sql` | 28 KB | Esquema (ya existía) |
| `work/supabase/002_seguridad_y_funciones.sql` | 21 KB | RLS + funciones (ya existía) |
| `work/supabase/003_identidad.sql` | 20 KB | Identidad Supabase Auth (ya existía) |
