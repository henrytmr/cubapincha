# CubaPincha — Carga de datos reales en staging

**CORRECCIÓN 2026-11-21 22:24:** la 003 **sí** se aplicó en staging
después de escribir este documento (sin errores, 19 tablas, FK
`fk_usuarios_id_auth_users` creada, trigger creado). Por eso el orden
del §5 cambia para staging: **antes de cargar, hay que quitar la FK**
(`ALTER TABLE usuarios DROP CONSTRAINT fk_usuarios_id_auth_users;`),
cargar, crear los 14 `auth.users`, y re-ejecutar 003 para que la FK
vuelva a crearse. No cargar con la FK puesta: fallaría por violación
de FK con los 14 IDs legados.

**Fecha:** 2026-11-21 · **Origen:** `work/migracion/csv/` (18 CSV, hoja
principal "CubaPincha DB", 303 filas de datos). **Verificado en local
(Postgres 17.4), sin tocar staging.** La carga en staging está pendiente
de la contraseña de la base (por vía segura).

## 1. Dry-run (transformación, sin base de datos)

```bash
python migrar_sheets_a_supabase.py \
  --csv-dir ~/workspace/CubPincha/work/migracion/csv/ \
  --informe /tmp/informe_dryrun_transform.json --dry-run
```

Resultado (exit 0): **296 filas leídas, 296 preparadas, 0 incidencias.**
provincias 16, municipios 168, usuarios 14, perfiles_trabajador 5,
perfiles_empresa 9, ofertas 12, postulaciones 4, ofertas_guardadas 4,
notificaciones 4, dispositivos_fcm 6, reportes 1, configuracion 11,
auditoria 42. `reportes.csv` ya trae `abierto` (corregido solo en el
CSV, no en Sheets) — el bloqueo §5.1 de `REPORTE_CSV.md` queda resuelto
para la carga.

## 2. Dry-run real + carga local (Postgres 17.4, base fresca)

Base local `cubapincha_load` (UTF8): setup de roles + `auth.uid()` stub,
luego 001 (53 stmts) + 002 (89) + 003 (22), **0 errores**. 003 en local
se salta §2 y §3 con NOTICE (`auth.users` no existe) y deja 19 tablas
(`sesiones` borrada).

Dry-run con DSN local (rollback al final): las 296 filas se insertan
(0 `ya_existian`), transacción revertida, exit 0.

Carga real local (commit): **296/296 insertadas, 0 `ya_existian`,
0 incidencias, exit 0.**

Conteos verificados tras la carga:

| Tabla | Filas | Detalle |
|---|---|---|
| provincias | 16 | |
| municipios | 168 | |
| usuarios | 14 | 9 company/active, 5 worker/incomplete |
| perfiles_trabajador | 5 | |
| perfiles_empresa | 9 | |
| ofertas | 12 | 12 published, 12 sin `expires_at` |
| postulaciones | 4 | |
| ofertas_guardadas | 4 | |
| notificaciones | 4 | |
| dispositivos_fcm | 6 | |
| reportes | 1 | status `abierto` |
| configuracion | 11 | |
| auditoria | 42 | |
| v_ofertas_publicas | 12 | las 12 ofertas publicadas visibles |

Integridad: **0 huérfanos** en perfiles_trabajador, perfiles_empresa,
ofertas→empresa, postulaciones→oferta/trabajador y reportes→usuario.
`usuarios.id` nunca NULL. Tablas en public: 19 (`sesiones` no existe).

Re-ejecución del script (idempotencia): todas las tablas 0 insertadas /
todo `ya_existian`, **salvo `auditoria`, que duplicó 42 → 84 filas**
(ver §4). Usuarios y ofertas siguen en 14 y 12.

Prueba del trigger `handle_new_user` (stub `auth.users` creado en
local): un `auth.users` nuevo crea su fila en `public.usuarios`
(`company`, `incomplete`, correo enmascarado) y deja intactos los 14
legados. Prueba de re-apunte: `UPDATE usuarios SET id = <nuevo>` en
una empresa re-apunta su `perfiles_empresa` y su `ofertas.created_by`
por `ON UPDATE CASCADE`, sin cambiar ningún conteo.

## 3. ¿El script funciona tal cual tras 003? Sí, sin parche.

El script **sí suministra `usuarios.id` explícitamente**
(`uid()` en `transformar()`: UUID tal cual, o uuid5 determinista
con namespace fijo para IDs no UUID). No depende del DEFAULT que
003 quita. **No hace falta ningún parche en el script.**

Lo que sí manda es el **orden** (§5). El script no hay que tocarlo;
el orden de operaciones en staging es lo crítico.

## 4. Advertencias (leer antes de cargar en staging)

1. **La carga es de una sola vez. No re-ejecutar el script.**
   `auditoria` no tiene clave única: cada re-ejecución duplica
   sus 42 filas (verificado: 42 → 84). Si tras el re-apunte a
   `auth.uid()` se re-ejecutara, además fallaría por FK (los
   perfiles apuntarían a IDs legados que ya no existen).
2. **No crear los `auth.users` antes de cargar.** Si el trigger
   `handle_new_user` crea primero la fila de un usuario (con su
   `auth.uid()`), el script después inserta la fila legada con
   otro `id` y el mismo `email_hash`: el `ON CONFLICT DO NOTHING`
   la salta por el UNIQUE de `email_hash`, y los perfiles que
   apuntan al ID legado fallan por FK. Cargar primero, crear
   usuarios después.
3. **No aplicar 003 antes de cargar.** En staging `auth.users`
   existe y `usuarios` está vacío: §2 de 003 vería 0 huérfanas y
   **crearía la FK `fk_usuarios_id_auth_users`**, y la carga
   fallaría por violación de FK al insertar los 14 usuarios
   legados (sus IDs no están en `auth.users`). En local no pasó
   porque no había `auth.users` y §2 se saltó. Este es el orden
   correcto (§5).
4. Las 7 filas de `sesiones` no se migran por diseño; esos
   usuarios vuelven a iniciar sesión en el corte.
5. `firebase_uid` queda NULL en los 14 (el script lo pone así);
   la vinculación es por `email_hash` en el primer login.

## 5. Orden de operaciones en staging (no cambiarlo)

Estado actual de staging: 001+002 aplicados, 20 tablas, 0 filas,
bucket `archivos` privado. **003 todavía NO aplicado.**

```bash
# 0. Contraseña de la base por vía segura (nunca en el chat).
#    La URL es: postgresql://postgres:<PASSWORD>@db.ogimwehtnhegfoamiwzm.supabase.co:5432/postgres
export SUPABASE_DB_URL='postgresql://postgres:<PASSWORD>@db.ogimwehtnhegfoamiwzm.supabase.co:5432/postgres'

# 1. CARGAR PRIMERO, con 003 todavía sin aplicar.
cd ~/workspace/CubPincha/extracted/cubapincha-supabase/migracion
python migrar_sheets_a_supabase.py \
  --csv-dir ~/workspace/CubPincha/work/migracion/csv/ \
  --informe informe_migracion.json --dry-run
#    Esperado: 296 preparadas, 0 incidencias, todo insertable, rollback.
python migrar_sheets_a_supabase.py \
  --csv-dir ~/workspace/CubPincha/work/migracion/csv/ \
  --informe informe_migracion.json
#    Esperado: 296/296 insertadas, 0 ya_existian. Verificar conteos
#    (14 usuarios, 12 ofertas published, v_ofertas_publicas = 12).

# 2. APLICAR 003 (SQL Editor de Supabase o psql -f 003_identidad.sql).
#    §1 recrea las FK con ON UPDATE CASCADE; §2 se salta la FK a
#    auth.users con NOTICE (14 huérfanas, correcto); §3 crea el
#    trigger on_auth_user_created; §7 borra sesiones; S-04/S-05/S-06.

# 3. CREAR LOS 14 auth.users (Admin API con email_confirm=true para
#    los migrados, o enlace mágico por usuario). El trigger re-apunta
#    cada fila legada a su auth.uid() por email_hash; los perfiles,
#    ofertas y demás siguen por ON UPDATE CASCADE.

# 4. RE-EJECUTAR 003. Ahora §2 crea fk_usuarios_id_auth_users
#    (0 huérfanas). Verificar según §8 de 003_identidad.sql:
#    19 tablas, FK presente, trigger presente, RLS vivo, T13.

# 5. Después: desplegar la Edge Function, activar Google Auth,
#    programar pg_cron, probar contrato T01–T20.
```

## 6. Archivos

- Script (original, sin modificar):
  `extracted/cubapincha-supabase/migracion/migrar_sheets_a_supabase.py`
- CSVs: `work/migracion/csv/` (18 archivos + `REPORTE_CSV.md`)
- SQL: `work/supabase/001_esquema.sql`, `002_seguridad_y_funciones.sql`,
  `003_identidad.sql`
- Informes locales (en `/tmp`, no se guardan): `informe_dryrun_transform.json`,
  `informe_dryrun_db.json`, `informe_carga_local.json`, `informe_rerun.json`
