# CubaPincha — Exportación CSV de "CubaPincha DB" para la migración a Supabase

**Fecha de exportación:** 2026-11-20, 22:19 (America/Havana). Solo lectura en
Sheets: no se escribió, editó ni borró nada en la hoja.
**Hoja origen:** "CubaPincha DB" — `11BsGkkK6IBFHlNHKrFKdcAJCwjcqdLZGjUI6K2tu-Vo`
(la principal, **no** la copia staging).
**Carpeta:** `~/workspace/CubPincha/work/migracion/csv/` — un CSV por pestaña,
nombre exacto de la pestaña, UTF-8, primera fila = cabecera de la hoja,
valores tal cual, sin inventar columnas ni traducir valores.
**Script de referencia:** `cubapincha-supabase/migracion/migrar_sheets_a_supabase.py`
(`transformar()` + `ORDEN` de 17 tablas).

**Privacidad:** este informe contiene solo conteos y nombres de columna.
No incluye nombres, correos, teléfonos, tokens, hashes ni contenidos de filas.

## 1. Resultado: 18 CSV, 303 filas de datos

| CSV | Filas | Columnas | Lo lee el script |
|---|---|---|---|
| catalogos.csv | 184 | 7 | Sí (→ 16 provincias + 168 municipios) |
| usuarios.csv | 14 | 12 | Sí |
| perfiles_trabajador.csv | 5 | 27 | Sí |
| perfiles_empresa.csv | 9 | 23 | Sí |
| ofertas.csv | 12 | 35 | Sí |
| postulaciones_intereses.csv | 4 | 12 | Sí |
| filtros_guardados.csv | 0 (solo cabecera) | 9 | Sí |
| ofertas_guardadas.csv | 4 | 7 | Sí |
| candidatos_guardados.csv | 0 (solo cabecera) | 7 | Sí |
| acciones_sincronizacion.csv | 0 (solo cabecera) | 8 | Sí |
| contacto_preferencias.csv | 0 (solo cabecera) | 6 | Sí |
| notificaciones.csv | 4 | 11 | Sí |
| dispositivos_fcm.csv | 6 | 8 | Sí |
| archivos.csv | 0 (solo cabecera) | 8 | No (respaldo; el script no lo migra) |
| reportes.csv | 1 | 8 | Sí |
| auditoria.csv | 42 | 9 | Sí |
| configuracion.csv | 11 | 5 | Sí |
| sesiones.csv | 7 | 5 | No (respaldo; el script no las migra) |
| **Total** | **303** | — | **296 filas que lee el script** |

## 2. Dry-run con el script (`transformar()`, sin base de datos)

- Filas leídas por el script: 296 (las 303 menos las 7 de `sesiones`, que no
  migra; `archivos` tiene 0 filas).
- Filas preparadas: **296 de 296** (provincias 16, municipios 168, usuarios 14,
  perfiles_trabajador 5, perfiles_empresa 9, ofertas 12, postulaciones 4,
  filtros_guardados 0, ofertas_guardadas 4, candidatos_guardados 0,
  contacto_preferencias 0, acciones_sincronizacion 0, notificaciones 4,
  dispositivos_fcm 6, reportes 1, configuracion 11, auditoria 42).
- **Incidencias: 0.** Ninguna fila se omite ni se corrige en el dry-run.

## 3. Novedad frente a SHEETS_ESTUDIO.md (2026-11-20 21:35)

La hoja viva **ha cambiado** desde el estudio: alguien añadió las columnas
que faltaban, con valores reales.

- **Ofertas: las 9 columnas que faltaban ya existen** (35 columnas en total).
  `includesFood`, `includesTransport`, `includesAccommodation`,
  `includesTips` y `contactHours` tienen valor en 12/12 filas;
  `paymentNotes` en 5/12; `startDate` en 12/12 (todas con la misma fecha);
  `archivedAt` y `archiveReason` vacías en 12/12 (correcto: ninguna oferta
  está archivada). El desajuste §3.1 del estudio **queda resuelto**.
- **Perfiles_trabajador: `contactPreference` ya existe** (27 columnas).
  Tiene valor en 2/5 filas (`whatsapp`); vacía en 3/5, que migrarán con
  `contact_preference = NULL`. El desajuste §3.2 del estudio **queda
  resuelto** como columna; queda por decidir si esos 3 trabajadores llevan
  un valor por defecto (ver §5).

## 4. Comparación de columnas por pestaña (script vs. CSV exportado)

El script lee cada columna con `r.get(...)`: si falta, aplica su valor por
defecto en silencio; si sobra, la ignora. Resultado por pestaña:

| Pestaña | Columnas que el script espera y **faltan** | Columnas del CSV que el script **ignora** |
|---|---|---|
| catalogos | — | `updatedAt` |
| usuarios | — | `authProvider`, `firebaseUid` |
| perfiles_trabajador | — | `cvFileId`, `provinceName`, `municipalityName` |
| perfiles_empresa | — | `logoFileId`, `provinceName`, `municipalityName` |
| ofertas | — | `countryCode`, `provinceName`, `municipalityName` |
| postulaciones_intereses | — | `dedupeKey` |
| filtros_guardados | — | — |
| ofertas_guardadas | — | `ownerType` |
| candidatos_guardados | — | — |
| acciones_sincronizacion | — | — |
| contacto_preferencias | — | — |
| notificaciones | — | — |
| dispositivos_fcm | — | — |
| archivos | (no la lee el script) | (toda la pestaña) |
| reportes | — | — |
| auditoria | — | `auditId`, `ipHash` |
| configuracion | — | — |
| sesiones | (no la lee el script) | (toda la pestaña) |

**Ninguna columna esperada falta en ningún CSV.** Las columnas ignoradas
son pérdida nula hoy: `cvFileId` y `logoFileId` están vacíos en todas las
filas, `ipHash` vacío en las 42 filas de auditoría, y el resto son valores
redundantes o derivables (`provinceName`, `municipalityName`, `countryCode`,
`updatedAt`). Excepción: `firebaseUid` solo está presente en 3/14 usuarios;
el script pone `firebase_uid = NULL` para todos y lo vincula en el primer
login por `email_hash` (ver §5).

## 5. Desajustes que quedan (solo 1 bloqueante)

### 5.1 BLOQUEANTE — reportes.status = `open` (1 fila)

El único reporte tiene `status` = `open` (inglés). El script solo admite
`abierto | en_revision | resuelto | descartado` y, al no reconocerlo, aplica
su valor por defecto `abierto`. El resultado final es correcto por casualidad,
pero es un cambio silencioso: hay que hacerlo explícito antes de cargar.

**Arreglo (elegir uno):**
1. Cambiar el valor a `abierto` en la hoja (pestaña `reportes`) y
   re-exportar `reportes.csv`; o
2. Cambiar el valor a `abierto` solo en `reportes.csv`; o
3. Añadir el mapeo `open -> abierto` en `migrar_sheets_a_supabase.py`
   antes de la carga.

### 5.2 No bloqueantes (decidir antes de cargar, no impiden el dry-run)

1. **`firebaseUid` solo en 3/14 usuarios.** El script pone
   `firebase_uid = NULL` en todos. Antes del corte, confirmar que el
   `email_hash` se calcula igual en `Code.gs` que en el script, o 11
   usuarios no podrán vincular su cuenta en el primer login.
2. **`contactPreference` vacío en 3/5 trabajadores.** Migrarán con
   `contact_preference = NULL`. Decidir si se les pone un valor por
   defecto en la hoja (p. ej. `whatsapp`) o se acepta NULL.
3. **Trabajadores `incomplete` (5/5) y empresas `active` (9/9).**
   Verificar que `incomplete` no bloquee el login nuevo (el perfil se
   completa después de entrar, no en la puerta).
4. **`expiresAt` vacío en 12/12 ofertas.** Ninguna oferta caduca; el
   cron `expirar_ofertas` no tendrá nada que hacer hasta que se pueble.
5. **`sentAt` y `readAt` vacíos en 4/4 notificaciones.** El backend viejo
   nunca puebla esos campos; la lógica nueva debe decidir si los empieza
   a poblar o los ignora.
6. **Ubicación de trabajadores: `provinceCode` en 2/5, `city` en 0/5.**
   El matching por ubicación no encontrará a esos perfiles hasta que
   completen su ubicación.
7. **Pestañas vacías:** `filtros_guardados`, `candidatos_guardados`,
   `acciones_sincronizacion`, `contacto_preferencias` y `archivos`
   migran vacías. La Edge Function debe tratar la ausencia de
   `contacto_preferencias` como `in_app_first`.
8. **Sesiones (7 filas): no se migran por diseño.** Al cortar, esos
   usuarios vuelven a iniciar sesión. Avisarlo en el corte.
9. **Dispositivos FCM:** versión de app `2.9.0` en 5/6 y `2.9.2` en 1/6.

## 6. Flujo recomendado antes de cargar en staging

```bash
# 1. Resolver §5.1 (cambiar open -> abierto) y re-exportar reportes.csv si se
#    corrige en la hoja. Para el resto de §5.2, decidir y anotar la decisión.
# 2. Dry-run del script (solo transforma, sin cargar):
python migrar_sheets_a_supabase.py --csv-dir ~/workspace/CubPincha/work/migracion/csv/ \
    --informe informe_migracion.json --dry-run
#    Esperado: 296 preparadas, 0 incidencias (después de resolver §5.1).
# 3. Aplicar solo cuando el dry-run dé 0 incidencias inesperadas:
#    export SUPABASE_DB_URL='postgresql://postgres:***@db.ogimwehtnhegfoamiwzm.supabase.co:5432/postgres'
#    python migrar_sheets_a_supabase.py --csv-dir ~/workspace/CubPincha/work/migracion/csv/ \
#        --informe informe_migracion.json
#    (La contraseña de la base NO va en el chat; por vía segura.)
```

**No se ha cargado nada en Supabase en esta tarea.** Los CSV están listos
en `~/workspace/CubPincha/work/migracion/csv/`; falta solo resolver §5.1
y correr el dry-run y la carga con la contraseña de la base.
