-- ============================================================================
-- CubaPincha · 004a_carga_datos.sql — carga de datos reales (rebuild staging)
-- Generado desde work/migracion/csv/ con la MISMA lógica que
-- migrar_sheets_a_supabase.py :: transformar() (mismo mapeo de columnas,
-- mismos uuid5 para IDs legados no-UUID, mismos defaults de enums).
-- Ejecutar DESPUÉS de 000_reset.sql, 001_esquema.sql y
-- 002_seguridad_y_funciones.sql, y ANTES de 003_identidad.sql.
--
-- ADVERTENCIA: la carga es de UNA SOLA VEZ. No re-ejecutar: la tabla
-- auditoria no tiene clave única y se duplicaría (42 -> 84 filas).
-- Si algo falla a mitad, volver a empezar desde 000_reset.sql.
--
-- Tablas en este archivo: provincias (16), municipios (168), usuarios (14), perfiles_trabajador (5), perfiles_empresa (9)
-- Tablas vacías en origen (sin INSERTs): 
-- ============================================================================

-- --- provincias: 16 filas ---
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('PRI', 'Pinar del Río', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('ART', 'Artemisa', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('HAB', 'La Habana', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('MAY', 'Mayabeque', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('MAT', 'Matanzas', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('CFG', 'Cienfuegos', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('VCL', 'Villa Clara', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('SSP', 'Sancti Spíritus', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('CAV', 'Ciego de Ávila', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('CAM', 'Camagüey', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('LTU', 'Las Tunas', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('HOL', 'Holguín', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('GRA', 'Granma', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('SCU', 'Santiago de Cuba', 14, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('GUA', 'Guantánamo', 15, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.provincias (codigo, nombre, orden, activo) VALUES ('IJ', 'Isla de la Juventud', 16, TRUE) ON CONFLICT DO NOTHING;

-- --- municipios: 168 filas ---
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-consolacion-del-sur', 'Consolación del Sur', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-guane', 'Guane', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-la-palma', 'La Palma', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-los-palacios', 'Los Palacios', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-mantua', 'Mantua', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-minas-de-matahambre', 'Minas de Matahambre', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-pinar-del-rio', 'Pinar del Río', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-san-juan-y-martinez', 'San Juan y Martínez', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-san-luis', 'San Luis', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-sandino', 'Sandino', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('PRI', 'PRI-vinales', 'Viñales', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-alquizar', 'Alquízar', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-artemisa', 'Artemisa', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-bahia-honda', 'Bahía Honda', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-bauta', 'Bauta', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-caimito', 'Caimito', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-candelaria', 'Candelaria', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-guanajay', 'Guanajay', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-guira-de-melena', 'Güira de Melena', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-mariel', 'Mariel', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-san-antonio-de-los-banos', 'San Antonio de los Baños', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('ART', 'ART-san-cristobal', 'San Cristóbal', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-arroyo-naranjo', 'Arroyo Naranjo', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-boyeros', 'Boyeros', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-centro-habana', 'Centro Habana', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-cerro', 'Cerro', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-cotorro', 'Cotorro', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-diez-de-octubre', 'Diez de Octubre', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-guanabacoa', 'Guanabacoa', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-la-habana-del-este', 'La Habana del Este', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-la-habana-vieja', 'La Habana Vieja', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-la-lisa', 'La Lisa', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-marianao', 'Marianao', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-playa', 'Playa', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-plaza-de-la-revolucion', 'Plaza de la Revolución', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-regla', 'Regla', 14, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HAB', 'HAB-san-miguel-del-padron', 'San Miguel del Padrón', 15, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-batabano', 'Batabanó', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-bejucal', 'Bejucal', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-guines', 'Güines', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-jaruco', 'Jaruco', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-madruga', 'Madruga', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-melena-del-sur', 'Melena del Sur', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-nueva-paz', 'Nueva Paz', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-quivican', 'Quivicán', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-san-jose-de-las-lajas', 'San José de las Lajas', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-san-nicolas-de-bari', 'San Nicolás de Bari', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAY', 'MAY-santa-cruz-del-norte', 'Santa Cruz del Norte', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-calimete', 'Calimete', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-cardenas', 'Cárdenas', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-cienaga-de-zapata', 'Ciénaga de Zapata', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-colon', 'Colón', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-jaguey-grande', 'Jagüey Grande', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-jovellanos', 'Jovellanos', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-limonar', 'Limonar', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-los-arabos', 'Los Arabos', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-marti', 'Martí', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-matanzas', 'Matanzas', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-pedro-betancourt', 'Pedro Betancourt', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-perico', 'Perico', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('MAT', 'MAT-union-de-reyes', 'Unión de Reyes', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-abreus', 'Abreus', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-aguada-de-pasajeros', 'Aguada de Pasajeros', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-cienfuegos', 'Cienfuegos', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-cruces', 'Cruces', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-cumanayagua', 'Cumanayagua', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-lajas', 'Lajas', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-palmira', 'Palmira', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CFG', 'CFG-rodas', 'Rodas', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-caibarien', 'Caibarién', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-camajuani', 'Camajuaní', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-cifuentes', 'Cifuentes', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-corralillo', 'Corralillo', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-encrucijada', 'Encrucijada', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-manicaragua', 'Manicaragua', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-placetas', 'Placetas', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-quemado-de-guines', 'Quemado de Güines', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-ranchuelo', 'Ranchuelo', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-remedios', 'Remedios', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-sagua-la-grande', 'Sagua la Grande', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-santa-clara', 'Santa Clara', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('VCL', 'VCL-santo-domingo', 'Santo Domingo', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-cabaiguan', 'Cabaiguán', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-fomento', 'Fomento', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-jatibonico', 'Jatibonico', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-la-sierpe', 'La Sierpe', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-sancti-spiritus', 'Sancti Spíritus', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-taguasco', 'Taguasco', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-trinidad', 'Trinidad', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SSP', 'SSP-yaguajay', 'Yaguajay', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-baragua', 'Baraguá', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-bolivia', 'Bolivia', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-chambas', 'Chambas', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-ciego-de-avila', 'Ciego de Ávila', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-ciro-redondo', 'Ciro Redondo', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-florencia', 'Florencia', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-majagua', 'Majagua', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-moron', 'Morón', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-primero-de-enero', 'Primero de Enero', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAV', 'CAV-venezuela', 'Venezuela', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-camaguey', 'Camagüey', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-carlos-manuel-de-cespedes', 'Carlos Manuel de Céspedes', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-esmeralda', 'Esmeralda', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-florida', 'Florida', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-guaimaro', 'Guáimaro', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-jimaguayu', 'Jimaguayú', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-minas', 'Minas', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-najasa', 'Najasa', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-nuevitas', 'Nuevitas', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-santa-cruz-del-sur', 'Santa Cruz del Sur', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-sibanicu', 'Sibanicú', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-sierra-de-cubitas', 'Sierra de Cubitas', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('CAM', 'CAM-vertientes', 'Vertientes', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-amancio', 'Amancio', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-colombia', 'Colombia', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-jesus-menendez', 'Jesús Menéndez', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-jobabo', 'Jobabo', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-las-tunas', 'Las Tunas', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-majibacoa', 'Majibacoa', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-manati', 'Manatí', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('LTU', 'LTU-puerto-padre', 'Puerto Padre', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-antilla', 'Antilla', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-baguanos', 'Báguanos', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-banes', 'Banes', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-cacocum', 'Cacocum', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-calixto-garcia', 'Calixto García', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-cueto', 'Cueto', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-frank-pais', 'Frank País', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-gibara', 'Gibara', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-holguin', 'Holguín', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-mayari', 'Mayarí', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-moa', 'Moa', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-rafael-freyre', 'Rafael Freyre', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-sagua-de-tanamo', 'Sagua de Tánamo', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('HOL', 'HOL-urbano-noris', 'Urbano Noris', 14, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-bartolome-maso', 'Bartolomé Masó', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-bayamo', 'Bayamo', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-buey-arriba', 'Buey Arriba', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-campechuela', 'Campechuela', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-cauto-cristo', 'Cauto Cristo', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-guisa', 'Guisa', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-jiguani', 'Jiguaní', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-manzanillo', 'Manzanillo', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-media-luna', 'Media Luna', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-niquero', 'Niquero', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-pilon', 'Pilón', 11, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-rio-cauto', 'Río Cauto', 12, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GRA', 'GRA-yara', 'Yara', 13, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-contramaestre', 'Contramaestre', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-guama', 'Guamá', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-julio-antonio-mella', 'Julio Antonio Mella', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-palma-soriano', 'Palma Soriano', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-san-luis', 'San Luis', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-santiago-de-cuba', 'Santiago de Cuba', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-segundo-frente', 'Segundo Frente', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-songo-la-maya', 'Songo-La Maya', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('SCU', 'SCU-tercer-frente', 'Tercer Frente', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-baracoa', 'Baracoa', 1, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-caimanera', 'Caimanera', 2, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-el-salvador', 'El Salvador', 3, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-guantanamo', 'Guantánamo', 4, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-imias', 'Imías', 5, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-maisi', 'Maisí', 6, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-manuel-tames', 'Manuel Tames', 7, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-niceto-perez', 'Niceto Pérez', 8, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-san-antonio-del-sur', 'San Antonio del Sur', 9, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('GUA', 'GUA-yateras', 'Yateras', 10, TRUE) ON CONFLICT DO NOTHING;
INSERT INTO public.municipios (provincia_codigo, codigo, nombre, orden, activo) VALUES ('IJ', 'IJ-isla-de-la-juventud', 'Isla de la Juventud', 1, TRUE) ON CONFLICT DO NOTHING;

-- --- usuarios: 14 filas ---
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('cd2d1ce5-4995-5ecd-a57b-ae46bbd33eb3', NULL, 'a1bf1f8794660bae54e796891d136e720d7c29e3b676d962582bfe9c72646e7c', 'co***@eljardin.cu', 'company', 'active', 'Restaurante El Jardín', '5358964904', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('45a653f2-f8f7-59e5-b1f3-92b221916ada', NULL, '352bc1b187eb8ee2c442db4d1d0ecc6c1133d6df9bc9780b6e644e12e126ff3b', 'ho***@tecnohabana.cu', 'company', 'active', 'TecnoHabana', '5355551234', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('157c58b3-9e86-558f-81cf-5d025f74f6a8', NULL, '1e376687e1dfc873e21a2f15415dc5f6b44f66c614c9c976e6a0efcb4dbc46f3', 'in***@clinicasantafe.cu', 'company', 'active', 'Clínica Santa Fe', '5372040000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('0b584e37-e294-5036-bf2b-8d5c61b06ce8', NULL, '8ecdd011641c20485d66f9478de910c2e5cad05157d873786834490fb9ab1e87', 'ob***@constructoracaribe.cu', 'company', 'active', 'Constructora Caribe', '5372030000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('902b892e-f6fc-59c8-abbf-f236b0550374', NULL, '6d2feab823a93aae45fa7276f6f012ebcbdd8d4bcb7a22de8162dffd2dc726ea', 'rr***@hotelsolvaradero.cu', 'company', 'active', 'Hotel Sol Varadero', '5345610000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('64b4a31c-6b25-5afd-abd2-fd646396edd1', NULL, '950b5e55ffbe044e04139647d6fd9b8bab799602d42447ffebb0a532493c95b6', 'in***@vinalesaventura.cu', 'company', 'active', 'Viñales Aventura', '5348790000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('3c6b661e-40ce-55e1-9b45-13381b798b9a', NULL, '9743629d7b3e37abde9221943412d8c514d2833cac5fd8045c7bccce8a4879da', 'in***@academiabright.cu', 'company', 'active', 'Academia Bright', '5378620000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('ef370abd-8dca-5aaf-9e32-49edb1a11715', NULL, 'd2d042ae0a64cec49ad31751194fefc728065951afe72d35fb6a8284bd3b423f', 'pe***@distribuidorarapido.cu', 'company', 'active', 'Distribuidora Rápido', '5376450000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('29ed4f65-b341-52f2-b52b-030799b661cb', NULL, '396bdb0898d7737f443c60e5ced8401174f2ab9b795a73f06c589a9205353c01', 'co***@fincalaesperanza.cu', 'company', 'active', 'Finca La Esperanza', '5347720000', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz, NULL) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('491ace94-2914-4f4f-8d9d-e8ef382b147c', NULL, '69034df1021d37855672da39fc64422d93716ccc7614704df8ee574d8a31ffd9', 'h***@gmail.com', 'worker', 'incomplete', 'Henry Tamayo Ruz', '58964904', '2026-11-20T05:20:05.742Z'::timestamptz, '2026-11-20T22:30:52.030Z'::timestamptz, '2026-11-20T22:30:52.030Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('82b32919-3f45-45f0-a4bf-5803846d9723', NULL, '678fad0e89d579896b104d95e68d260ca803bb1e35fa7cab9ee7f2ccc30e4727', 'h***@gmail.com', 'worker', 'incomplete', 'Henry Ruz Tamayo', '54748433', '2026-11-20T05:44:59.740Z'::timestamptz, '2026-11-20T14:01:13.529Z'::timestamptz, '2026-11-20T14:01:13.529Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('5bdf7772-581e-467c-88e2-539898f3effa', NULL, 'e566142808b8709a512fd4282cebd6b46c538510b655e5d7063f5430b60be642', 'h***@gmail.com', 'worker', 'incomplete', 'Henry Ruz Tamayo', '58964904', '2026-11-20T14:05:43.618Z'::timestamptz, '2026-11-20T14:05:43.618Z'::timestamptz, '2026-11-20T14:05:43.618Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('51162e5a-808f-4b09-90d2-f7d03b002fb5', NULL, '8216f1c9898659addeb9f038ca7f7e21cace7a55d961a67a42f3a708f61ea126', 'r***@gmail.com', 'worker', 'incomplete', 'ruz henry tamayo', '52364585', '2026-11-20T19:25:03.679Z'::timestamptz, '2026-11-20T19:25:03.679Z'::timestamptz, '2026-11-20T19:25:03.679Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.usuarios (id, firebase_uid, email_hash, email_masked, role, status, display_name, phone, created_at, updated_at, last_login_at) VALUES ('11fc7e57-170e-47b8-a8da-17630c8b1366', NULL, '9464107de3c04f6a331cfbd25616ac3b0b281ec41d547a7f73b958d3cb41eb75', 'j***@gmail.com', 'worker', 'incomplete', 'José Agusto Ruz Tamayo', '58964904', '2026-11-21T00:36:13.998Z'::timestamptz, '2026-11-21T00:36:13.998Z'::timestamptz, '2026-11-21T00:36:13.998Z'::timestamptz) ON CONFLICT DO NOTHING;

-- --- perfiles_trabajador: 5 filas ---
INSERT INTO public.perfiles_trabajador (id, user_id, headline, city, country, skills, experience_years, availability, work_modes, salary_min, salary_max, cv_path, profile_percent, phone, province_code, municipality_code, locality, mobility_scope, can_relocate, remote_available, preferred_salary_period, contact_hours, contact_preference, created_at, updated_at) VALUES ('e8dd8fa2-65d8-445e-bea4-f0c67c74ced4', '491ace94-2914-4f4f-8d9d-e8ef382b147c', '', '', 'Cuba', '{}'::text[], NULL, '', '{}'::text[], NULL, NULL, '', 0, '58964904', NULL, NULL, '', NULL, FALSE, FALSE, NULL, '', NULL, '2026-11-20T05:20:05.742Z'::timestamptz, '2026-11-20T05:20:05.742Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_trabajador (id, user_id, headline, city, country, skills, experience_years, availability, work_modes, salary_min, salary_max, cv_path, profile_percent, phone, province_code, municipality_code, locality, mobility_scope, can_relocate, remote_available, preferred_salary_period, contact_hours, contact_preference, created_at, updated_at) VALUES ('741dcf53-10ce-46da-85ff-df421f3fec53', '82b32919-3f45-45f0-a4bf-5803846d9723', 'carpintero', '', 'Cuba', ARRAY['madera']::text[], 2, 'Inmediata', ARRAY['por_zonas']::text[], 1000, 5000, '', 75, '54748433', 'HAB', 'HAB-diez-de-octubre', 'Santos suárez', 'mi_municipio', FALSE, TRUE, 'diario', '9 am', 'whatsapp', '2026-11-20T05:44:59.740Z'::timestamptz, '2026-11-20T05:45:58.814Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_trabajador (id, user_id, headline, city, country, skills, experience_years, availability, work_modes, salary_min, salary_max, cv_path, profile_percent, phone, province_code, municipality_code, locality, mobility_scope, can_relocate, remote_available, preferred_salary_period, contact_hours, contact_preference, created_at, updated_at) VALUES ('c2e99092-caa4-4acf-9709-34fd733cd2c1', '5bdf7772-581e-467c-88e2-539898f3effa', 'informática', '', 'Cuba', ARRAY['programador']::text[], 3, 'Inmediata', ARRAY['presencial']::text[], 2000, 5000, '', 75, '58964904', 'HAB', 'HAB-diez-de-octubre', 'Santos suárez', 'mi_municipio', FALSE, FALSE, 'diario', '', 'whatsapp', '2026-11-20T14:05:43.618Z'::timestamptz, '2026-11-20T14:05:43.618Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_trabajador (id, user_id, headline, city, country, skills, experience_years, availability, work_modes, salary_min, salary_max, cv_path, profile_percent, phone, province_code, municipality_code, locality, mobility_scope, can_relocate, remote_available, preferred_salary_period, contact_hours, contact_preference, created_at, updated_at) VALUES ('2cc32ec5-eaa3-4b05-882e-d376046fe636', '51162e5a-808f-4b09-90d2-f7d03b002fb5', 'pito', '', 'Cuba', '{}'::text[], NULL, '', '{}'::text[], NULL, NULL, '', 13, '52364585', NULL, NULL, '', NULL, FALSE, FALSE, NULL, '', NULL, '2026-11-20T19:25:03.679Z'::timestamptz, '2026-11-20T19:25:03.679Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_trabajador (id, user_id, headline, city, country, skills, experience_years, availability, work_modes, salary_min, salary_max, cv_path, profile_percent, phone, province_code, municipality_code, locality, mobility_scope, can_relocate, remote_available, preferred_salary_period, contact_hours, contact_preference, created_at, updated_at) VALUES ('746d2c6f-a0ce-42ee-8032-ae062e4498a0', '11fc7e57-170e-47b8-a8da-17630c8b1366', 'Pizeero', '', 'Cuba', ARRAY['pizzas']::text[], 2, '', '{}'::text[], NULL, NULL, '', 38, '58964904', NULL, NULL, '', NULL, FALSE, FALSE, NULL, '', NULL, '2026-11-21T00:36:13.998Z'::timestamptz, '2026-11-21T00:36:13.998Z'::timestamptz) ON CONFLICT DO NOTHING;

-- --- perfiles_empresa: 9 filas ---
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('c06419b6-f589-5178-839d-823cc1e442e7', 'cd2d1ce5-4995-5ecd-a57b-ae46bbd33eb3', 'Restaurante El Jardín S.R.L.', 'Restaurante El Jardín', 'Gastronomía', '11-50', 'Restaurante de cocina cubana e internacional en el Vedado.', 'Vedado, La Habana', '', '', TRUE, 'basica', 'active', 'mipyme', '5358964904', '9:00–17:00', 'HAB', 'HAB-plaza-de-la-revolucion', 'Vedado', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('949cb447-6d0a-5cfc-826a-3a12f047fe13', '45a653f2-f8f7-59e5-b1f3-92b221916ada', 'TecnoHabana S.R.L.', 'TecnoHabana', 'Tecnología', '11-50', 'Estudio de desarrollo móvil. Construimos apps Android en Java.', 'Miramar, La Habana', '', '', TRUE, 'basica', 'active', 'mipyme', '5355551234', '9:00–18:00', 'HAB', 'HAB-playa', 'Miramar', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('fbc381b2-902e-5e53-a506-bd7c9a16ad6f', '157c58b3-9e86-558f-81cf-5d025f74f6a8', 'Clínica Santa Fe S.A.', 'Clínica Santa Fe', 'Salud', '11-50', 'Clínica privada de atención ambulatoria en Santa Fe.', 'Santa Fe, La Habana', '', '', TRUE, 'basica', 'active', 'privada', '5372040000', '8:00–16:00', 'HAB', 'HAB-playa', 'Santa Fe', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('72326075-255c-5c1e-93b6-fc63218e3a2f', '0b584e37-e294-5036-bf2b-8d5c61b06ce8', 'Constructora Caribe S.A.', 'Constructora Caribe', 'Construcción', '51-200', 'Empresa constructora con obras en toda La Habana.', 'Playa, La Habana', '', '', FALSE, 'basica', 'active', 'privada', '5372030000', '8:00–17:00', 'HAB', 'HAB-playa', '', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('5ca7b57f-1398-5825-ba31-e3f0eea948e3', '902b892e-f6fc-59c8-abbf-f236b0550374', 'Hotel Sol Varadero', 'Hotel Sol Varadero', 'Turismo', '51-200', 'Hotel de playa en Varadero, servicio todo incluido.', 'Varadero, Matanzas', '', '', TRUE, 'basica', 'active', 'institucional', '5345610000', '8:00–18:00', 'MAT', 'MAT-cardenas', 'Varadero', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('8aff5e48-8e9f-5164-9a11-fb8703be3954', '64b4a31c-6b25-5afd-abd2-fd646396edd1', 'Viñales Aventura', 'Viñales Aventura', 'Turismo', '1-10', 'Agencia de turismo rural y senderismo en el Valle de Viñales.', 'Viñales, Pinar del Río', '', '', TRUE, 'basica', 'active', 'tcp', '5348790000', '8:00–17:00', 'PRI', 'PRI-vinales', '', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('9adceaa7-903d-5492-8dc2-566bb8c36f52', '3c6b661e-40ce-55e1-9b45-13381b798b9a', 'Academia Bright S.R.L.', 'Academia Bright', 'Educación', '1-10', 'Academia de idiomas en Centro Habana.', 'Centro Habana, La Habana', '', '', TRUE, 'basica', 'active', 'mipyme', '5378620000', '9:00–18:00', 'HAB', 'HAB-centro-habana', '', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('cb69ad5f-c1a0-5c3d-b2e3-6bdfce05395b', 'ef370abd-8dca-5aaf-9e32-49edb1a11715', 'Distribuidora Rápido S.R.L.', 'Distribuidora Rápido', 'Transporte', '11-50', 'Distribuidora de alimentos y productos en La Habana.', 'Boyeros, La Habana', '', '', TRUE, 'basica', 'active', 'mipyme', '5376450000', '7:00–16:00', 'HAB', 'HAB-boyeros', '', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
INSERT INTO public.perfiles_empresa (id, user_id, legal_name, display_name, industry, size, description, city, website, logo_path, verified, verification_level, status, org_type, phone, contact_hours, province_code, municipality_code, locality, created_at, updated_at) VALUES ('e015b07f-6642-5e90-a387-24abc6c3bbb5', '29ed4f65-b341-52f2-b52b-030799b661cb', 'Finca La Esperanza', 'Finca La Esperanza', 'Agricultura', '1-10', 'Finca agroecológica en Güines, Mayabeque.', 'Güines, Mayabeque', '', '', FALSE, 'basica', 'active', 'cooperativa', '5347720000', '7:00–15:00', 'MAY', 'MAY-guines', '', '2026-11-20T04:30:00.000Z'::timestamptz, '2026-11-20T04:30:00.000Z'::timestamptz) ON CONFLICT DO NOTHING;
