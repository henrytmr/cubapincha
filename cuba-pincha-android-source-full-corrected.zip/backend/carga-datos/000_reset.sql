-- ============================================================================
-- CubaPincha · 000_reset.sql — REBUILD DE STAGING (DESTRUCTIVO)
-- ============================================================================
-- ⚠️  ADVERTENCIA: este archivo BORRA TODO el esquema public de
--     cubapincha-staging (todas las tablas, la vista v_ofertas_publicas,
--     funciones, políticas RLS y triggers). Ejecutar UNA SOLA VEZ, solo
--     en STAGING, como primer paso del rebuild (ver work/rebuild/REBUILD.md).
--     NO ejecutarlo nunca en producción. NO toca los esquemas auth,
--     storage ni extensions (los usuarios de Auth, el bucket 'archivos'
--     y las extensiones sobreviven). Los datos se vuelven a cargar con
--     004a/004b, generados desde los CSV de la hoja principal.
--
--     Después de este archivo: 001_esquema.sql, 002_seguridad_y_funciones.sql,
--     004a_carga_datos.sql, 004b_carga_datos.sql y 003_identidad.sql, en
--     ese orden. Los trabajos pg_cron que apunten a funciones de public
--     (expirar_ofertas, limpiezas) se borran abajo si pg_cron existe;
--     si no, borrarlos a mano en el panel antes de reprogramarlos.
-- ============================================================================

-- Borrar trabajos pg_cron que dependen de public (si pg_cron existe).
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron')
       AND EXISTS (SELECT 1 FROM information_schema.tables
                    WHERE table_schema = 'cron' AND table_name = 'job') THEN
        DELETE FROM cron.job
         WHERE jobname IN ('expirar-ofertas-cada-hora',
                           'purga-sesiones-03-30',
                           'purga-limites-03-35');
        RAISE NOTICE '000: trabajos pg_cron de CubaPincha borrados (si existían).';
    END IF;
END $$;

-- Borrar todo el esquema public y recrearlo vacío.
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;

-- Restaurar los permisos estándar de Supabase sobre el esquema public.
-- (El dueño es postgres, que es quien ejecuta este archivo en el SQL Editor.)
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO anon;
GRANT ALL ON SCHEMA public TO authenticated;
GRANT ALL ON SCHEMA public TO service_role;

-- Verificación: el esquema public debe existir y estar vacío.
SELECT 'public_existe' AS comprobacion,
       (to_regclass('public.usuarios') IS NULL) AS usuarios_ausente;
