// ============================================================================
// CubaPincha · Edge Function "api" · 2.10.0 (Supabase Auth)
// ----------------------------------------------------------------------------
// Contrato: CONTRACT.md 1.4.1, transportado a Supabase (contrato 2.0.0).
// Respuesta siempre: { ok, data, error, requestId }.
// Todas las acciones son POST, salvo `health` (GET o POST, pública).
// `publicJob` y `listCatalogs` son públicas (sin JWT). Todo lo demás
// exige JWT de Supabase Auth en `Authorization: Bearer <jwt>`.
// `login` ya no autentica: es un stub de compatibilidad (ver abajo).
//
// 34 acciones, todas implementadas. Ninguna responde NOT_IMPLEMENTED.
// Portada desde Code.gs 1.4.1 (Apps Script) a Postgres (001/002).
//
// Secretos (nombres, nunca valores):
//   Inyectados por Supabase: SUPABASE_URL, SUPABASE_ANON_KEY,
//   SUPABASE_SERVICE_ROLE_KEY.
//   Configurar con `supabase secrets set ...`:
//   ALLOWED_ORIGIN   origen de la web, p. ej. https://cubapincha.cu
//   FCM_SERVICE_ACCOUNT  JSON de la cuenta de servicio de FCM (opcional;
//                        sin él no hay push, pero las notificaciones
//                        se siguen persistiendo)
//   CRON_SECRET      secreto para el resumen diario de filtros
//                    (endpoint ?cron=saved-filters-daily, opcional)
//   ELIMINADOS: FIREBASE_API_KEY, REQUIRE_EMAIL_VERIFIED,
//   SESSION_TTL_HOURS. No hay sesiones opacas ni tabla `sesiones`.
// ============================================================================

import { createClient } from "npm:@supabase/supabase-js@2";

// ---------------------------------------------------------------------------
// Constantes
// ---------------------------------------------------------------------------
const API_VERSION = "2.0.0-supabase";
const MAX_BODY_BYTES = 262144;
const MAX_INTERESTS_PER_HOUR = 30;

const READ_ACTIONS = new Set([
  "health",
  "me",
  "jobs",
  "job",
  "applications",
  "notifications",
  "sync",
  "contactOptions",
  "listFilters",
  "publicJob",
  "listCatalogs",
  "getRatings",
]);
const WRITE_ACTIONS = new Set([
  "login",
  "logout",
  "registerProfile",
  "updateProfile",
  "createJob",
  "publishJob",
  "updateJob",
  "changeJobStatus",
  "archiveJob",
  "deleteJob",
  "expressInterest",
  "sendReminder",
  "changeApplicationStatus",
  "saveJob",
  "saveCandidate",
  "saveFilter",
  "deleteFilter",
  "syncActions",
  "contactEvent",
  "registerDevice",
  "unregisterDevice",
  "markNotificationRead",
  "report",
  "rateApplication",
]);
// Públicas (sin JWT): health, publicJob, listCatalogs y getRatings. `login` es un stub
// de compatibilidad y tampoco exige JWT: solo dice que hay que actualizar.
const PUBLIC_ACTIONS = new Set([
  "health",
  "login",
  "publicJob",
  "listCatalogs",
  "getRatings",
]);

const PROVINCE_CODES = [
  "PRI",
  "ART",
  "HAB",
  "MAY",
  "MAT",
  "CFG",
  "VCL",
  "SSP",
  "CAV",
  "CAM",
  "LTU",
  "HOL",
  "GRA",
  "SCU",
  "GUA",
  "IJ",
];
const SALARY_PERIODS = [
  "mensual",
  "quincenal",
  "semanal",
  "diario",
  "por_hora",
  "por_proyecto",
  "comision",
  "a_convenir",
];
const MOBILITY_SCOPES = [
  "mi_municipio",
  "mi_provincia",
  "cualquier_lugar",
  "remoto",
];
const ORG_TYPES = [
  "privada",
  "mipyme",
  "cooperativa",
  "tcp",
  "proyecto",
  "institucional",
];
const REPORT_REASONS = [
  "pide_dinero",
  "salario_enganoso",
  "ubicacion_falsa",
  "identidad_no_confirmada",
  "acoso",
  "duplicada",
  "otro",
];
const APPLICATION_STATUSES = [
  "sent",
  "reviewing",
  "interview",
  "hired",
  "rejected",
  "withdrawn",
];
const COMPANY_APPLICATION_TRANSITIONS: Record<string, string[]> = {
  sent: ["reviewing", "interview", "rejected"],
  reviewing: ["interview", "hired", "rejected"],
  interview: ["hired", "rejected"],
  hired: [],
  rejected: [],
  withdrawn: [],
};
const JOB_STATUS_TRANSITIONS: Record<string, string[]> = {
  draft: ["closed"],
  published: ["paused", "closed"],
  paused: ["published", "closed"],
  closed: [],
  expired: ["closed"],
  archived: ["published", "paused", "closed"],
};

const CORS = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ??
    "https://cubapincha.cu",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

// ---------------------------------------------------------------------------
// Tipos
// ---------------------------------------------------------------------------
type Json = Record<string, unknown>;
// Fila de base de datos (snake_case). `any` explícito: las columnas
// varían por tabla y el cliente no tiene tipos generados.
type Row = Record<string, any>;

class ApiError extends Error {
  constructor(public code: string, message: string, public status: number) {
    super(message);
  }
}

interface AuthContext {
  usuarioId: string;
  email: string;
  emailVerified: boolean;
  role: "worker" | "company" | "";
  status: string;
  displayName: string;
  emailMasked: string;
  phone: string;
}

// ---------------------------------------------------------------------------
// Clientes: service_role (solo servidor) y por petición (JWT del usuario)
// ---------------------------------------------------------------------------
const db = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false, autoRefreshToken: false } },
);

function userClient(jwt: string) {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    {
      global: { headers: { Authorization: `Bearer ${jwt}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    },
  );
}

// ---------------------------------------------------------------------------
// Respuestas
// ---------------------------------------------------------------------------
function ok(data: unknown, requestId: string): Response {
  return json({ ok: true, data, error: null, requestId }, 200);
}

function fail(
  code: string,
  message: string,
  requestId: string,
  status: number,
): Response {
  return json(
    { ok: false, data: null, error: { code, message }, requestId },
    status,
  );
}

function json(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...CORS },
  });
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
async function sha256Hex(text: string): Promise<string> {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((b) =>
    b.toString(16).padStart(2, "0")
  ).join("");
}

function maskEmail(email: string): string {
  const parts = String(email || "").split("@");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return "***";
  return `${parts[0].charAt(0)}***@${parts[1]}`;
}

function normalizeText(text: unknown): string {
  return String(text ?? "")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function toBool(v: unknown): boolean {
  return v === true || v === "TRUE" || v === "true" || v === 1;
}

function toNum(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function isExpiredRow(row: Row): boolean {
  if (!row || !row.expires_at) return false;
  const t = new Date(row.expires_at).getTime();
  return !Number.isNaN(t) && t <= Date.now();
}

function rejectUnknownFields(body: Json, allowed: string[]): void {
  const set = new Set(["action", "accessToken", ...allowed]);
  for (const key of Object.keys(body)) {
    if (!set.has(key)) {
      throw new ApiError("VALIDATION_ERROR", `Campo no permitido: ${key}`, 400);
    }
  }
}

function requireString(body: Json, field: string, maxLength: number): string {
  const value = body[field];
  if (typeof value !== "string" || value.trim() === "") {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} es obligatorio.`,
      400,
    );
  }
  const clean = value.replace(/[<>\u0000-\u001F\u007F]/g, "").trim();
  if (clean.length > maxLength) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} es demasiado largo.`,
      400,
    );
  }
  return clean;
}

function optionalString(body: Json, field: string, maxLength: number): string {
  const value = body[field];
  if (value === undefined || value === null) return "";
  if (typeof value !== "string") {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} debe ser texto.`,
      400,
    );
  }
  return value.replace(/[<>\u0000-\u001F\u007F]/g, "").trim().slice(
    0,
    maxLength,
  );
}

function requireEnum(body: Json, field: string, allowed: string[]): string {
  const value = body[field];
  if (typeof value !== "string" || !allowed.includes(value)) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} tiene un valor no válido.`,
      400,
    );
  }
  return value;
}

function optionalEnum(body: Json, field: string, allowed: string[]): string {
  const value = body[field];
  if (value === undefined || value === null || value === "") return "";
  if (typeof value !== "string" || !allowed.includes(value)) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} tiene un valor no válido.`,
      400,
    );
  }
  return value;
}

function optionalBool(body: Json, field: string): boolean {
  const value = body[field];
  if (value === undefined || value === null || value === "") return false;
  if (typeof value === "boolean") return value;
  if (value === "true") return true;
  if (value === "false") return false;
  throw new ApiError(
    "VALIDATION_ERROR",
    `El campo ${field} debe ser verdadero o falso.`,
    400,
  );
}

function optionalNumber(
  body: Json,
  field: string,
  min: number,
  max: number,
): number | null {
  const value = body[field];
  if (value === undefined || value === null || value === "") return null;
  const num = Number(value);
  if (!Number.isFinite(num) || num < min || num > max) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} no es un número válido.`,
      400,
    );
  }
  return num;
}

function optionalStringArray(
  body: Json,
  field: string,
  maxItems: number,
  maxLength: number,
): string[] {
  const value = body[field];
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} debe ser una lista.`,
      400,
    );
  }
  if (value.length > maxItems) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} tiene demasiados elementos.`,
      400,
    );
  }
  return (value as unknown[]).map((item) => {
    if (typeof item !== "string") {
      throw new ApiError(
        "VALIDATION_ERROR",
        `El campo ${field} debe contener solo texto.`,
        400,
      );
    }
    return item.replace(/[<>\u0000-\u001F\u007F]/g, "").trim().slice(
      0,
      maxLength,
    );
  }).filter((item) => item !== "");
}

function optionalIsoDate(body: Json, field: string): string {
  const value = body[field];
  if (value === undefined || value === null || value === "") return "";
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `El campo ${field} no es una fecha válida.`,
      400,
    );
  }
  return date.toISOString();
}

function parsePagination(params: Json): { limit: number; offset: number } {
  let limit = parseInt(String(params.limit ?? ""), 10);
  if (Number.isNaN(limit)) limit = 20;
  limit = Math.max(1, Math.min(50, limit));
  let offset = parseInt(String(params.cursor ?? "0"), 10);
  if (Number.isNaN(offset) || offset < 0) offset = 0;
  return { limit, offset };
}

function nextCursor(
  offset: number,
  limit: number,
  total: number,
): string | null {
  return offset + limit < total ? String(offset + limit) : null;
}

function isValidEmail(email: unknown): boolean {
  return typeof email === "string" &&
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}

/** Traduce errores de Postgres con prefijo NOT_FOUND: / CONFLICT: */
function mapDbError(err: { message?: string } | null): ApiError {
  const msg = err?.message ?? "";
  if (msg.includes("NOT_FOUND:")) {
    return new ApiError("NOT_FOUND", msg.split("NOT_FOUND:")[1].trim(), 404);
  }
  if (msg.includes("CONFLICT:")) {
    return new ApiError("CONFLICT", msg.split("CONFLICT:")[1].trim(), 409);
  }
  console.error("DB_ERROR", msg);
  return new ApiError(
    "INTERNAL_ERROR",
    "Error interno. Inténtalo de nuevo.",
    500,
  );
}

function throwIfDbError(error: { message?: string } | null): void {
  if (error) throw mapDbError(error);
}

// ---------------------------------------------------------------------------
// Configuración (tabla `configuracion`, con valores por defecto)
// ---------------------------------------------------------------------------
const DEFAULT_CONFIG: Record<string, string> = {
  MATCH_THRESHOLD: "60",
  MAX_INTERESTS_PER_HOUR: "30",
  MAX_JOBS_PER_HOUR: "10",
  MAX_NOTIFICATIONS_PER_PUBLISH: "200",
  MAX_LOGIN_PER_HOUR: "10",
  MAX_REGISTER_PER_HOUR: "5",
  MAX_REPORTS_PER_HOUR: "10",
  MAX_SAVES_PER_HOUR: "60",
  MAX_CONTACT_EVENTS_PER_HOUR: "30",
};
const configCache = new Map<string, string>();

async function getConfig(key: string): Promise<string> {
  if (configCache.has(key)) return configCache.get(key)!;
  let value = DEFAULT_CONFIG[key] ?? "";
  const { data } = await db.from("configuracion").select("valor").eq(
    "clave",
    key,
  ).maybeSingle();
  if (data?.valor) value = String(data.valor);
  configCache.set(key, value);
  return value;
}

async function configInt(key: string, fallback: number): Promise<number> {
  const n = parseInt(await getConfig(key), 10);
  return Number.isNaN(n) || n <= 0 ? fallback : n;
}

// ---------------------------------------------------------------------------
// Auditoría (best effort: nunca rompe la operación principal)
// ---------------------------------------------------------------------------
async function audit(
  actorId: string,
  action: string,
  entityType: string,
  entityId: string,
  beforeObj: unknown,
  afterObj: unknown,
): Promise<void> {
  try {
    await db.from("auditoria").insert({
      actor_id: actorId || "",
      action,
      entity_type: entityType || "",
      entity_id: entityId || "",
      before_json: beforeObj ? beforeObj : null,
      after_json: afterObj ? afterObj : null,
    });
  } catch (err) {
    console.error("AUDIT_FAIL", action, err);
  }
}

// ---------------------------------------------------------------------------
// Autenticación: verificar el JWT de Supabase (AUTH_SUPABASE.md §5.2)
// ---------------------------------------------------------------------------
async function requireAuth(jwt: string | undefined): Promise<AuthContext> {
  if (!jwt || jwt.trim() === "") {
    throw new ApiError("AUTH_REQUIRED", "Falta el token de sesión.", 401);
  }
  const client = userClient(jwt.trim());
  const { data: { user }, error } = await client.auth.getUser();
  if (error || !user) {
    throw new ApiError("AUTH_REQUIRED", "Sesión no válida o caducada.", 401);
  }
  const { data: row } = await db
    .from("usuarios")
    .select("id, role, status, display_name, email_masked, phone")
    .eq("id", user.id)
    .maybeSingle();
  // Sin fila en `usuarios` (registro de GoTrue sin registerProfile):
  // identidad válida, perfil pendiente. Los handlers que exigen un
  // perfil devuelven NOT_FOUND, como hacía Code.gs.
  const ctx: AuthContext = {
    usuarioId: user.id,
    email: String(user.email ?? "").toLowerCase(),
    emailVerified: user.email_confirmed_at != null,
    role: (row?.role ?? "") as AuthContext["role"],
    status: row?.status ?? "incomplete",
    displayName: row?.display_name ??
      String(
        user.user_metadata?.display_name ?? user.user_metadata?.full_name ?? "",
      ),
    emailMasked: row?.email_masked ?? maskEmail(user.email ?? ""),
    phone: row?.phone ?? "",
  };
  requireAccountUsable(ctx);
  return ctx;
}

function requireAccountUsable(ctx: AuthContext): void {
  if (ctx.status === "suspended") {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "La cuenta está suspendida. Contacta con soporte.",
      403,
    );
  }
  if (ctx.status === "deleted") {
    throw new ApiError("FORBIDDEN_ROLE", "La cuenta está eliminada.", 403);
  }
}

function requireRole(ctx: AuthContext, role: "worker" | "company"): void {
  if (ctx.role !== role) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      `Esta acción requiere el rol ${role}.`,
      403,
    );
  }
}

async function getWorkerProfile(userId: string): Promise<Row | null> {
  const { data, error } = await db.from("perfiles_trabajador").select("*").eq(
    "user_id",
    userId,
  ).maybeSingle();
  throwIfDbError(error);
  return data ?? null;
}

async function getCompanyProfile(userId: string): Promise<Row | null> {
  const { data, error } = await db.from("perfiles_empresa").select("*").eq(
    "user_id",
    userId,
  ).maybeSingle();
  throwIfDbError(error);
  return data ?? null;
}

/** Límite por usuario (consumir_limite es atómico en Postgres). */
async function consumeLimit(
  userId: string,
  action: string,
  max: number,
  label: string,
): Promise<void> {
  const { data: within, error } = await db.rpc("consumir_limite", {
    p_usuario: userId,
    p_accion: action,
    p_max: max,
  });
  throwIfDbError(error);
  if (within === false) {
    throw new ApiError(
      "RATE_LIMITED",
      `Has alcanzado el límite de ${label}. Inténtalo más tarde.`,
      429,
    );
  }
}

// ---------------------------------------------------------------------------
// Notificaciones y push FCM (Code.gs §10, portado)
// ---------------------------------------------------------------------------
async function createNotification(
  userId: string,
  type: string,
  title: string,
  bodyText: string,
  entityId: string,
  route: string,
): Promise<Row | null> {
  const dedupeKey = `${type}:${userId}:${entityId || ""}`;
  const { data: existing } = await db.from("notificaciones").select("id").eq(
    "dedupe_key",
    dedupeKey,
  ).maybeSingle();
  if (existing) return null;
  const { data, error } = await db.from("notificaciones").insert({
    user_id: userId,
    type,
    title,
    body: bodyText,
    entity_id: entityId || "",
    route: route || "",
    dedupe_key: dedupeKey,
  }).select().single();
  if (error || !data) {
    // Carrera con otra llamada: el dedupe ya ganó.
    if (error?.message?.includes("duplicate")) return null;
    console.error("NOTIFICATION_FAIL", error?.message);
    return null;
  }
  const pushed = await trySendPush(data);
  if (pushed) {
    await db.from("notificaciones").update({
      sent_at: new Date().toISOString(),
    }).eq("id", data.id);
    data.sent_at = new Date().toISOString();
  }
  return data;
}

// --- FCM HTTP v1: cuenta de servicio en el secreto FCM_SERVICE_ACCOUNT ---
// Sin ese secreto no hay push, pero la notificación queda persistida.
let fcmTokenCache: { token: string; expiresAt: number } | null = null;

function pemToDer(pem: string): ArrayBuffer {
  const b64 = pem.replace(/-----BEGIN [^-]+-----/g, "").replace(
    /-----END [^-]+-----/g,
    "",
  ).replace(/\s+/g, "");
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer.slice(
    bytes.byteOffset,
    bytes.byteOffset + bytes.byteLength,
  ) as ArrayBuffer;
}

async function getFcmAccessToken(sa: Row): Promise<string | null> {
  const nowSec = Math.floor(Date.now() / 1000);
  if (fcmTokenCache && fcmTokenCache.expiresAt > nowSec + 60) {
    return fcmTokenCache.token;
  }
  if (!sa.private_key || !sa.client_email) return null;
  try {
    const header = { alg: "RS256", typ: "JWT" };
    const claim = {
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      exp: nowSec + 3600,
      iat: nowSec,
    };
    const enc = (obj: unknown) =>
      btoa(
        String.fromCharCode(...new TextEncoder().encode(JSON.stringify(obj))),
      )
        .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const unsigned = `${enc(header)}.${enc(claim)}`;
    const key = await crypto.subtle.importKey(
      "pkcs8",
      pemToDer(String(sa.private_key)),
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["sign"],
    );
    const sig = await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      key,
      new TextEncoder().encode(unsigned),
    );
    const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)))
      .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const resp = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: `${unsigned}.${sigB64}`,
      }),
    });
    if (!resp.ok) return null;
    const parsed = await resp.json().catch(() => ({}));
    if (!parsed.access_token) return null;
    fcmTokenCache = { token: parsed.access_token, expiresAt: nowSec + 3300 };
    return parsed.access_token;
  } catch (err) {
    console.error("FCM_TOKEN_FAIL", err);
    return null;
  }
}

async function trySendPush(notification: Row): Promise<boolean> {
  try {
    const { data: devices } = await db.from("dispositivos_fcm")
      .select("*").eq("user_id", notification.user_id).eq("enabled", true);
    if (!devices || devices.length === 0) return false;
    const saRaw = Deno.env.get("FCM_SERVICE_ACCOUNT");
    if (!saRaw) return false;
    let sa: Row;
    try {
      sa = JSON.parse(saRaw);
    } catch {
      return false;
    }
    if (!sa.project_id) return false;
    const accessToken = await getFcmAccessToken(sa);
    if (!accessToken) return false;
    const url =
      `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;
    let sent = 0;
    for (const device of devices as Row[]) {
      if (!device.token) continue;
      const resp = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          message: {
            token: device.token,
            data: {
              notificationId: String(notification.id),
              type: String(notification.type),
              route: String(notification.route || ""),
              title: String(notification.title || ""),
              body: String(notification.body || ""),
            },
          },
        }),
      });
      if (resp.ok) {
        sent++;
        continue;
      }
      const text = await resp.text().catch(() => "");
      if (
        text.includes("UNREGISTERED") || text.includes("NOT_FOUND") ||
        text.includes("INVALID_ARGUMENT")
      ) {
        await db.from("dispositivos_fcm").update({ enabled: false }).eq(
          "id",
          device.id,
        );
      } else {
        console.error("PUSH_FAIL", resp.status, text.slice(0, 200));
      }
    }
    return sent > 0;
  } catch (err) {
    console.error("PUSH_ERROR", err);
    return false;
  }
}

// ---------------------------------------------------------------------------
// Motor de coincidencia (Code.gs §11, portado; trabaja sobre filas DB)
// ---------------------------------------------------------------------------
function computeMatchScore(job: Row, worker: Row | null): number {
  if (!worker) return 0;
  let score = 0;
  const headlineNorm = normalizeText(worker.headline);
  const skills: string[] = Array.isArray(worker.skills) ? worker.skills : [];
  const skillsNorm = skills.map((s) => normalizeText(s));
  const categoryNorm = normalizeText(job.category);
  if (
    categoryNorm &&
    (headlineNorm.includes(categoryNorm) || skillsNorm.includes(categoryNorm))
  ) {
    score += 40;
  } else if (categoryNorm) {
    const words = categoryNorm.split(" ").filter((w) => w.length > 3);
    for (const w of words) {
      if (headlineNorm.includes(w)) {
        score += 20;
        break;
      }
    }
  }
  if (
    job.municipality_code && worker.municipality_code &&
    job.municipality_code === worker.municipality_code
  ) {
    score += 15;
  } else if (
    job.province_code && worker.province_code &&
    job.province_code === worker.province_code
  ) {
    score += 8;
  } else if (
    job.city && worker.city &&
    normalizeText(job.city) === normalizeText(worker.city)
  ) {
    score += 15;
  }
  const workModes: string[] = Array.isArray(worker.work_modes)
    ? worker.work_modes
    : [];
  if (job.work_mode && workModes.includes(job.work_mode)) score += 10;
  const requirements: Row =
    (job.requirements && typeof job.requirements === "object")
      ? job.requirements
      : {};
  const requiredSkills: string[] = Array.isArray(requirements.skills)
    ? requirements.skills
    : [];
  if (requiredSkills.length > 0) {
    let matched = 0;
    for (const req of requiredSkills) {
      if (skillsNorm.includes(normalizeText(req))) matched++;
    }
    score += Math.round(25 * (matched / requiredSkills.length));
  } else {
    score += 10;
  }
  const experienceMin = requirements.experienceMin;
  const experienceYears = Number(worker.experience_years) || 0;
  if (
    experienceMin === undefined || experienceMin === null ||
    experienceYears >= Number(experienceMin)
  ) score += 10;
  return Math.max(0, Math.min(100, score));
}

function filterMatchesJob(f: Row, job: Row, company: Row | null): boolean {
  if (!f || typeof f !== "object") return false;
  if (f.category && job.category !== f.category) return false;
  if (f.workMode && job.work_mode !== f.workMode) return false;
  if (f.contractType && job.contract_type !== f.contractType) return false;
  if (f.city && !normalizeText(job.city).includes(normalizeText(f.city))) {
    return false;
  }
  if (f.provinceCode && job.province_code !== f.provinceCode) return false;
  if (f.municipalityCode && job.municipality_code !== f.municipalityCode) {
    return false;
  }
  if (
    f.onlyWithSalary === true &&
    (job.salary_min === null || job.salary_min === undefined) &&
    (job.salary_max === null || job.salary_max === undefined)
  ) return false;
  if (
    f.minSalary !== undefined && f.minSalary !== null && f.minSalary !== "" &&
    job.salary_max !== null && job.salary_max !== undefined &&
    Number(job.salary_max) < Number(f.minSalary)
  ) return false;
  if (
    f.maxSalary !== undefined && f.maxSalary !== null && f.maxSalary !== "" &&
    job.salary_min !== null && job.salary_min !== undefined &&
    Number(job.salary_min) > Number(f.maxSalary)
  ) return false;
  if (f.verifiedOnly === true && (!company || !toBool(company.verified))) {
    return false;
  }
  if (f.q) {
    const haystack = normalizeText(
      [
        job.title,
        job.category,
        job.description,
        job.city,
        job.province_name,
        job.municipality_name,
        job.locality,
        company ? company.display_name : "",
      ].join(" "),
    );
    if (!haystack.includes(normalizeText(f.q))) return false;
  }
  return true;
}

/** Alertas inmediatas al publicar (frequency=inmediata). */
async function matchSavedFiltersForJob(
  job: Row,
  notifiedKeys: Set<string>,
): Promise<number> {
  const { data: filters } = await db.from("filtros_guardados")
    .select("*").eq("enabled", true).eq("frequency", "inmediata");
  if (!filters || filters.length === 0) return 0;
  const companies = await companiesByIds(
    (filters as Row[]).map(() => job.empresa_id),
  );
  const company = companies.get(job.empresa_id) ?? null;
  let created = 0;
  for (const saved of filters as Row[]) {
    const { data: user } = await db.from("usuarios").select("status").eq(
      "id",
      saved.user_id,
    ).maybeSingle();
    if (!user || user.status !== "active") continue;
    if (notifiedKeys.has(`new_relevant_job:${saved.user_id}:${job.id}`)) {
      continue;
    }
    if (notifiedKeys.has(`saved_filter_match:${saved.user_id}:${job.id}`)) {
      continue;
    }
    const f: Row = (saved.filters && typeof saved.filters === "object")
      ? saved.filters
      : {};
    if (!filterMatchesJob(f, job, company)) continue;
    const n = await createNotification(
      saved.user_id,
      "saved_filter_match",
      `Nueva oferta para «${saved.name}»`,
      `«${job.title}» en ${job.city || "tu zona"}`,
      job.id,
      `job/${job.id}`,
    );
    if (n) {
      notifiedKeys.add(`saved_filter_match:${saved.user_id}:${job.id}`);
      created++;
    }
  }
  return created;
}

/** Al publicar: matching de perfil + alertas inmediatas de filtros. */
async function runMatchingForJob(job: Row): Promise<number> {
  const threshold = await configInt("MATCH_THRESHOLD", 60);
  const maxNotifications = await configInt(
    "MAX_NOTIFICATIONS_PER_PUBLISH",
    200,
  );
  const { data: workers } = await db.from("perfiles_trabajador").select("*");
  const { data: users } = await db.from("usuarios").select("id, status");
  const usersById = new Map<string, Row>(
    (users as Row[] ?? []).map((u) => [u.id, u]),
  );
  const { data: existingNotes } = await db.from("notificaciones").select(
    "dedupe_key",
  ).eq("entity_id", String(job.id));
  const notifiedKeys = new Set<string>(
    (existingNotes as Row[] ?? []).map((n) => n.dedupe_key),
  );
  let notified = 0;
  for (const worker of (workers as Row[] ?? [])) {
    if (notified >= maxNotifications) break;
    const user = usersById.get(worker.user_id);
    if (!user || user.status !== "active") continue;
    if (notifiedKeys.has(`new_relevant_job:${worker.user_id}:${job.id}`)) {
      continue;
    }
    const score = computeMatchScore(job, worker);
    if (score < threshold) continue;
    const created = await createNotification(
      worker.user_id,
      "new_relevant_job",
      "Nueva oferta para ti",
      `«${job.title}» en ${job.city || "tu zona"} · Coincidencia ${score}%`,
      job.id,
      `job/${job.id}`,
    );
    if (created) {
      notified++;
      notifiedKeys.add(`new_relevant_job:${worker.user_id}:${job.id}`);
    }
  }
  await matchSavedFiltersForJob(job, notifiedKeys);
  return notified;
}

/**
 * Resumen diario de filtros (trigger 09:00, CONTRACT.md). No es una
 * acción del contrato: se invoca por `?cron=saved-filters-daily` con
 * el secreto CRON_SECRET (ver la entrada HTTP al final).
 */
export async function runSavedFiltersDaily(): Promise<number> {
  const { data: filters } = await db.from("filtros_guardados")
    .select("*").eq("enabled", true).eq("frequency", "diaria");
  if (!filters || filters.length === 0) return 0;
  const { data: companies } = await db.from("perfiles_empresa").select("*");
  const companiesById = new Map<string, Row>(
    (companies as Row[] ?? []).map((c) => [c.id, c]),
  );
  const { data: users } = await db.from("usuarios").select("id, status");
  const usersById = new Map<string, Row>(
    (users as Row[] ?? []).map((u) => [u.id, u]),
  );
  const { data: jobs } = await db.from("ofertas").select("*").eq(
    "status",
    "published",
  );
  const now = new Date().toISOString();
  let digests = 0;
  for (const saved of filters as Row[]) {
    const user = usersById.get(saved.user_id);
    const since = saved.last_run_at || saved.created_at || "";
    const sinceMs = since ? new Date(since).getTime() : 0;
    if (user && user.status === "active") {
      const f: Row = (saved.filters && typeof saved.filters === "object")
        ? saved.filters
        : {};
      const matches = (jobs as Row[] ?? []).filter((job) => {
        if (isExpiredRow(job)) return false;
        const publishedMs = new Date(job.published_at || job.created_at)
          .getTime();
        if (Number.isNaN(publishedMs) || publishedMs <= sinceMs) return false;
        return filterMatchesJob(
          f,
          job,
          companiesById.get(job.empresa_id) ?? null,
        );
      });
      if (matches.length > 0) {
        const first = matches[0];
        await createNotification(
          saved.user_id,
          "saved_filter_match",
          `${matches.length}${
            matches.length === 1 ? " oferta nueva" : " ofertas nuevas"
          } para «${saved.name}»`,
          `«${first.title}» en ${first.city || "tu zona"}${
            matches.length > 1 ? ` y ${matches.length - 1} más` : ""
          }`,
          first.id,
          `job/${first.id}`,
        );
        digests++;
      }
    }
    await db.from("filtros_guardados").update({ last_run_at: now }).eq(
      "id",
      saved.id,
    );
  }
  return digests;
}

// ---------------------------------------------------------------------------
// Mapeo DB (snake_case) -> API (camelCase) y lookups
// ---------------------------------------------------------------------------
async function companiesByIds(ids: string[]): Promise<Map<string, Row>> {
  const unique = [...new Set(ids.filter(Boolean))];
  if (unique.length === 0) return new Map();
  const { data } = await db.from("perfiles_empresa").select("*").in(
    "id",
    unique,
  );
  return new Map<string, Row>((data as Row[] ?? []).map((c) => [c.id, c]));
}

async function placeNames(): Promise<
  { provincias: Map<string, string>; municipios: Map<string, string> }
> {
  const { data: prov } = await db.from("provincias").select("codigo, nombre");
  const { data: mun } = await db.from("municipios").select(
    "provincia_codigo, codigo, nombre",
  );
  return {
    provincias: new Map((prov as Row[] ?? []).map((p) => [p.codigo, p.nombre])),
    municipios: new Map(
      (mun as Row[] ?? []).map((
        m,
      ) => [`${m.provincia_codigo}:${m.codigo}`, m.nombre]),
    ),
  };
}

function mapJob(
  job: Row,
  company: Row | null,
  places: { provincias: Map<string, string>; municipios: Map<string, string> },
  extra: Json = {},
): Json {
  const req: Row = (job.requirements && typeof job.requirements === "object")
    ? job.requirements
    : {};
  return {
    jobId: job.id,
    companyId: job.empresa_id,
    companyName: company
      ? (company.display_name || company.legal_name || "")
      : "",
    companyVerified: company ? toBool(company.verified) : false,
    title: job.title ?? "",
    category: job.category ?? "",
    description: job.description ?? "",
    responsibilities: Array.isArray(job.responsibilities)
      ? job.responsibilities
      : [],
    requirements: Array.isArray(req.skills) ? req.skills : [],
    experienceMin: req.experienceMin !== undefined ? req.experienceMin : null,
    languages: Array.isArray(req.languages) ? req.languages : [],
    keywords: Array.isArray(req.keywords) ? req.keywords : [],
    benefits: Array.isArray(job.benefits) ? job.benefits : [],
    city: job.city ?? "",
    countryCode: "CU",
    provinceCode: job.province_code ?? "",
    provinceName: places.provincias.get(job.province_code ?? "") ?? "",
    municipalityCode: job.municipality_code ?? "",
    municipalityName: places.municipios.get(
      `${job.province_code ?? ""}:${job.municipality_code ?? ""}`,
    ) ?? "",
    locality: job.locality ?? "",
    workMode: job.work_mode ?? "",
    contractType: job.contract_type ?? "",
    salaryMin: toNum(job.salary_min),
    salaryMax: toNum(job.salary_max),
    salaryPeriod: job.salary_period ?? "mensual",
    includesFood: toBool(job.includes_food),
    includesTransport: toBool(job.includes_transport),
    includesAccommodation: toBool(job.includes_accommodation),
    includesTips: toBool(job.includes_tips),
    paymentNotes: job.payment_notes ?? "",
    contactHours: job.contact_hours ?? "",
    startDate: job.start_date ?? "",
    status: job.status,
    archivedAt: job.archived_at ?? "",
    archiveReason: job.archive_reason ?? "",
    publishedAt: job.published_at ?? "",
    expiresAt: job.expires_at ?? "",
    createdAt: job.created_at,
    updatedAt: job.updated_at,
    ...extra,
  };
}

function mapWorkerProfile(
  w: Row,
  places: { provincias: Map<string, string>; municipios: Map<string, string> },
): Json {
  return {
    workerId: w.id,
    userId: w.user_id,
    headline: w.headline ?? "",
    city: w.city ?? "",
    country: w.country ?? "",
    phone: w.phone ?? "",
    provinceCode: w.province_code ?? "",
    provinceName: places.provincias.get(w.province_code ?? "") ?? "",
    municipalityCode: w.municipality_code ?? "",
    municipalityName: places.municipios.get(
      `${w.province_code ?? ""}:${w.municipality_code ?? ""}`,
    ) ?? "",
    locality: w.locality ?? "",
    mobilityScope: w.mobility_scope ?? "",
    canRelocate: toBool(w.can_relocate),
    remoteAvailable: toBool(w.remote_available),
    preferredSalaryPeriod: w.preferred_salary_period ?? "",
    contactHours: w.contact_hours ?? "",
    contactPreference: w.contact_preference ?? "",
    skills: Array.isArray(w.skills) ? w.skills : [],
    experienceYears: toNum(w.experience_years),
    availability: w.availability ?? "",
    workModes: Array.isArray(w.work_modes) ? w.work_modes : [],
    salaryMin: toNum(w.salary_min),
    salaryMax: toNum(w.salary_max),
    hasCv: !!w.cv_path,
    profilePercent: w.profile_percent ?? 0,
    updatedAt: w.updated_at,
  };
}

function mapCompanyProfile(
  c: Row,
  places: { provincias: Map<string, string>; municipios: Map<string, string> },
): Json {
  return {
    companyId: c.id,
    userId: c.user_id,
    legalName: c.legal_name ?? "",
    displayName: c.display_name ?? "",
    industry: c.industry ?? "",
    size: c.size ?? "",
    description: c.description ?? "",
    city: c.city ?? "",
    website: c.website ?? "",
    phone: c.phone ?? "",
    provinceCode: c.province_code ?? "",
    provinceName: places.provincias.get(c.province_code ?? "") ?? "",
    municipalityCode: c.municipality_code ?? "",
    municipalityName: places.municipios.get(
      `${c.province_code ?? ""}:${c.municipality_code ?? ""}`,
    ) ?? "",
    locality: c.locality ?? "",
    contactHours: c.contact_hours ?? "",
    orgType: c.org_type ?? "",
    verificationLevel: c.verification_level ?? "",
    hasLogo: !!c.logo_path,
    verified: toBool(c.verified),
    status: c.status,
    updatedAt: c.updated_at,
  };
}

function mapNotification(n: Row): Json {
  return {
    notificationId: n.id,
    type: n.type,
    title: n.title,
    body: n.body,
    entityId: n.entity_id,
    route: n.route,
    read: !!n.read_at,
    readAt: n.read_at ?? null,
    createdAt: n.created_at,
  };
}

function mapFilter(r: Row): Json {
  const f: Row = (r.filters && typeof r.filters === "object") ? r.filters : {};
  return {
    filterId: r.id,
    name: r.name,
    query: f.q ?? "",
    category: f.category ?? "",
    workMode: f.workMode ?? "",
    contractType: f.contractType ?? "",
    city: f.city ?? "",
    provinceCode: f.provinceCode ?? "",
    municipalityCode: f.municipalityCode ?? "",
    mobilityScope: f.mobilityScope ?? "",
    minSalary: f.minSalary !== undefined && f.minSalary !== null
      ? f.minSalary
      : null,
    maxSalary: f.maxSalary !== undefined && f.maxSalary !== null
      ? f.maxSalary
      : null,
    verifiedOnly: f.verifiedOnly === true,
    onlyWithSalary: f.onlyWithSalary === true,
    sort: f.sort ?? "recent",
    frequency: r.frequency ?? "diaria",
    enabled: toBool(r.enabled),
  };
}

function computeProfilePercent(w: Row): number {
  const checks = [
    !!w.headline,
    !!w.city,
    Array.isArray(w.skills) && w.skills.length > 0,
    w.experience_years !== null && w.experience_years !== undefined &&
    w.experience_years !== "",
    !!w.availability,
    Array.isArray(w.work_modes) && w.work_modes.length > 0,
    w.salary_min !== null && w.salary_min !== undefined && w.salary_min !== "",
    !!w.cv_path,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

async function loadJobView(job: Row): Promise<Json> {
  const places = await placeNames();
  const companies = await companiesByIds([job.empresa_id]);
  return mapJob(job, companies.get(job.empresa_id) ?? null, places);
}

// ---------------------------------------------------------------------------
// Handlers de lectura
// ---------------------------------------------------------------------------
async function handleHealth(): Promise<Json> {
  return {
    status: "ok",
    version: API_VERSION,
    backend: "supabase",
    time: new Date().toISOString(),
  };
}

/**
 * `login` ya no autentica (AUTH_SUPABASE.md §5.2): Supabase Auth ya
 * autenticó al usuario antes de llamar. La app 2.10.0 no lo llama:
 * tras el sign-in de GoTrue llama directamente a `me`. Este stub
 * existe solo para que una app vieja reciba un mensaje claro.
 * Se borra en 2.11.0.
 */
async function handleLogin(body: Json): Promise<Json> {
  // Sin límite aquí: el limitador por correo no puede escribir en
  // `limites_uso` (su user_id tiene FK a `usuarios` y el UUID derivado
  // del correo no existe), así que rechazaba con 500 antes del mensaje.
  // Este stub solo rechaza; el inicio real pasa por GoTrue + `me`.
  throw new ApiError(
    "AUTH_REQUIRED",
    "Actualiza la app: inicia sesión con Supabase Auth y vuelve a intentarlo.",
    401,
  );
}

async function handleLogout(
  auth: AuthContext,
  jwt: string,
  body: Json,
): Promise<Json> {
  // Revocar el refresh token en Supabase y dar de baja el token FCM.
  try {
    await userClient(jwt).auth.signOut();
  } catch { /* best effort */ }
  if (typeof body.token === "string" && body.token) {
    await db.from("dispositivos_fcm").update({ enabled: false })
      .eq("user_id", auth.usuarioId).eq("token", body.token);
  }
  await audit(auth.usuarioId, "logout", "usuario", auth.usuarioId, null, null);
  return { loggedOut: true, usuarioId: auth.usuarioId };
}

/**
 * `registerProfile` = completar/crear el perfil de un usuario YA
 * autenticado por GoTrue (JWT obligatorio). Crea la fila en
 * `usuarios` si no existe (o la actualiza si la creó el trigger
 * handle_new_user). Sin sesión opaca: la sesión es el JWT.
 */
async function handleRegisterProfile(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, [
    "role",
    "email",
    "displayName",
    "termsAccepted",
    "phone",
    "city",
    "country",
    "headline",
    "skills",
    "experienceYears",
    "availability",
    "workModes",
    "salaryMin",
    "salaryMax",
    "provinceCode",
    "municipalityCode",
    "locality",
    "mobilityScope",
    "canRelocate",
    "remoteAvailable",
    "preferredSalaryPeriod",
    "contactHours",
    "contactPreference",
    "legalName",
    "industry",
    "size",
    "description",
    "website",
    "orgType",
  ]);
  const role = requireEnum(body, "role", ["worker", "company"]) as
    | "worker"
    | "company";
  const emailRaw = body.email !== undefined ? String(body.email) : auth.email;
  if (!isValidEmail(emailRaw)) {
    throw new ApiError("VALIDATION_ERROR", "El correo no es válido.", 400);
  }
  const email = emailRaw.trim().toLowerCase();
  if (email !== auth.email) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "El correo no coincide con la sesión de Supabase Auth.",
      400,
    );
  }
  if (body.termsAccepted !== true) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "Debes aceptar los términos y condiciones.",
      400,
    );
  }
  // Límite 5/h por usuario, como Apps Script (P3). Por usuario y no por
  // correo: el limitador por correo derivaba un UUID del correo que no
  // existe en `usuarios` y `limites_uso.user_id` tiene FK, así que cada
  // registro fallaba con 500 antes de crear el perfil (2026-11-21).
  // Aquí el usuario ya está autenticado y su fila existe (trigger).
  await consumeLimit(
    auth.usuarioId,
    "registerProfile",
    await configInt("MAX_REGISTER_PER_HOUR", 5),
    "registro",
  );

  const emailHash = await sha256Hex(email);
  const { data: byEmail } = await db.from("usuarios").select("id").eq(
    "email_hash",
    emailHash,
  ).maybeSingle();
  if (byEmail && byEmail.id !== auth.usuarioId) {
    throw new ApiError(
      "DUPLICATE",
      "Ya existe una cuenta con ese correo. Inicia sesión.",
      409,
    );
  }
  const { data: existing } = await db.from("usuarios").select("id").eq(
    "id",
    auth.usuarioId,
  ).maybeSingle();
  const isNew = !existing;
  const now = new Date().toISOString();
  let status: string;
  let displayName: string;
  if (role === "worker") {
    displayName = requireString(body, "displayName", 120);
    status = "incomplete";
  } else {
    const legalName = requireString(body, "legalName", 200);
    displayName = optionalString(body, "displayName", 200) || legalName;
    status = "pending_verification";
  }
  const userRow = {
    id: auth.usuarioId,
    email_hash: emailHash,
    email_masked: maskEmail(email),
    role,
    status,
    display_name: displayName,
    phone: optionalString(body, "phone", 40),
    last_login_at: now,
  };
  if (existing) {
    const { error } = await db.from("usuarios").update(userRow).eq(
      "id",
      auth.usuarioId,
    );
    throwIfDbError(error);
  } else {
    const { error } = await db.from("usuarios").insert({
      ...userRow,
      created_at: now,
      updated_at: now,
    });
    throwIfDbError(error);
  }

  const places = await placeNames();
  let profile: Json;
  if (role === "worker") {
    const workerRow: Row = {
      user_id: auth.usuarioId,
      headline: optionalString(body, "headline", 200),
      city: optionalString(body, "city", 120),
      country: optionalString(body, "country", 120),
      skills: optionalStringArray(body, "skills", 50, 60),
      experience_years: optionalNumber(body, "experienceYears", 0, 60),
      availability: optionalString(body, "availability", 60),
      work_modes: optionalStringArray(body, "workModes", 3, 20),
      salary_min: optionalNumber(body, "salaryMin", 0, 100000000),
      salary_max: optionalNumber(body, "salaryMax", 0, 100000000),
      phone: optionalString(body, "phone", 40),
      province_code: optionalEnum(body, "provinceCode", PROVINCE_CODES) || null,
      municipality_code: optionalString(body, "municipalityCode", 120) || null,
      locality: optionalString(body, "locality", 120),
      mobility_scope: optionalEnum(body, "mobilityScope", MOBILITY_SCOPES) ||
        null,
      can_relocate: optionalBool(body, "canRelocate"),
      remote_available: optionalBool(body, "remoteAvailable"),
      preferred_salary_period:
        optionalEnum(body, "preferredSalaryPeriod", SALARY_PERIODS) || null,
      contact_hours: optionalString(body, "contactHours", 120),
      contact_preference: optionalEnum(body, "contactPreference", [
        "whatsapp",
        "llamada",
        "correo",
      ]) || null,
    };
    if (
      workerRow.salary_min !== null && workerRow.salary_max !== null &&
      workerRow.salary_min > workerRow.salary_max
    ) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "El salario mínimo no puede ser mayor que el máximo.",
        400,
      );
    }
    workerRow.profile_percent = computeProfilePercent(workerRow);
    const { data: prev } = await db.from("perfiles_trabajador").select("id").eq(
      "user_id",
      auth.usuarioId,
    ).maybeSingle();
    if (prev) {
      const { error } = await db.from("perfiles_trabajador").update(workerRow)
        .eq("user_id", auth.usuarioId);
      throwIfDbError(error);
    } else {
      const { error } = await db.from("perfiles_trabajador").insert(workerRow);
      throwIfDbError(error);
    }
    if (workerRow.profile_percent >= 80) {
      status = "active";
      await db.from("usuarios").update({ status: "active" }).eq(
        "id",
        auth.usuarioId,
      );
    }
    const { data: fresh } = await db.from("perfiles_trabajador").select("*").eq(
      "user_id",
      auth.usuarioId,
    ).single();
    profile = mapWorkerProfile(fresh, places);
  } else {
    const companyRow: Row = {
      user_id: auth.usuarioId,
      legal_name: requireString(body, "legalName", 200),
      display_name: displayName,
      industry: optionalString(body, "industry", 120),
      size: optionalString(body, "size", 60),
      description: optionalString(body, "description", 2000),
      city: optionalString(body, "city", 120),
      website: optionalString(body, "website", 300),
      phone: optionalString(body, "phone", 40),
      province_code: optionalEnum(body, "provinceCode", PROVINCE_CODES) || null,
      municipality_code: optionalString(body, "municipalityCode", 120) || null,
      locality: optionalString(body, "locality", 120),
      contact_hours: optionalString(body, "contactHours", 120),
      org_type: optionalEnum(body, "orgType", ORG_TYPES) || null,
      verification_level: "basica",
      status: "pending_verification",
    };
    const { data: prev } = await db.from("perfiles_empresa").select("id").eq(
      "user_id",
      auth.usuarioId,
    ).maybeSingle();
    if (prev) {
      const { error } = await db.from("perfiles_empresa").update(companyRow).eq(
        "user_id",
        auth.usuarioId,
      );
      throwIfDbError(error);
    } else {
      const { error } = await db.from("perfiles_empresa").insert(companyRow);
      throwIfDbError(error);
    }
    const { data: fresh } = await db.from("perfiles_empresa").select("*").eq(
      "user_id",
      auth.usuarioId,
    ).single();
    profile = mapCompanyProfile(fresh, places);
  }
  await audit(auth.usuarioId, "register", "usuario", auth.usuarioId, null, {
    role,
    status,
  });
  return { userId: auth.usuarioId, role, status, displayName, isNew, profile };
}

async function handleMe(auth: AuthContext): Promise<Json> {
  const places = await placeNames();
  const data: Json = {
    userId: auth.usuarioId,
    role: auth.role,
    status: auth.status,
    displayName: auth.displayName,
    emailMasked: auth.emailMasked,
    phone: auth.phone,
  };
  if (auth.role === "worker") {
    const worker = await getWorkerProfile(auth.usuarioId);
    data.profile = worker ? mapWorkerProfile(worker, places) : null;
  } else if (auth.role === "company") {
    const company = await getCompanyProfile(auth.usuarioId);
    data.profile = company ? mapCompanyProfile(company, places) : null;
  } else {
    data.profile = null;
  }
  const { count } = await db.from("notificaciones").select("id", {
    count: "exact",
    head: true,
  })
    .eq("user_id", auth.usuarioId).is("read_at", null);
  data.unreadNotifications = count ?? 0;
  return data;
}

async function handleJobs(auth: AuthContext, body: Json): Promise<Json> {
  const params = body;
  const { limit, offset } = parsePagination(params);
  const filters: Row = (params.filters && typeof params.filters === "object")
    ? params.filters as Row
    : {};
  const q = normalizeText(params.q ?? filters.q ?? "");
  const category = String(params.category ?? filters.category ?? "");
  const workMode = String(params.workMode ?? filters.workMode ?? "");
  const city = normalizeText(params.city ?? filters.city ?? "");
  const provinceCode = String(
    params.provinceCode ?? filters.provinceCode ?? "",
  );
  const municipalityCode = String(
    params.municipalityCode ?? filters.municipalityCode ?? "",
  );
  const mobilityScope = String(
    params.mobilityScope ?? filters.mobilityScope ?? "",
  );
  const contractType = String(
    params.contractType ?? filters.contractType ?? "",
  );
  const minSalary = toNum(params.minSalary ?? filters.minSalary);
  const maxSalary = toNum(params.maxSalary ?? filters.maxSalary);
  const verifiedOnly = (params.verifiedOnly ?? filters.verifiedOnly) === true;
  const onlyWithSalary =
    (params.onlyWithSalary ?? filters.onlyWithSalary) === true;
  const statusFilter = String(params.status ?? filters.status ?? "");
  const sort = String(params.sort ?? filters.sort ?? "recent");

  let myCompany: Row | null = null;
  let workerProfile: Row | null = null;
  let savedJobIds = new Set<string>();
  if (auth.role === "company") {
    myCompany = await getCompanyProfile(auth.usuarioId);
  }
  if (auth.role === "worker") {
    workerProfile = await getWorkerProfile(auth.usuarioId);
    const { data: saves } = await db.from("ofertas_guardadas").select(
      "oferta_id",
    )
      .eq("user_id", auth.usuarioId).eq("active", true);
    savedJobIds = new Set((saves as Row[] ?? []).map((s) => s.oferta_id));
  }

  let query = db.from("ofertas").select("*");
  if (auth.role === "company") {
    if (!myCompany) {
      return { items: [], total: 0, hasMore: false, nextCursor: null };
    }
    query = query.eq("empresa_id", myCompany.id);
    if (statusFilter) query = query.eq("status", statusFilter);
  } else {
    query = query.eq("status", "published").or(
      `expires_at.is.null,expires_at.gt.${new Date().toISOString()}`,
    );
  }
  if (category) query = query.eq("category", category);
  if (workMode) query = query.eq("work_mode", workMode);
  if (contractType) query = query.eq("contract_type", contractType);
  if (provinceCode) query = query.eq("province_code", provinceCode);
  if (municipalityCode) query = query.eq("municipality_code", municipalityCode);
  const { data: rows, error } = await query.limit(500);
  throwIfDbError(error);
  let jobs = rows as Row[] ?? [];

  const companies = await companiesByIds(jobs.map((j) => j.empresa_id));
  jobs = jobs.filter((job) => {
    if (city && !normalizeText(job.city).includes(city)) return false;
    if (mobilityScope && auth.role === "worker" && workerProfile) {
      if (
        mobilityScope === "mi_municipio" &&
        job.municipality_code !== workerProfile.municipality_code
      ) return false;
      if (
        mobilityScope === "mi_provincia" &&
        job.province_code !== workerProfile.province_code
      ) return false;
      if (mobilityScope === "remoto" && job.work_mode !== "remoto") {
        return false;
      }
    }
    if (onlyWithSalary && job.salary_min === null && job.salary_max === null) {
      return false;
    }
    if (
      minSalary !== null && job.salary_max !== null &&
      Number(job.salary_max) < minSalary
    ) return false;
    if (
      maxSalary !== null && job.salary_min !== null &&
      Number(job.salary_min) > maxSalary
    ) return false;
    if (verifiedOnly) {
      const company = companies.get(job.empresa_id);
      if (!company || !toBool(company.verified)) return false;
    }
    if (q) {
      const company = companies.get(job.empresa_id);
      const haystack = normalizeText(
        [
          job.title,
          job.category,
          job.description,
          job.city,
          company ? company.display_name : "",
        ].join(" "),
      );
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  if (sort === "salary") {
    jobs.sort((a, b) => {
      const salA = a.salary_max !== null
        ? Number(a.salary_max)
        : (a.salary_min !== null ? Number(a.salary_min) : -1);
      const salB = b.salary_max !== null
        ? Number(b.salary_max)
        : (b.salary_min !== null ? Number(b.salary_min) : -1);
      return salB - salA;
    });
  } else if (sort === "match" && auth.role === "worker" && workerProfile) {
    jobs.sort((a, b) =>
      computeMatchScore(b, workerProfile) - computeMatchScore(a, workerProfile)
    );
  } else {
    jobs.sort((a, b) =>
      new Date(b.published_at || b.created_at).getTime() -
      new Date(a.published_at || a.created_at).getTime()
    );
  }

  const total = jobs.length;
  const places = await placeNames();
  const items = jobs.slice(offset, offset + limit).map((job) => {
    const extra: Json = {};
    if (auth.role === "worker") {
      extra.saved = savedJobIds.has(job.id);
      extra.matchScore = computeMatchScore(job, workerProfile);
    }
    return mapJob(job, companies.get(job.empresa_id) ?? null, places, extra);
  });
  return {
    items,
    total,
    hasMore: offset + limit < total,
    nextCursor: nextCursor(offset, limit, total),
  };
}

async function handleJob(auth: AuthContext, body: Json): Promise<Json> {
  const id = requireString(body, "id", 100);
  const { data: job, error } = await db.from("ofertas").select("*").eq("id", id)
    .maybeSingle();
  throwIfDbError(error);
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  const company = await getCompanyProfile(auth.usuarioId);
  const isOwner = company !== null && company.id === job.empresa_id;
  if (job.status !== "published" && !isOwner) {
    throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  }
  const places = await placeNames();
  const companies = await companiesByIds([job.empresa_id]);
  const extra: Json = {};
  if (auth.role === "worker") {
    const worker = await getWorkerProfile(auth.usuarioId);
    extra.matchScore = computeMatchScore(job, worker);
    const { data: save } = await db.from("ofertas_guardadas").select("id")
      .eq("user_id", auth.usuarioId).eq("oferta_id", id).eq("active", true)
      .maybeSingle();
    extra.saved = !!save;
    if (worker) {
      const { data: app } = await db.from("postulaciones").select("status")
        .eq("oferta_id", id).eq("trabajador_id", worker.id).maybeSingle();
      extra.applicationStatus = app ? app.status : null;
    } else {
      extra.applicationStatus = null;
    }
    const { data: similars } = await db.from("ofertas").select("*")
      .eq("status", "published").eq("category", job.category).neq("id", id)
      .order("published_at", { ascending: false }).limit(5);
    const similarCompanies = await companiesByIds(
      (similars as Row[] ?? []).map((s) => s.empresa_id),
    );
    extra.similarJobs = (similars as Row[] ?? [])
      .filter((s) => !isExpiredRow(s))
      .map((s) =>
        mapJob(s, similarCompanies.get(s.empresa_id) ?? null, places)
      );
  }
  return mapJob(job, companies.get(job.empresa_id) ?? null, places, extra);
}

async function handlePublicJob(body: Json): Promise<Json> {
  const id = requireString(body, "id", 100);
  const { data: job, error } = await db.from("ofertas").select("*").eq("id", id)
    .maybeSingle();
  throwIfDbError(error);
  if (!job || (job.status !== "published" && job.status !== "closed")) {
    throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  }
  if (job.status === "published" && isExpiredRow(job)) {
    throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  }
  const places = await placeNames();
  const companies = await companiesByIds([job.empresa_id]);
  const extra: Json = {};
  if (job.status === "closed") {
    const { data: similars } = await db.from("ofertas").select("*")
      .eq("status", "published").eq("category", job.category).neq("id", id)
      .order("published_at", { ascending: false }).limit(5);
    const similarCompanies = await companiesByIds(
      (similars as Row[] ?? []).map((s) => s.empresa_id),
    );
    extra.similarJobs = (similars as Row[] ?? [])
      .filter((s) => !isExpiredRow(s))
      .map((s) =>
        mapJob(s, similarCompanies.get(s.empresa_id) ?? null, places)
      );
  } else {
    extra.similarJobs = [];
  }
  return mapJob(job, companies.get(job.empresa_id) ?? null, places, extra);
}

async function handleListCatalogs(): Promise<Json> {
  const { data: rows, error } = await db.from("municipios").select(
    "provincia_codigo, nombre",
  )
    .eq("activo", true).order("provincia_codigo").order("nombre");
  throwIfDbError(error);
  const out: Record<string, string[]> = {};
  for (const r of (rows as Row[] ?? [])) {
    if (!out[r.provincia_codigo]) out[r.provincia_codigo] = [];
    out[r.provincia_codigo].push(r.nombre);
  }
  for (const key of Object.keys(out)) out[key].sort();
  return out;
}

async function handleApplications(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  const statusFilter = optionalString(body, "status", 50);
  const { limit, offset } = parsePagination(body);
  let worker: Row | null = null;
  let company: Row | null = null;
  let query = db.from("postulaciones").select("*");
  if (auth.role === "worker") {
    worker = await getWorkerProfile(auth.usuarioId);
    if (!worker) {
      return { items: [], total: 0, hasMore: false, nextCursor: null };
    }
    query = query.eq("trabajador_id", worker.id);
  } else if (auth.role === "company") {
    company = await getCompanyProfile(auth.usuarioId);
    if (!company) {
      return { items: [], total: 0, hasMore: false, nextCursor: null };
    }
    query = query.eq("empresa_id", company.id);
  } else {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Rol no válido para candidaturas.",
      403,
    );
  }
  if (statusFilter) query = query.eq("status", statusFilter);
  const { data: rows, error } = await query.order("created_at", {
    ascending: false,
  });
  throwIfDbError(error);
  const apps = rows as Row[] ?? [];
  const { data: jobs } = await db.from("ofertas").select("*").in(
    "id",
    apps.map((a) => a.oferta_id),
  );
  const jobsById = new Map<string, Row>(
    (jobs as Row[] ?? []).map((j) => [j.id, j]),
  );
  const { data: workers } = await db.from("perfiles_trabajador").select("*").in(
    "id",
    apps.map((a) => a.trabajador_id),
  );
  const workersById = new Map<string, Row>(
    (workers as Row[] ?? []).map((w) => [w.id, w]),
  );
  const { data: users } = await db.from("usuarios").select("id, display_name")
    .in("id", [...workersById.values()].map((w) => w.user_id));
  const usersById = new Map<string, Row>(
    (users as Row[] ?? []).map((u) => [u.id, u]),
  );
  const companies = await companiesByIds(apps.map((a) => a.empresa_id));
  const places = await placeNames();
  const total = apps.length;
  const items = apps.slice(offset, offset + limit).map((app) => {
    const job: Row = jobsById.get(app.oferta_id) ?? {};
    const workerProfile: Row | undefined = workersById.get(app.trabajador_id);
    const out: Json = {
      applicationId: app.id,
      jobId: app.oferta_id,
      jobTitle: job.title ?? "",
      jobCity: job.city ?? "",
      jobProvinceName: places.provincias.get(job.province_code ?? "") ?? "",
      jobMunicipalityName: places.municipios.get(
        `${job.province_code ?? ""}:${job.municipality_code ?? ""}`,
      ) ?? "",
      jobWorkMode: job.work_mode ?? "",
      jobStatus: job.status ?? "",
      workerId: app.trabajador_id,
      companyId: app.empresa_id,
      status: app.status,
      message: app.message ?? "",
      reminderSentAt: app.reminder_sent_at ?? "",
      createdAt: app.created_at,
      updatedAt: app.updated_at,
    };
    if (auth.role === "worker") {
      const jobCompany = companies.get(app.empresa_id);
      out.companyName = jobCompany
        ? (jobCompany.display_name || jobCompany.legal_name || "")
        : "";
      out.companyVerified = jobCompany ? toBool(jobCompany.verified) : false;
    } else {
      const workerUser = workerProfile
        ? usersById.get(workerProfile.user_id)
        : undefined;
      out.workerName = workerUser ? workerUser.display_name : "";
      out.workerHeadline = workerProfile ? workerProfile.headline : "";
      out.workerCity = workerProfile ? workerProfile.city : "";
      out.workerProvinceName = workerProfile
        ? (places.provincias.get(workerProfile.province_code ?? "") ?? "")
        : "";
      out.workerMunicipalityName = workerProfile
        ? (places.municipios.get(
          `${workerProfile.province_code ?? ""}:${
            workerProfile.municipality_code ?? ""
          }`,
        ) ?? "")
        : "";
      out.workerSkills = workerProfile && Array.isArray(workerProfile.skills)
        ? workerProfile.skills
        : [];
      out.workerExperienceYears = workerProfile
        ? toNum(workerProfile.experience_years)
        : null;
      out.matchScore = workerProfile
        ? computeMatchScore(job, workerProfile)
        : null;
      out.internalNote = app.internal_note ?? "";
      out.hasCv = !!(workerProfile && workerProfile.cv_path);
    }
    return out;
  });
  return {
    items,
    total,
    hasMore: offset + limit < total,
    nextCursor: nextCursor(offset, limit, total),
  };
}

async function handleGetRatings(body: Json): Promise<Json> {
  rejectUnknownFields(body, ["userId", "limit", "cursor"]);
  const profileId = requireString(body, "userId", 100);
  const { limit, offset } = parsePagination(body);
  const { data: rows, error } = await db.from("valoraciones").select("*")
    .eq("destinatario_perfil_id", profileId).order("created_at", { ascending: false });
  throwIfDbError(error);
  const ratings = rows as Row[] ?? [];
  const page = ratings.slice(offset, offset + limit);
  const authorUsers = await db.from("usuarios").select("id, display_name")
    .in("id", page.map((r) => r.autor_usuario_id));
  throwIfDbError(authorUsers.error);
  const names = new Map<string, string>((authorUsers.data as Row[] ?? [])
    .map((u) => [u.id, u.display_name ?? "Usuario"]));
  const applications = await db.from("postulaciones").select("id, oferta_id")
    .in("id", page.map((r) => r.postulacion_id));
  throwIfDbError(applications.error);
  const jobs = await db.from("ofertas").select("id, title")
    .in("id", (applications.data as Row[] ?? []).map((a) => a.oferta_id));
  throwIfDbError(jobs.error);
  const jobNames = new Map<string, string>((jobs.data as Row[] ?? [])
    .map((j) => [j.id, j.title ?? "Trabajo"]));
  const appJobs = new Map<string, string>((applications.data as Row[] ?? [])
    .map((a) => [a.id, jobNames.get(a.oferta_id) ?? "Trabajo"]));
  const items = page.map((r) => ({
    ratingId: r.id,
    applicationId: r.postulacion_id,
    authorId: r.autor_usuario_id,
    authorName: names.get(r.autor_usuario_id) ?? "Usuario",
    jobTitle: appJobs.get(r.postulacion_id) ?? "Trabajo",
    stars: r.stars,
    comment: r.comment ?? "",
    createdAt: r.created_at,
  }));
  const total = ratings.length;
  const average = total === 0
    ? 0
    : ratings.reduce((sum, r) => sum + Number(r.stars || 0), 0) / total;
  return {
    userId: profileId,
    average: Math.round(average * 100) / 100,
    total,
    ratings: items,
    hasMore: offset + limit < total,
    nextCursor: nextCursor(offset, limit, total),
  };
}

async function handleRateApplication(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["applicationId", "stars", "comment"]);
  const applicationId = requireString(body, "applicationId", 100);
  const stars = optionalNumber(body, "stars", 1, 5);
  if (stars === null || !Number.isInteger(stars)) {
    throw new ApiError("VALIDATION_ERROR", "Las estrellas deben ser un entero de 1 a 5.", 400);
  }
  const comment = optionalString(body, "comment", 1000);
  const { data: app, error } = await db.from("postulaciones").select("*")
    .eq("id", applicationId).maybeSingle();
  throwIfDbError(error);
  if (!app) throw new ApiError("NOT_FOUND", "La candidatura no existe.", 404);
  if (app.status !== "hired") {
    throw new ApiError("CONFLICT", "Solo se puede valorar una candidatura contratada.", 409);
  }
  const worker = await getWorkerProfile(auth.usuarioId);
  const company = await getCompanyProfile(auth.usuarioId);
  let authorProfileId = "";
  let recipientProfileId = "";
  if (auth.role === "worker" && worker && app.trabajador_id === worker.id) {
    authorProfileId = worker.id;
    recipientProfileId = app.empresa_id;
  } else if (auth.role === "company" && company && app.empresa_id === company.id) {
    authorProfileId = company.id;
    recipientProfileId = app.trabajador_id;
  } else {
    throw new ApiError("FORBIDDEN_ROLE", "No puedes valorar esta candidatura con esta cuenta.", 403);
  }
  const { data: inserted, error: insertError } = await db.from("valoraciones").insert({
    postulacion_id: applicationId,
    autor_usuario_id: auth.usuarioId,
    autor_perfil_id: authorProfileId,
    destinatario_perfil_id: recipientProfileId,
    stars,
    comment,
  }).select().single();
  if (insertError) {
    if (insertError.code === "23505") {
      throw new ApiError("CONFLICT", "Ya valoraste esta candidatura.", 409);
    }
    throwIfDbError(insertError);
  }
  const { data: all, error: allError } = await db.from("valoraciones")
    .select("stars").eq("destinatario_perfil_id", recipientProfileId);
  throwIfDbError(allError);
  const received = all as Row[] ?? [];
  const average = received.length === 0 ? 0
    : received.reduce((sum, r) => sum + Number(r.stars || 0), 0) / received.length;
  await audit(auth.usuarioId, "rate_application", "postulacion", applicationId, null, { stars });
  return {
    ratingId: inserted.id,
    applicationId,
    average: Math.round(average * 100) / 100,
    total: received.length,
  };
}

async function handleNotifications(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  const unreadOnly = body.unreadOnly === true || body.unreadOnly === "true";
  const { limit, offset } = parsePagination(body);
  let query = db.from("notificaciones").select("*").eq(
    "user_id",
    auth.usuarioId,
  );
  if (unreadOnly) query = query.is("read_at", null);
  const { data: rows, error } = await query.order("created_at", {
    ascending: false,
  });
  throwIfDbError(error);
  const all = rows as Row[] ?? [];
  const { count: unread } = await db.from("notificaciones").select("id", {
    count: "exact",
    head: true,
  })
    .eq("user_id", auth.usuarioId).is("read_at", null);
  const total = all.length;
  return {
    items: all.slice(offset, offset + limit).map(mapNotification),
    total,
    hasMore: offset + limit < total,
    nextCursor: nextCursor(offset, limit, total),
    unread: unread ?? 0,
    unreadCount: unread ?? 0,
  };
}

async function handleListFilters(auth: AuthContext): Promise<Json> {
  const { data: rows, error } = await db.from("filtros_guardados").select("*")
    .eq("user_id", auth.usuarioId);
  throwIfDbError(error);
  const items = (rows as Row[] ?? []).map(mapFilter);
  return { items, total: items.length };
}

async function handleSync(auth: AuthContext, body: Json): Promise<Json> {
  const sinceParam = optionalString(body, "since", 100);
  const since = sinceParam ? new Date(sinceParam).getTime() : 0;
  if (Number.isNaN(since)) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "El parámetro since no es una fecha válida.",
      400,
    );
  }
  const offset = Math.max(0, parseInt(String(body.offset ?? "0"), 10) || 0);
  const serverTime = new Date().toISOString();
  const isNewer = (iso: unknown) => {
    if (!iso) return false;
    const t = new Date(String(iso)).getTime();
    return !Number.isNaN(t) && t > since;
  };
  let jobs: Row[] = [];
  let worker: Row | null = null;
  let myCompany: Row | null = null;
  if (auth.role === "worker") {
    worker = await getWorkerProfile(auth.usuarioId);
    const { data } = await db.from("ofertas").select("*").eq(
      "status",
      "published",
    );
    jobs = (data as Row[] ?? []).filter((j) =>
      !isExpiredRow(j) && isNewer(j.updated_at)
    );
  } else if (auth.role === "company") {
    myCompany = await getCompanyProfile(auth.usuarioId);
    if (myCompany) {
      const { data } = await db.from("ofertas").select("*").eq(
        "empresa_id",
        myCompany.id,
      );
      jobs = (data as Row[] ?? []).filter((j) => isNewer(j.updated_at));
    }
  }
  const { data: appRows } = await db.from("postulaciones").select("*");
  const applications = (appRows as Row[] ?? []).filter((app) => {
    if (!isNewer(app.updated_at)) return false;
    if (worker) return app.trabajador_id === worker.id;
    if (myCompany) return app.empresa_id === myCompany.id;
    return false;
  });
  const { data: noteRows } = await db.from("notificaciones").select("*").eq(
    "user_id",
    auth.usuarioId,
  );
  const notifications = (noteRows as Row[] ?? []).filter((n) =>
    isNewer(n.created_at)
  );
  const places = await placeNames();
  const companies = await companiesByIds(jobs.map((j) => j.empresa_id));
  return {
    serverTime,
    jobs: jobs.slice(offset, offset + 100).map((j) =>
      mapJob(j, companies.get(j.empresa_id) ?? null, places)
    ),
    applications: applications.slice(offset, offset + 100).map((app) => ({
      applicationId: app.id,
      jobId: app.oferta_id,
      workerId: app.trabajador_id,
      companyId: app.empresa_id,
      status: app.status,
      message: app.message,
      createdAt: app.created_at,
      updatedAt: app.updated_at,
      lastNotifiedAt: app.last_notified_at,
    })),
    notifications: notifications.slice(offset, offset + 100).map(
      mapNotification,
    ),
    hasMore: jobs.length > offset + 100 || applications.length > offset + 100 ||
      notifications.length > offset + 100,
  };
}

/** Contexto de contacto: existe la entidad y ¿puede ver el número? */
async function contactContext(
  auth: AuthContext,
  entityType: string,
  entityId: string,
): Promise<{ targetUserId: string; authorized: boolean; job: Row | null }> {
  if (
    entityType !== "job" && entityType !== "company" && entityType !== "worker"
  ) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "entityType debe ser job, company o worker.",
      400,
    );
  }
  if (!entityId) {
    throw new ApiError("VALIDATION_ERROR", "Falta el parámetro entityId.", 400);
  }
  let targetUserId: string | null = null;
  let job: Row | null = null;
  if (entityType === "job") {
    const { data } = await db.from("ofertas").select("*").eq("id", entityId)
      .maybeSingle();
    if (!data) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
    job = data;
    const { data: jobCompany } = await db.from("perfiles_empresa").select("*")
      .eq("id", data.empresa_id).maybeSingle();
    if (!jobCompany) {
      throw new ApiError("NOT_FOUND", "Empresa no encontrada.", 404);
    }
    targetUserId = jobCompany.user_id;
    if (data.status !== "published" && targetUserId !== auth.usuarioId) {
      throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
    }
  } else if (entityType === "company") {
    const { data } = await db.from("perfiles_empresa").select("*").eq(
      "id",
      entityId,
    ).maybeSingle();
    if (!data) throw new ApiError("NOT_FOUND", "Empresa no encontrada.", 404);
    targetUserId = data.user_id;
  } else {
    const { data } = await db.from("perfiles_trabajador").select("*").eq(
      "id",
      entityId,
    ).maybeSingle();
    if (!data) {
      throw new ApiError("NOT_FOUND", "Trabajador no encontrado.", 404);
    }
    targetUserId = data.user_id;
  }
  let authorized = targetUserId === auth.usuarioId;
  const activeStatuses = ["sent", "reviewing", "interview", "hired"];
  if (!authorized) {
    if (entityType === "job") {
      const worker = await getWorkerProfile(auth.usuarioId);
      if (worker) {
        const { data } = await db.from("postulaciones").select("id").eq(
          "trabajador_id",
          worker.id,
        )
          .eq("oferta_id", entityId).in("status", activeStatuses).maybeSingle();
        authorized = !!data;
      }
    } else if (entityType === "company") {
      const worker = await getWorkerProfile(auth.usuarioId);
      if (worker) {
        const { data } = await db.from("postulaciones").select("id").eq(
          "trabajador_id",
          worker.id,
        )
          .eq("empresa_id", entityId).in("status", activeStatuses)
          .maybeSingle();
        authorized = !!data;
      }
    } else {
      const myCompany = await getCompanyProfile(auth.usuarioId);
      if (myCompany) {
        const { data } = await db.from("postulaciones").select("id").eq(
          "trabajador_id",
          entityId,
        )
          .eq("empresa_id", myCompany.id).in("status", activeStatuses)
          .maybeSingle();
        authorized = !!data;
      }
    }
  }
  return { targetUserId: targetUserId!, authorized, job };
}

async function handleContactOptions(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  const entityType = requireEnum(body, "entityType", [
    "job",
    "company",
    "worker",
  ]);
  const entityId = requireString(body, "entityId", 100);
  const { targetUserId, authorized, job } = await contactContext(
    auth,
    entityType,
    entityId,
  );
  const { data: prefs } = await db.from("contacto_preferencias").select("*").eq(
    "user_id",
    targetUserId,
  ).maybeSingle();
  const whatsappEnabled = prefs ? toBool(prefs.whatsapp_enabled) : false;
  const phoneEnabled = prefs ? toBool(prefs.phone_enabled) : false;
  const publicPhone = prefs ? String(prefs.public_phone || "") : "";
  const masked = publicPhone ? publicPhone.replace(/.(?=.{4})/g, "*") : "";
  let contactHours = "";
  if (entityType === "job" && job) {
    const { data: c } = await db.from("perfiles_empresa").select(
      "contact_hours",
    ).eq("id", job.empresa_id).maybeSingle();
    contactHours = c?.contact_hours ?? "";
  } else if (entityType === "company") {
    const { data: c } = await db.from("perfiles_empresa").select(
      "contact_hours",
    ).eq("id", entityId).maybeSingle();
    contactHours = c?.contact_hours ?? "";
  } else {
    const { data: w } = await db.from("perfiles_trabajador").select(
      "contact_hours",
    ).eq("id", entityId).maybeSingle();
    contactHours = w?.contact_hours ?? "";
  }
  return {
    entityType,
    entityId,
    whatsappEnabled,
    phoneEnabled,
    phoneMasked: masked,
    phone: authorized && phoneEnabled ? publicPhone : null,
    whatsappUrl: authorized && whatsappEnabled && publicPhone
      ? `https://wa.me/${publicPhone.replace(/[^0-9]/g, "")}`
      : null,
    contactPolicy: prefs
      ? (prefs.contact_policy || "in_app_first")
      : "in_app_first",
    contactHours,
  };
}

// ---------------------------------------------------------------------------
// Handlers de escritura: perfil y ofertas
// ---------------------------------------------------------------------------
async function handleUpdateProfile(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, [
    "displayName",
    "phone",
    "headline",
    "city",
    "country",
    "skills",
    "experienceYears",
    "availability",
    "workModes",
    "salaryMin",
    "salaryMax",
    "provinceCode",
    "municipalityCode",
    "locality",
    "mobilityScope",
    "canRelocate",
    "remoteAvailable",
    "preferredSalaryPeriod",
    "contactHours",
    "contactPreference",
    "legalName",
    "industry",
    "size",
    "description",
    "website",
    "orgType",
    "whatsappEnabled",
    "phoneEnabled",
    "publicPhone",
    "contactPolicy",
    "expectedUpdatedAt",
  ]);
  const now = new Date().toISOString();
  const displayName = body.displayName !== undefined
    ? requireString(body, "displayName", 120)
    : null;
  const userPatch: Row = { updated_at: now };
  if (displayName) userPatch.display_name = displayName;
  if (body.phone !== undefined) {
    userPatch.phone = optionalString(body, "phone", 40);
  }
  const { error: uErr } = await db.from("usuarios").update(userPatch).eq(
    "id",
    auth.usuarioId,
  );
  throwIfDbError(uErr);

  // Preferencias de contacto (si viene alguna).
  if (
    body.whatsappEnabled !== undefined || body.phoneEnabled !== undefined ||
    body.publicPhone !== undefined || body.contactPolicy !== undefined
  ) {
    const prefs: Row = { user_id: auth.usuarioId };
    if (body.whatsappEnabled !== undefined) {
      prefs.whatsapp_enabled = optionalBool(body, "whatsappEnabled");
    }
    if (body.phoneEnabled !== undefined) {
      prefs.phone_enabled = optionalBool(body, "phoneEnabled");
    }
    if (body.publicPhone !== undefined) {
      prefs.public_phone = optionalString(body, "publicPhone", 40);
    }
    if (body.contactPolicy !== undefined) {
      prefs.contact_policy = requireEnum(body, "contactPolicy", [
        "in_app_first",
        "direct",
      ]);
    }
    const { error } = await db.from("contacto_preferencias").upsert(prefs, {
      onConflict: "user_id",
    });
    throwIfDbError(error);
  }

  const places = await placeNames();
  if (auth.role === "worker") {
    const worker = await getWorkerProfile(auth.usuarioId);
    if (!worker) {
      throw new ApiError(
        "NOT_FOUND",
        "Perfil de trabajador no encontrado.",
        404,
      );
    }
    if (
      body.expectedUpdatedAt && worker.updated_at !== body.expectedUpdatedAt
    ) {
      throw new ApiError(
        "CONFLICT",
        "El perfil cambió desde tu última lectura. Recarga y reintenta.",
        409,
      );
    }
    const patch: Row = { updated_at: now };
    const strFields: Array<[string, string, number]> = [
      ["headline", "headline", 200],
      ["city", "city", 120],
      ["country", "country", 120],
      ["availability", "availability", 120],
      ["phone", "phone", 40],
      ["municipalityCode", "municipality_code", 120],
      ["locality", "locality", 120],
      ["contactHours", "contact_hours", 120],
    ];
    for (const [bodyField, col, max] of strFields) {
      if (body[bodyField] !== undefined) {
        patch[col] = optionalString(body, bodyField, max);
      }
    }
    if (body.provinceCode !== undefined) {
      patch.province_code =
        optionalEnum(body, "provinceCode", PROVINCE_CODES) || null;
    }
    if (body.mobilityScope !== undefined) {
      patch.mobility_scope =
        optionalEnum(body, "mobilityScope", MOBILITY_SCOPES) || null;
    }
    if (body.preferredSalaryPeriod !== undefined) {
      patch.preferred_salary_period =
        optionalEnum(body, "preferredSalaryPeriod", SALARY_PERIODS) || null;
    }
    if (body.contactPreference !== undefined) {
      patch.contact_preference = optionalEnum(body, "contactPreference", [
        "whatsapp",
        "llamada",
        "correo",
      ]) || null;
    }
    if (body.canRelocate !== undefined) {
      patch.can_relocate = optionalBool(body, "canRelocate");
    }
    if (body.remoteAvailable !== undefined) {
      patch.remote_available = optionalBool(body, "remoteAvailable");
    }
    if (body.skills !== undefined) {
      patch.skills = optionalStringArray(body, "skills", 50, 60);
    }
    if (body.workModes !== undefined) {
      patch.work_modes = optionalStringArray(body, "workModes", 3, 20);
    }
    if (body.experienceYears !== undefined) {
      patch.experience_years = optionalNumber(body, "experienceYears", 0, 60);
    }
    if (body.salaryMin !== undefined) {
      patch.salary_min = optionalNumber(body, "salaryMin", 0, 100000000);
    }
    if (body.salaryMax !== undefined) {
      patch.salary_max = optionalNumber(body, "salaryMax", 0, 100000000);
    }
    const { data: updated, error } = await db.from("perfiles_trabajador")
      .update(patch).eq("id", worker.id).select().single();
    throwIfDbError(error);
    const percent = computeProfilePercent(updated);
    await db.from("perfiles_trabajador").update({ profile_percent: percent })
      .eq("id", worker.id);
    updated.profile_percent = percent;
    let newStatus = auth.status;
    if (auth.status === "incomplete" && percent >= 80) {
      await db.from("usuarios").update({ status: "active" }).eq(
        "id",
        auth.usuarioId,
      );
      newStatus = "active";
    }
    await audit(
      auth.usuarioId,
      "update_profile",
      "perfil_trabajador",
      worker.id,
      null,
      null,
    );
    return { profile: mapWorkerProfile(updated, places), status: newStatus };
  }

  if (auth.role === "company") {
    const company = await getCompanyProfile(auth.usuarioId);
    if (!company) {
      throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
    }
    if (
      body.expectedUpdatedAt && company.updated_at !== body.expectedUpdatedAt
    ) {
      throw new ApiError(
        "CONFLICT",
        "El perfil cambió desde tu última lectura. Recarga y reintenta.",
        409,
      );
    }
    const patch: Row = { updated_at: now };
    const strFields: Array<[string, string, number]> = [
      ["legalName", "legal_name", 200],
      ["industry", "industry", 120],
      ["size", "size", 60],
      ["description", "description", 2000],
      ["city", "city", 120],
      ["website", "website", 300],
      ["phone", "phone", 40],
      ["municipalityCode", "municipality_code", 120],
      ["locality", "locality", 120],
      ["contactHours", "contact_hours", 120],
    ];
    for (const [bodyField, col, max] of strFields) {
      if (body[bodyField] !== undefined) {
        patch[col] = optionalString(body, bodyField, max);
      }
    }
    if (body.provinceCode !== undefined) {
      patch.province_code =
        optionalEnum(body, "provinceCode", PROVINCE_CODES) || null;
    }
    if (body.orgType !== undefined) {
      patch.org_type = optionalEnum(body, "orgType", ORG_TYPES) || null;
    }
    if (displayName) patch.display_name = displayName;
    const { data: updated, error } = await db.from("perfiles_empresa").update(
      patch,
    ).eq("id", company.id).select().single();
    throwIfDbError(error);
    await audit(
      auth.usuarioId,
      "update_profile",
      "perfil_empresa",
      company.id,
      null,
      null,
    );
    return { profile: mapCompanyProfile(updated, places), status: auth.status };
  }
  throw new ApiError(
    "FORBIDDEN_ROLE",
    "Rol no válido para actualizar perfil.",
    403,
  );
}

/** Valida y normaliza los campos de una oferta (borrador o publicación). */
function parseJobFields(body: Json, forPublish: boolean): Row {
  const fields: Row = {};
  if (body.title !== undefined) {
    fields.title = requireString(body, "title", 200);
  }
  if (body.category !== undefined) {
    fields.category = requireString(body, "category", 120);
  }
  if (body.description !== undefined) {
    fields.description = optionalString(body, "description", 10000);
  }
  if (body.responsibilities !== undefined) {
    fields.responsibilities = optionalStringArray(
      body,
      "responsibilities",
      30,
      500,
    );
  }
  if (body.benefits !== undefined) {
    fields.benefits = optionalStringArray(body, "benefits", 30, 500);
  }
  if (body.city !== undefined) fields.city = optionalString(body, "city", 120);
  if (body.provinceCode !== undefined) {
    fields.province_code = optionalEnum(body, "provinceCode", PROVINCE_CODES) ||
      null;
  }
  if (body.municipalityCode !== undefined) {
    fields.municipality_code = optionalString(body, "municipalityCode", 120) ||
      null;
  }
  if (body.locality !== undefined) {
    fields.locality = optionalString(body, "locality", 120);
  }
  if (body.workMode !== undefined) {
    fields.work_mode = requireEnum(body, "workMode", [
      "presencial",
      "hibrido",
      "remoto",
      "por_zonas",
    ]);
  }
  if (body.contractType !== undefined) {
    fields.contract_type = requireEnum(body, "contractType", [
      "indefinido",
      "temporal",
      "por_proyecto",
      "practicas",
      "medio_tiempo",
      "tiempo_completo",
    ]);
  }
  if (body.salaryMin !== undefined) {
    fields.salary_min = optionalNumber(body, "salaryMin", 0, 100000000);
  }
  if (body.salaryMax !== undefined) {
    fields.salary_max = optionalNumber(body, "salaryMax", 0, 100000000);
  }
  if (body.salaryPeriod !== undefined) {
    fields.salary_period = optionalEnum(body, "salaryPeriod", SALARY_PERIODS) ||
      "mensual";
  }
  if (body.includesFood !== undefined) {
    fields.includes_food = optionalBool(body, "includesFood");
  }
  if (body.includesTransport !== undefined) {
    fields.includes_transport = optionalBool(body, "includesTransport");
  }
  if (body.includesAccommodation !== undefined) {
    fields.includes_accommodation = optionalBool(body, "includesAccommodation");
  }
  if (body.includesTips !== undefined) {
    fields.includes_tips = optionalBool(body, "includesTips");
  }
  if (body.paymentNotes !== undefined) {
    fields.payment_notes = optionalString(body, "paymentNotes", 500);
  }
  if (body.contactHours !== undefined) {
    fields.contact_hours = optionalString(body, "contactHours", 120);
  }
  if (body.startDate !== undefined) {
    fields.start_date = optionalString(body, "startDate", 20) || null;
  }
  if (body.expiresAt !== undefined) {
    fields.expires_at = optionalIsoDate(body, "expiresAt") || null;
  }

  const requirements: Row = {};
  let hasRequirements = false;
  if (body.requirements !== undefined) {
    requirements.skills = optionalStringArray(body, "requirements", 50, 60);
    hasRequirements = true;
  }
  if (body.experienceMin !== undefined) {
    requirements.experienceMin = optionalNumber(body, "experienceMin", 0, 60);
    hasRequirements = true;
  }
  if (body.languages !== undefined) {
    requirements.languages = optionalStringArray(body, "languages", 10, 60);
    hasRequirements = true;
  }
  if (body.keywords !== undefined) {
    requirements.keywords = optionalStringArray(body, "keywords", 30, 60);
    hasRequirements = true;
  }
  if (hasRequirements) fields.requirements = requirements;

  if (forPublish) {
    const missing = [
      "title",
      "category",
      "description",
      "workMode",
      "contractType",
    ].filter((f) => !fields[f]);
    if (missing.length > 0) {
      throw new ApiError(
        "VALIDATION_ERROR",
        `Faltan campos obligatorios para publicar: ${missing.join(", ")}`,
        400,
      );
    }
  }
  validateSalaryRange(fields.salary_min, fields.salary_max);
  return fields;
}

function validateSalaryRange(salaryMin: unknown, salaryMax: unknown): void {
  if (
    salaryMin === undefined || salaryMin === null || salaryMin === "" ||
    salaryMax === undefined || salaryMax === null || salaryMax === ""
  ) return;
  if (Number(salaryMin) > Number(salaryMax)) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "El salario mínimo no puede ser mayor que el máximo.",
      400,
    );
  }
}

async function handleCreateJob(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, [
    "title",
    "category",
    "description",
    "responsibilities",
    "requirements",
    "benefits",
    "city",
    "provinceCode",
    "municipalityCode",
    "locality",
    "workMode",
    "contractType",
    "salaryMin",
    "salaryMax",
    "salaryPeriod",
    "includesFood",
    "includesTransport",
    "includesAccommodation",
    "includesTips",
    "paymentNotes",
    "contactHours",
    "startDate",
    "expiresAt",
    "experienceMin",
    "languages",
    "keywords",
  ]);
  requireRole(auth, "company");
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  const title = requireString(body, "title", 200);
  const fields = parseJobFields(body, false);
  fields.title = title;
  await consumeLimit(
    auth.usuarioId,
    "createJob",
    await configInt("MAX_JOBS_PER_HOUR", 10),
    "creación de ofertas",
  );
  const now = new Date().toISOString();
  const { data: job, error } = await db.from("ofertas").insert({
    empresa_id: company.id,
    title: fields.title,
    category: fields.category ?? "",
    description: fields.description ?? "",
    responsibilities: fields.responsibilities ?? [],
    requirements: fields.requirements ?? {},
    benefits: fields.benefits ?? [],
    city: fields.city ?? "",
    work_mode: fields.work_mode ?? null,
    contract_type: fields.contract_type ?? null,
    salary_min: fields.salary_min ?? null,
    salary_max: fields.salary_max ?? null,
    salary_period: fields.salary_period ?? "mensual",
    province_code: fields.province_code ?? null,
    municipality_code: fields.municipality_code ?? null,
    locality: fields.locality ?? "",
    includes_food: fields.includes_food ?? false,
    includes_transport: fields.includes_transport ?? false,
    includes_accommodation: fields.includes_accommodation ?? false,
    includes_tips: fields.includes_tips ?? false,
    payment_notes: fields.payment_notes ?? "",
    contact_hours: fields.contact_hours ?? "",
    start_date: fields.start_date ?? null,
    expires_at: fields.expires_at ?? null,
    status: "draft",
    created_by: auth.usuarioId,
    created_at: now,
    updated_at: now,
  }).select().single();
  throwIfDbError(error);
  await audit(auth.usuarioId, "create_job", "oferta", job.id, null, {
    title: job.title,
    status: "draft",
  });
  return { job: await loadJobView(job) };
}

/** Transición centralizada a "published": valida, actualiza, audita y ejecuta el matching una sola vez. */
async function publishJobTransition(
  job: Row,
  company: Row,
  userId: string,
): Promise<Json> {
  const missing = [
    "title",
    "category",
    "description",
    "work_mode",
    "contract_type",
  ].filter((f) => !job[f]);
  if (missing.length > 0) {
    throw new ApiError(
      "VALIDATION_ERROR",
      `Faltan campos obligatorios para publicar: ${missing.join(", ")}`,
      400,
    );
  }
  const now = new Date().toISOString();
  const { data: updated, error } = await db.from("ofertas")
    .update({ status: "published", published_at: now, updated_at: now }).eq(
      "id",
      job.id,
    ).select().single();
  throwIfDbError(error);
  await audit(userId, "publish_job", "oferta", job.id, { status: job.status }, {
    status: "published",
  });
  const notified = await runMatchingForJob(updated);
  return { job: await loadJobView(updated), workersNotified: notified };
}

async function handlePublishJob(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["jobId"]);
  requireRole(auth, "company");
  if (auth.status !== "active") {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "La empresa debe estar verificada y activa para publicar.",
      403,
    );
  }
  const jobId = requireString(body, "jobId", 100);
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  const { data: job, error } = await db.from("ofertas").select("*").eq(
    "id",
    jobId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  if (job.empresa_id !== company.id) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede publicar esta oferta.",
      403,
    );
  }
  if (job.status !== "draft" && job.status !== "paused") {
    throw new ApiError(
      "CONFLICT",
      "Solo un borrador o una oferta pausada puede publicarse.",
      409,
    );
  }
  await consumeLimit(
    auth.usuarioId,
    "publishJob",
    await configInt("MAX_JOBS_PER_HOUR", 10),
    "publicación de ofertas",
  );
  return publishJobTransition(job, company, auth.usuarioId);
}

async function handleUpdateJob(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, [
    "jobId",
    "title",
    "category",
    "description",
    "responsibilities",
    "requirements",
    "benefits",
    "city",
    "provinceCode",
    "municipalityCode",
    "locality",
    "workMode",
    "contractType",
    "salaryMin",
    "salaryMax",
    "salaryPeriod",
    "includesFood",
    "includesTransport",
    "includesAccommodation",
    "includesTips",
    "paymentNotes",
    "contactHours",
    "startDate",
    "expiresAt",
    "experienceMin",
    "languages",
    "keywords",
  ]);
  requireRole(auth, "company");
  const jobId = requireString(body, "jobId", 100);
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  const fields = parseJobFields(body, false);
  // Fusionar requisitos con los existentes (no sobrescribir en silencio).
  const { data: current } = await db.from("ofertas").select("*").eq("id", jobId)
    .maybeSingle();
  if (!current) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  if (current.empresa_id !== company.id) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede editar esta oferta.",
      403,
    );
  }
  if (current.status === "closed") {
    throw new ApiError(
      "CONFLICT",
      "Una oferta cerrada no puede editarse.",
      409,
    );
  }
  if (fields.requirements !== undefined) {
    const merged: Row =
      (current.requirements && typeof current.requirements === "object")
        ? { ...current.requirements }
        : {};
    Object.assign(merged, fields.requirements);
    fields.requirements = merged;
  }
  const effMin = fields.salary_min !== undefined && fields.salary_min !== null
    ? fields.salary_min
    : current.salary_min;
  const effMax = fields.salary_max !== undefined && fields.salary_max !== null
    ? fields.salary_max
    : current.salary_max;
  validateSalaryRange(effMin, effMax);
  // Mapear nombres camelCase de parseJobFields a columnas snake_case.
  const patch: Row = { updated_at: new Date().toISOString() };
  for (const [k, v] of Object.entries(fields)) patch[k] = v;
  const { data: updated, error } = await db.from("ofertas").update(patch).eq(
    "id",
    jobId,
  ).select().single();
  throwIfDbError(error);
  await audit(auth.usuarioId, "update_job", "oferta", jobId, {
    title: current.title,
    status: current.status,
  }, { title: updated.title, status: updated.status });
  return { job: await loadJobView(updated) };
}

async function handleChangeJobStatus(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["jobId", "status"]);
  requireRole(auth, "company");
  const jobId = requireString(body, "jobId", 100);
  const newStatus = requireEnum(body, "status", [
    "published",
    "paused",
    "closed",
  ]);
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  const { data: job, error } = await db.from("ofertas").select("*").eq(
    "id",
    jobId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  if (job.empresa_id !== company.id) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede cambiar el estado de esta oferta.",
      403,
    );
  }
  const allowed = JOB_STATUS_TRANSITIONS[job.status] || [];
  if (!allowed.includes(newStatus)) {
    throw new ApiError(
      "CONFLICT",
      `No se puede pasar de ${job.status} a ${newStatus}.`,
      409,
    );
  }
  if (newStatus === "published") {
    if (auth.status !== "active") {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "La empresa debe estar verificada y activa para publicar.",
        403,
      );
    }
    return publishJobTransition(job, company, auth.usuarioId);
  }
  const { data: updated, error: uErr } = await db.from("ofertas")
    .update({ status: newStatus, updated_at: new Date().toISOString() }).eq(
      "id",
      jobId,
    ).select().single();
  throwIfDbError(uErr);
  await audit(auth.usuarioId, "change_job_status", "oferta", jobId, {
    status: job.status,
  }, { status: newStatus });
  return { job: await loadJobView(updated) };
}

async function handleArchiveJob(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["jobId", "reason"]);
  requireRole(auth, "company");
  const jobId = requireString(body, "jobId", 100);
  const reason = optionalString(body, "reason", 200);
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  const { data: job, error } = await db.from("ofertas").select("*").eq(
    "id",
    jobId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  if (job.empresa_id !== company.id) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede archivar esta oferta.",
      403,
    );
  }
  if (job.status === "draft") {
    throw new ApiError(
      "CONFLICT",
      "Un borrador no se archiva: elimínalo si ya no lo necesitas.",
      409,
    );
  }
  if (job.status === "archived") {
    throw new ApiError("CONFLICT", "Esta oferta ya está archivada.", 409);
  }
  const now = new Date().toISOString();
  const { data: updated, error: uErr } = await db.from("ofertas")
    .update({
      status: "archived",
      archived_at: now,
      archive_reason: reason,
      updated_at: now,
    }).eq("id", jobId).select().single();
  throwIfDbError(uErr);
  await audit(auth.usuarioId, "archive_job", "oferta", jobId, {
    status: job.status,
  }, { status: "archived" });
  return { job: await loadJobView(updated) };
}

async function handleDeleteJob(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["jobId"]);
  requireRole(auth, "company");
  const jobId = requireString(body, "jobId", 100);
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  const { data: job, error } = await db.from("ofertas").select("*").eq(
    "id",
    jobId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  if (job.empresa_id !== company.id) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede eliminar esta oferta.",
      403,
    );
  }
  if (job.status !== "draft") {
    throw new ApiError(
      "CONFLICT",
      "Solo se puede eliminar un borrador. Cierra o archiva esta oferta.",
      409,
    );
  }
  const { count } = await db.from("postulaciones").select("id", {
    count: "exact",
    head: true,
  }).eq("oferta_id", jobId);
  if ((count ?? 0) > 0) {
    throw new ApiError(
      "CONFLICT",
      "Este borrador ya tiene candidaturas; archívalo en su lugar.",
      409,
    );
  }
  const { error: dErr } = await db.from("ofertas").delete().eq("id", jobId);
  throwIfDbError(dErr);
  await audit(auth.usuarioId, "delete_job", "oferta", jobId, {
    title: job.title,
    status: "draft",
  }, null);
  return { deleted: true };
}

// ---------------------------------------------------------------------------
// Handlers de escritura: candidaturas y guardados
// ---------------------------------------------------------------------------
async function handleExpressInterest(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["jobId", "message", "clientActionId"]);
  requireRole(auth, "worker");
  if (auth.status !== "active" && auth.status !== "incomplete") {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "El perfil no está habilitado para expresar interés.",
      403,
    );
  }
  const jobId = requireString(body, "jobId", 100);
  const message = optionalString(body, "message", 1000);
  const worker = await getWorkerProfile(auth.usuarioId);
  if (!worker) {
    throw new ApiError("NOT_FOUND", "Perfil de trabajador no encontrado.", 404);
  }
  // S-05: la empresa debe estar activa y el trabajador no puede ser el dueño.
  const { data: job } = await db.from("ofertas").select(
    "id, empresa_id, title, status",
  ).eq("id", jobId).maybeSingle();
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  const { data: jobCompany } = await db.from("perfiles_empresa").select(
    "id, user_id, status",
  ).eq("id", job.empresa_id).maybeSingle();
  if (!jobCompany) {
    throw new ApiError("NOT_FOUND", "Empresa no encontrada.", 404);
  }
  if (jobCompany.user_id === auth.usuarioId) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "No puedes postular a tu propia oferta.",
      403,
    );
  }
  if (jobCompany.status !== "active") {
    throw new ApiError(
      "CONFLICT",
      "La empresa de esta oferta no está activa.",
      409,
    );
  }
  // Límite por hora (atómico en Postgres). Cuenta intentos, no solo altas.
  await consumeLimit(
    auth.usuarioId,
    "expressInterest",
    MAX_INTERESTS_PER_HOUR,
    "expresiones de interés",
  );
  const { data, error } = await db.rpc("expresar_interes", {
    p_oferta: jobId,
    p_trabajador: worker.id,
    p_mensaje: message,
  });
  throwIfDbError(error);
  const result = data as Row;
  // Reactivar un interés retirado (Code.gs): withdrawn -> sent.
  if (result.alreadyExpressed === true && result.status === "withdrawn") {
    const { data: reactivated, error: rErr } = await db.from("postulaciones")
      .update({ status: "sent", message, updated_at: new Date().toISOString() })
      .eq("id", result.applicationId).select().single();
    throwIfDbError(rErr);
    await createNotification(
      jobCompany.user_id,
      "worker_interested",
      `Nuevo interés en «${job.title}»`,
      `${auth.displayName || "Un trabajador"} expresó interés en tu oferta.`,
      result.applicationId,
      `application/${result.applicationId}`,
    );
    await audit(
      auth.usuarioId,
      "express_interest",
      "postulacion",
      result.applicationId,
      null,
      { jobId, status: "sent", reactivated: true },
    );
    return {
      applicationId: result.applicationId,
      jobId,
      status: "sent",
      alreadyExpressed: false,
      createdAt: reactivated.created_at,
    };
  }
  if (result.alreadyExpressed === false) {
    await createNotification(
      jobCompany.user_id,
      "worker_interested",
      `Nuevo interés en «${job.title}»`,
      `${auth.displayName || "Un trabajador"} expresó interés en tu oferta.`,
      result.applicationId,
      `application/${result.applicationId}`,
    );
    await audit(
      auth.usuarioId,
      "express_interest",
      "postulacion",
      result.applicationId,
      null,
      { jobId, status: "sent" },
    );
  }
  return {
    applicationId: result.applicationId,
    jobId,
    status: result.status,
    alreadyExpressed: result.alreadyExpressed,
    createdAt: result.createdAt,
  };
}

async function handleSendReminder(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["applicationId"]);
  requireRole(auth, "worker");
  const applicationId = requireString(body, "applicationId", 100);
  const worker = await getWorkerProfile(auth.usuarioId);
  if (!worker) {
    throw new ApiError("NOT_FOUND", "Perfil de trabajador no encontrado.", 404);
  }
  const { data: app, error } = await db.from("postulaciones").select("*").eq(
    "id",
    applicationId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!app) throw new ApiError("NOT_FOUND", "Candidatura no encontrada.", 404);
  if (app.trabajador_id !== worker.id) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el trabajador puede recordar su candidatura.",
      403,
    );
  }
  if (app.status !== "sent") {
    throw new ApiError(
      "CONFLICT",
      "Esta candidatura ya avanzó; no hace falta recordatorio.",
      409,
    );
  }
  const threeDaysMs = 3 * 24 * 60 * 60 * 1000;
  if (Date.now() - new Date(app.created_at).getTime() < threeDaysMs) {
    throw new ApiError(
      "CONFLICT",
      "Podrás enviar un recordatorio cuando pasen 3 días sin respuesta.",
      409,
    );
  }
  if (
    app.reminder_sent_at &&
    Date.now() - new Date(app.reminder_sent_at).getTime() < threeDaysMs
  ) {
    throw new ApiError(
      "CONFLICT",
      "Ya enviaste un recordatorio hace poco. Espera 3 días.",
      409,
    );
  }
  const now = new Date().toISOString();
  await db.from("postulaciones").update({
    reminder_sent_at: now,
    updated_at: now,
  }).eq("id", applicationId);
  const { data: job } = await db.from("ofertas").select("title").eq(
    "id",
    app.oferta_id,
  ).maybeSingle();
  const { data: company } = await db.from("perfiles_empresa").select("user_id")
    .eq("id", app.empresa_id).maybeSingle();
  if (company) {
    await createNotification(
      company.user_id,
      "application_reminder",
      `Recordatorio sobre «${job?.title ?? "tu oferta"}»`,
      `${
        auth.displayName || "Un trabajador"
      } sigue interesado y espera tu respuesta.`,
      applicationId,
      `application/${applicationId}`,
    );
  }
  await audit(
    auth.usuarioId,
    "send_reminder",
    "postulacion",
    applicationId,
    null,
    null,
  );
  return { reminded: true };
}

async function handleChangeApplicationStatus(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["applicationId", "status", "internalNote"]);
  const applicationId = requireString(body, "applicationId", 100);
  const newStatus = requireEnum(body, "status", APPLICATION_STATUSES);
  const internalNote = optionalString(body, "internalNote", 2000);
  const { data: app, error } = await db.from("postulaciones").select("*").eq(
    "id",
    applicationId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!app) throw new ApiError("NOT_FOUND", "Candidatura no encontrada.", 404);
  const { data: job } = await db.from("ofertas").select("title").eq(
    "id",
    app.oferta_id,
  ).maybeSingle();
  const jobTitle = job?.title ?? "la oferta";

  if (auth.role === "company") {
    const company = await getCompanyProfile(auth.usuarioId);
    if (!company || app.empresa_id !== company.id) {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "Solo la empresa propietaria puede cambiar este estado.",
        403,
      );
    }
    const allowed = COMPANY_APPLICATION_TRANSITIONS[app.status] || [];
    if (!allowed.includes(newStatus)) {
      throw new ApiError(
        "CONFLICT",
        `No se puede pasar de ${app.status} a ${newStatus}.`,
        409,
      );
    }
    const patch: Row = {
      status: newStatus,
      updated_at: new Date().toISOString(),
    };
    if (internalNote !== "") patch.internal_note = internalNote;
    const { data: updated, error: uErr } = await db.from("postulaciones")
      .update(patch).eq("id", applicationId).select().single();
    throwIfDbError(uErr);
    await audit(
      auth.usuarioId,
      "change_application_status",
      "postulacion",
      applicationId,
      { status: app.status },
      { status: newStatus },
    );
    const { data: worker } = await db.from("perfiles_trabajador").select(
      "user_id",
    ).eq("id", app.trabajador_id).maybeSingle();
    if (worker) {
      const type = newStatus === "interview"
        ? "interview_invitation"
        : "application_status_changed";
      const labels: Record<string, string> = {
        reviewing: "en revisión",
        interview: "entrevista",
        hired: "contratado",
        rejected: "cerrada",
      };
      await createNotification(
        worker.user_id,
        type,
        newStatus === "interview"
          ? "Te invitaron a una entrevista"
          : "Tu candidatura cambió de estado",
        `«${jobTitle}» ahora está ${labels[newStatus] ?? newStatus}.`,
        applicationId,
        `application/${applicationId}`,
      );
    }
    return { applicationId, status: updated.status };
  }

  if (auth.role === "worker") {
    const workerProfile = await getWorkerProfile(auth.usuarioId);
    if (!workerProfile || app.trabajador_id !== workerProfile.id) {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "Solo el trabajador puede retirar su propio interés.",
        403,
      );
    }
    if (newStatus !== "withdrawn") {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "El trabajador solo puede retirar su interés.",
        403,
      );
    }
    if (app.status !== "sent" && app.status !== "reviewing") {
      throw new ApiError(
        "CONFLICT",
        "Solo se puede retirar un interés en estado sent o reviewing.",
        409,
      );
    }
    await db.from("postulaciones").update({
      status: "withdrawn",
      updated_at: new Date().toISOString(),
    }).eq("id", applicationId);
    await audit(
      auth.usuarioId,
      "withdraw_interest",
      "postulacion",
      applicationId,
      { status: app.status },
      { status: "withdrawn" },
    );
    return { applicationId, status: "withdrawn" };
  }
  throw new ApiError(
    "FORBIDDEN_ROLE",
    "Rol no válido para cambiar el estado de una candidatura.",
    403,
  );
}

async function handleSaveJob(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["jobId", "folderName", "active"]);
  const jobId = requireString(body, "jobId", 100);
  const folderName = optionalString(body, "folderName", 100);
  const active = body.active === undefined ? true : body.active === true;
  const { data: job, error } = await db.from("ofertas").select("*").eq(
    "id",
    jobId,
  ).maybeSingle();
  throwIfDbError(error);
  if (!job) throw new ApiError("NOT_FOUND", "Oferta no encontrada.", 404);
  if (auth.role === "worker") {
    if (job.status !== "published") {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "Solo puedes guardar ofertas publicadas.",
        403,
      );
    }
  } else if (auth.role === "company") {
    const myCompany = await getCompanyProfile(auth.usuarioId);
    if (
      job.status !== "published" &&
      (!myCompany || job.empresa_id !== myCompany.id)
    ) {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "Solo puedes guardar ofertas publicadas o propias.",
        403,
      );
    }
  }
  await consumeLimit(
    auth.usuarioId,
    "saveJob",
    await configInt("MAX_SAVES_PER_HOUR", 60),
    "guardados",
  );
  const { data: existing } = await db.from("ofertas_guardadas").select(
    "id, folder_name",
  )
    .eq("user_id", auth.usuarioId).eq("oferta_id", jobId).maybeSingle();
  if (existing) {
    await db.from("ofertas_guardadas")
      .update({ active, folder_name: folderName || existing.folder_name })
      .eq("id", existing.id);
  } else {
    const { error: iErr } = await db.from("ofertas_guardadas").insert({
      user_id: auth.usuarioId,
      oferta_id: jobId,
      folder_name: folderName,
      active,
    });
    throwIfDbError(iErr);
  }
  await audit(
    auth.usuarioId,
    active ? "save_job" : "unsave_job",
    "oferta",
    jobId,
    null,
    null,
  );
  return { jobId, saved: active };
}

async function handleSaveCandidate(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, [
    "workerId",
    "applicationId",
    "folderName",
    "active",
  ]);
  requireRole(auth, "company");
  const workerId = requireString(body, "workerId", 100);
  const applicationId = optionalString(body, "applicationId", 100);
  const folderName = optionalString(body, "folderName", 100);
  const active = body.active === undefined ? true : body.active === true;
  const company = await getCompanyProfile(auth.usuarioId);
  if (!company) {
    throw new ApiError("NOT_FOUND", "Perfil de empresa no encontrado.", 404);
  }
  let application: Row | null = null;
  if (applicationId) {
    const { data } = await db.from("postulaciones").select("*").eq(
      "id",
      applicationId,
    ).maybeSingle();
    if (
      !data || data.empresa_id !== company.id || data.trabajador_id !== workerId
    ) {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "La candidatura no pertenece a esta empresa.",
        403,
      );
    }
    application = data;
  } else {
    const { data } = await db.from("postulaciones").select("*")
      .eq("trabajador_id", workerId).eq("empresa_id", company.id).maybeSingle();
    if (!data) {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "Solo puedes guardar candidatos que hayan expresado interés en tus ofertas.",
        403,
      );
    }
    application = data;
  }
  const { data: existing } = await db.from("candidatos_guardados").select(
    "id, folder_name",
  )
    .eq("empresa_id", company.id).eq("trabajador_id", workerId).maybeSingle();
  if (existing) {
    await db.from("candidatos_guardados").update({
      active,
      folder_name: folderName || existing.folder_name,
      postulacion_id: application!.id,
    }).eq("id", existing.id);
  } else {
    const { error } = await db.from("candidatos_guardados").insert({
      empresa_id: company.id,
      trabajador_id: workerId,
      postulacion_id: application!.id,
      folder_name: folderName,
      active,
    });
    throwIfDbError(error);
  }
  await audit(
    auth.usuarioId,
    active ? "save_candidate" : "unsave_candidate",
    "candidato",
    workerId,
    null,
    null,
  );
  return { workerId, saved: active };
}

async function handleSaveFilter(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, [
    "filterId",
    "name",
    "filters",
    "frequency",
    "enabled",
  ]);
  const filterId = optionalString(body, "filterId", 100);
  const name = requireString(body, "name", 120);
  const filters = body.filters;
  if (
    filters === undefined || filters === null || typeof filters !== "object" ||
    Array.isArray(filters)
  ) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "El campo filters debe ser un objeto.",
      400,
    );
  }
  // La app envía la frecuencia en inglés; se normaliza a español.
  let freqRaw = body.frequency;
  if (freqRaw === "immediate") freqRaw = "inmediata";
  else if (freqRaw === "daily") freqRaw = "diaria";
  else if (freqRaw === "off") freqRaw = "desactivada";
  const frequency = freqRaw === undefined
    ? "diaria"
    : requireEnum({ frequency: freqRaw }, "frequency", [
      "inmediata",
      "diaria",
      "desactivada",
    ]);
  const enabled = body.enabled === undefined ? true : body.enabled === true;
  const now = new Date().toISOString();
  if (filterId) {
    const { data: existing, error } = await db.from("filtros_guardados").select(
      "*",
    ).eq("id", filterId).maybeSingle();
    throwIfDbError(error);
    if (!existing) {
      throw new ApiError("NOT_FOUND", "Filtro no encontrado.", 404);
    }
    if (existing.user_id !== auth.usuarioId) {
      throw new ApiError(
        "FORBIDDEN_ROLE",
        "Solo el propietario puede editar este filtro.",
        403,
      );
    }
    await db.from("filtros_guardados").update({
      name,
      filters,
      frequency,
      enabled,
      updated_at: now,
    }).eq("id", filterId);
    await audit(
      auth.usuarioId,
      "update_filter",
      "filtro",
      filterId,
      null,
      null,
    );
    return { filterId, name, frequency, enabled };
  }
  const { data: created, error: iErr } = await db.from("filtros_guardados")
    .insert({
      user_id: auth.usuarioId,
      name,
      filters,
      frequency,
      enabled,
      created_at: now,
      updated_at: now,
    }).select().single();
  throwIfDbError(iErr);
  await audit(
    auth.usuarioId,
    "create_filter",
    "filtro",
    created.id,
    null,
    null,
  );
  return { filterId: created.id, name, frequency, enabled };
}

async function handleDeleteFilter(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["filterId"]);
  const filterId = requireString(body, "filterId", 100);
  const { data: existing, error } = await db.from("filtros_guardados").select(
    "*",
  ).eq("id", filterId).maybeSingle();
  throwIfDbError(error);
  if (!existing) throw new ApiError("NOT_FOUND", "Filtro no encontrado.", 404);
  if (existing.user_id !== auth.usuarioId) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede eliminar este filtro.",
      403,
    );
  }
  await db.from("filtros_guardados").delete().eq("id", filterId);
  await audit(auth.usuarioId, "delete_filter", "filtro", filterId, null, null);
  return { deleted: true };
}

// ---------------------------------------------------------------------------
// Handlers de escritura: sincronización, contacto, dispositivos, reportes
// ---------------------------------------------------------------------------
type SyncHandler = (auth: AuthContext, body: Json) => Promise<Json>;

const SYNCABLE: Record<string, SyncHandler> = {
  saveJob: handleSaveJob,
  saveCandidate: handleSaveCandidate,
  expressInterest: handleExpressInterest,
  sendReminder: handleSendReminder,
  saveFilter: handleSaveFilter,
  updateProfile: handleUpdateProfile,
  registerDevice: handleRegisterDevice,
  markNotificationRead: handleMarkNotificationRead,
  contactEvent: handleContactEvent,
  changeApplicationStatus: handleChangeApplicationStatus,
  withdrawInterest: async (auth, body) => {
    const b = { ...body, status: "withdrawn" };
    return handleChangeApplicationStatus(auth, b);
  },
};

async function handleSyncActions(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["actions"]);
  const actions = body.actions;
  if (!Array.isArray(actions) || actions.length === 0) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "El campo actions debe ser una lista no vacía.",
      400,
    );
  }
  if (actions.length > 100) {
    throw new ApiError(
      "VALIDATION_ERROR",
      "Máximo 100 acciones por sincronización.",
      400,
    );
  }
  const results: Json[] = [];
  for (const queued of actions as Row[]) {
    const clientActionId = typeof queued?.clientActionId === "string"
      ? queued.clientActionId
      : "";
    const actionType = typeof queued?.actionType === "string"
      ? queued.actionType
      : "";
    const payload: Json =
      (queued && typeof queued.payload === "object" && queued.payload !== null)
        ? queued.payload as Json
        : {};
    if (!clientActionId || !actionType) {
      results.push({
        clientActionId,
        result: "rejected",
        errorCode: "VALIDATION_ERROR",
      });
      continue;
    }
    const payloadHash = await sha256Hex(JSON.stringify(payload));

    // 1) Reservar el clientActionId (o decidir según el registro).
    const { data: recorded } = await db.from("acciones_sincronizacion").select(
      "*",
    )
      .eq("user_id", auth.usuarioId).eq("client_action_id", clientActionId)
      .maybeSingle();
    let decision: "execute" | "already_applied" | "conflict" = "execute";
    if (recorded) {
      if (recorded.payload_hash !== payloadHash) {
        decision = "conflict";
      } else if (
        recorded.status === "applied" || recorded.status === "already_applied"
      ) {
        decision = "already_applied";
      } else if (recorded.status === "processing") {
        const ageMs = Date.now() - new Date(recorded.created_at).getTime();
        decision = ageMs < 10 * 60 * 1000 ? "conflict" : "execute";
        if (decision === "execute") {
          await db.from("acciones_sincronizacion").update({
            status: "processing",
            processed_at: new Date().toISOString(),
          })
            .eq("user_id", auth.usuarioId).eq(
              "client_action_id",
              clientActionId,
            );
        }
      } else {
        // rejected: se reintenta.
        await db.from("acciones_sincronizacion").update({
          status: "processing",
          processed_at: new Date().toISOString(),
          error_code: "",
        })
          .eq("user_id", auth.usuarioId).eq("client_action_id", clientActionId);
      }
    } else {
      const { error: iErr } = await db.from("acciones_sincronizacion").insert({
        user_id: auth.usuarioId,
        client_action_id: clientActionId,
        action_type: actionType,
        payload_hash: payloadHash,
        status: "processing",
        processed_at: new Date().toISOString(),
      });
      if (iErr) {
        // Carrera: otra petición reservó el mismo ID a la vez.
        decision = "conflict";
      }
    }
    if (decision === "already_applied") {
      results.push({
        clientActionId,
        result: "already_applied",
        errorCode: null,
      });
      continue;
    }
    if (decision === "conflict") {
      results.push({
        clientActionId,
        result: "conflict",
        errorCode: "CONFLICT",
      });
      continue;
    }

    // 2) Ejecutar (los handlers validan y auditan por su cuenta).
    const handler = SYNCABLE[actionType];
    let result = "applied";
    let errorCode: string | null = null;
    let resultData: unknown = null;
    if (!handler) {
      result = "rejected";
      errorCode = "VALIDATION_ERROR";
    } else {
      try {
        resultData = await handler(auth, payload);
        if (
          resultData && typeof resultData === "object" &&
          (resultData as Row).alreadyExpressed === true
        ) {
          result = "already_applied";
        }
      } catch (err) {
        if (err instanceof ApiError && err.code === "CONFLICT") {
          result = "conflict";
          errorCode = "CONFLICT";
        } else if (err instanceof ApiError) {
          result = "rejected";
          errorCode = err.code;
        } else {
          result = "rejected";
          errorCode = "INTERNAL_ERROR";
          console.error("SYNC_FAIL", clientActionId, err);
        }
      }
    }

    // 3) Registrar el resultado final.
    await db.from("acciones_sincronizacion").update({
      status: result,
      processed_at: new Date().toISOString(),
      error_code: errorCode || "",
    }).eq("user_id", auth.usuarioId).eq("client_action_id", clientActionId);
    results.push({ clientActionId, result, errorCode, data: resultData });
  }
  const applied =
    results.filter((r) =>
      r.result === "applied" || r.result === "already_applied"
    ).length;
  return {
    results,
    applied,
    total: results.length,
    serverTime: new Date().toISOString(),
  };
}

async function handleContactEvent(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["entityType", "entityId", "channel"]);
  const entityType = requireEnum(body, "entityType", [
    "job",
    "company",
    "worker",
  ]);
  const entityId = requireString(body, "entityId", 100);
  const channel = requireEnum(body, "channel", [
    "whatsapp",
    "call",
    "copy",
    "request",
  ]);
  const { authorized } = await contactContext(auth, entityType, entityId);
  if (!authorized) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "No tienes acceso de contacto con esta entidad.",
      403,
    );
  }
  await consumeLimit(
    auth.usuarioId,
    "contactEvent",
    await configInt("MAX_CONTACT_EVENTS_PER_HOUR", 30),
    "eventos de contacto",
  );
  await audit(
    auth.usuarioId,
    `contact_${channel}`,
    entityType,
    entityId,
    null,
    null,
  );
  return { recorded: true, channel };
}

async function handleRegisterDevice(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["token", "platform", "appVersion"]);
  const token = requireString(body, "token", 500);
  const platform = requireEnum(body, "platform", ["android", "ios", "web"]);
  const appVersion = optionalString(body, "appVersion", 50);
  const now = new Date().toISOString();
  const { data: existing } = await db.from("dispositivos_fcm").select("id").eq(
    "token",
    token,
  ).maybeSingle();
  if (existing) {
    await db.from("dispositivos_fcm").update({
      user_id: auth.usuarioId,
      platform,
      app_version: appVersion,
      enabled: true,
      last_seen_at: now,
    }).eq("id", existing.id);
    await audit(
      auth.usuarioId,
      "register_device",
      "dispositivo",
      existing.id,
      null,
      null,
    );
    return { deviceId: existing.id, registered: true };
  }
  const { data: device, error } = await db.from("dispositivos_fcm").insert({
    user_id: auth.usuarioId,
    token,
    platform,
    app_version: appVersion,
    enabled: true,
    last_seen_at: now,
    created_at: now,
  }).select().single();
  throwIfDbError(error);
  await audit(
    auth.usuarioId,
    "register_device",
    "dispositivo",
    device.id,
    null,
    null,
  );
  return { deviceId: device.id, registered: true };
}

async function handleUnregisterDevice(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["token"]);
  const token = requireString(body, "token", 500);
  const { data: existing } = await db.from("dispositivos_fcm").select(
    "id, user_id",
  ).eq("token", token).maybeSingle();
  if (existing && existing.user_id === auth.usuarioId) {
    await db.from("dispositivos_fcm").update({ enabled: false }).eq(
      "id",
      existing.id,
    );
    await audit(
      auth.usuarioId,
      "unregister_device",
      "dispositivo",
      existing.id,
      null,
      null,
    );
  }
  return { unregistered: true };
}

async function handleMarkNotificationRead(
  auth: AuthContext,
  body: Json,
): Promise<Json> {
  rejectUnknownFields(body, ["notificationId", "all"]);
  const now = new Date().toISOString();
  if (body.all === true) {
    const { data: unread } = await db.from("notificaciones").select("id")
      .eq("user_id", auth.usuarioId).is("read_at", null);
    const ids = (unread as Row[] ?? []).map((n) => n.id);
    if (ids.length > 0) {
      await db.from("notificaciones").update({ read_at: now }).in("id", ids);
    }
    await audit(
      auth.usuarioId,
      "mark_notifications_read",
      "notificaciones",
      "all",
      null,
      { marked: ids.length },
    );
    return { marked: ids.length, all: true };
  }
  const notificationId = requireString(body, "notificationId", 100);
  const { data: notification, error } = await db.from("notificaciones").select(
    "*",
  ).eq("id", notificationId).maybeSingle();
  throwIfDbError(error);
  if (!notification) {
    throw new ApiError("NOT_FOUND", "Notificación no encontrada.", 404);
  }
  if (notification.user_id !== auth.usuarioId) {
    throw new ApiError(
      "FORBIDDEN_ROLE",
      "Solo el propietario puede marcar esta notificación.",
      403,
    );
  }
  await db.from("notificaciones").update({ read_at: now }).eq(
    "id",
    notificationId,
  );
  await audit(
    auth.usuarioId,
    "mark_notification_read",
    "notificacion",
    notificationId,
    null,
    null,
  );
  return { notificationId, read: true };
}

async function handleReport(auth: AuthContext, body: Json): Promise<Json> {
  rejectUnknownFields(body, ["entityType", "entityId", "reason", "details"]);
  const entityType = requireEnum(body, "entityType", [
    "job",
    "company",
    "worker",
  ]);
  const entityId = requireString(body, "entityId", 100);
  const reason = requireEnum(body, "reason", REPORT_REASONS);
  const details = optionalString(body, "details", 2000);
  await consumeLimit(
    auth.usuarioId,
    "report",
    await configInt("MAX_REPORTS_PER_HOUR", 10),
    "reportes",
  );
  const { data: report, error } = await db.from("reportes").insert({
    reporter_id: auth.usuarioId,
    entity_type: entityType,
    entity_id: entityId,
    reason,
    details,
    status: "abierto",
  }).select().single();
  throwIfDbError(error);
  await audit(auth.usuarioId, "report", entityType, entityId, null, { reason });
  // La API responde status "open" al crear (CONTRACT.md); en base es "abierto".
  return { reportId: report.id, status: "open" };
}

// ---------------------------------------------------------------------------
// Router: allowlist de acciones. Nunca se ejecuta un nombre enviado por
// el cliente sin validar.
// ---------------------------------------------------------------------------
async function route(
  action: string,
  body: Json,
  jwt: string | undefined,
): Promise<Json> {
  if (action === "health") return handleHealth();
  if (action === "login") return handleLogin(body);
  if (action === "publicJob") return handlePublicJob(body);
  if (action === "listCatalogs") return handleListCatalogs();
  if (action === "getRatings") return handleGetRatings(body);

  const auth = await requireAuth(jwt);
  switch (action) {
    case "logout":
      return handleLogout(auth, jwt!, body);
    case "registerProfile":
      return handleRegisterProfile(auth, body);
    case "me":
      return handleMe(auth);
    case "jobs":
      return handleJobs(auth, body);
    case "job":
      return handleJob(auth, body);
    case "applications":
      return handleApplications(auth, body);
    case "notifications":
      return handleNotifications(auth, body);
    case "listFilters":
      return handleListFilters(auth);
    case "sync":
      return handleSync(auth, body);
    case "contactOptions":
      return handleContactOptions(auth, body);
    case "updateProfile":
      return handleUpdateProfile(auth, body);
    case "createJob":
      return handleCreateJob(auth, body);
    case "publishJob":
      return handlePublishJob(auth, body);
    case "updateJob":
      return handleUpdateJob(auth, body);
    case "changeJobStatus":
      return handleChangeJobStatus(auth, body);
    case "archiveJob":
      return handleArchiveJob(auth, body);
    case "deleteJob":
      return handleDeleteJob(auth, body);
    case "expressInterest":
      return handleExpressInterest(auth, body);
    case "sendReminder":
      return handleSendReminder(auth, body);
    case "changeApplicationStatus":
      return handleChangeApplicationStatus(auth, body);
    case "saveJob":
      return handleSaveJob(auth, body);
    case "saveCandidate":
      return handleSaveCandidate(auth, body);
    case "saveFilter":
      return handleSaveFilter(auth, body);
    case "deleteFilter":
      return handleDeleteFilter(auth, body);
    case "syncActions":
      return handleSyncActions(auth, body);
    case "contactEvent":
      return handleContactEvent(auth, body);
    case "registerDevice":
      return handleRegisterDevice(auth, body);
    case "unregisterDevice":
      return handleUnregisterDevice(auth, body);
    case "markNotificationRead":
      return handleMarkNotificationRead(auth, body);
    case "report":
      return handleReport(auth, body);
    case "rateApplication":
      return handleRateApplication(auth, body);
    default:
      throw new ApiError("VALIDATION_ERROR", "Acción no válida.", 400);
  }
}

// ---------------------------------------------------------------------------
// Entrada HTTP
// ---------------------------------------------------------------------------
Deno.serve(async (req: Request): Promise<Response> => {
  const requestId = crypto.randomUUID();
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

  try {
    const url = new URL(req.url);

    // Resumen diario de filtros (pg_cron / HTTP, 09:00). No es una
    // acción del contrato: exige el secreto CRON_SECRET.
    if (url.searchParams.get("cron") === "saved-filters-daily") {
      const secret = Deno.env.get("CRON_SECRET");
      const given = req.headers.get("x-cron-secret") ??
        url.searchParams.get("secret") ?? "";
      if (!secret || given !== secret) {
        return fail("AUTH_REQUIRED", "Cron no autorizado.", requestId, 401);
      }
      const digests = await runSavedFiltersDaily();
      return ok({ digests, runAt: new Date().toISOString() }, requestId);
    }

    if (req.method === "GET") {
      const action = url.searchParams.get("action");
      if (action !== "health") {
        return fail(
          "VALIDATION_ERROR",
          "Solo health está disponible por GET.",
          requestId,
          400,
        );
      }
      return ok(await handleHealth(), requestId);
    }
    if (req.method !== "POST") {
      return fail("VALIDATION_ERROR", "Método no permitido.", requestId, 405);
    }

    const raw = await req.text();
    if (raw.length > MAX_BODY_BYTES) {
      return fail(
        "VALIDATION_ERROR",
        "El cuerpo supera el tamaño máximo permitido.",
        requestId,
        413,
      );
    }
    let body: Json;
    try {
      body = JSON.parse(raw);
    } catch {
      return fail(
        "VALIDATION_ERROR",
        "El cuerpo POST no es JSON válido.",
        requestId,
        400,
      );
    }
    const action = typeof body.action === "string" ? body.action : "";
    if (!READ_ACTIONS.has(action) && !WRITE_ACTIONS.has(action)) {
      return fail("VALIDATION_ERROR", "Acción no válida.", requestId, 400);
    }

    // Token: cabecera Authorization (obligatoria en 2.10.0). Se acepta
    // durante una versión un `accessToken` opaco en el cuerpo, que
    // responde AUTH_REQUIRED con mensaje de actualización (AUTH §1.4);
    // en 2.11.0 se rechaza sin más.
    const header = req.headers.get("authorization") ?? "";
    const jwt = header.startsWith("Bearer ")
      ? header.slice(7)
      : (typeof body.accessToken === "string" ? body.accessToken : undefined);

    if (!PUBLIC_ACTIONS.has(action) && !jwt) {
      return fail("AUTH_REQUIRED", "Falta el token de sesión.", requestId, 401);
    }
    const data = await route(action, body, jwt);
    return ok(data, requestId);
  } catch (err) {
    if (err instanceof ApiError) {
      return fail(err.code, err.message, requestId, err.status);
    }
    console.error("INTERNAL_ERROR", requestId, err);
    return fail(
      "INTERNAL_ERROR",
      "Error interno. Inténtalo de nuevo.",
      requestId,
      500,
    );
  }
});
