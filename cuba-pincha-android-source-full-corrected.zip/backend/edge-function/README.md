# CubaPincha · Edge Function `api` 2.10.0 — borrador listo para desplegar

**Fecha:** 2026-11-21 · **Archivo:** `index.ts` (4.198 líneas tras `deno fmt`)
**Verificación local:** `deno check index.ts` → **OK, 0 errores** (Deno 2.9.8,
`@supabase/supabase-js@2`). No se contactó con Supabase, Firebase,
Google ni GitHub. **No desplegado.** Borrador, en `work/`, sin tocar el
original extraído.

**Base:** esqueleto `supabase/functions/api/index.ts` (6/34) + `Code.gs`
1.4.1 (lógica de referencia) + `CONTRACT.md` 1.4.1 + `AUTH_SUPABASE.md`
(diseño de JWT) + SQL `001`/`002`.

## Estado: 34 de 34 acciones implementadas, 0 `NOT_IMPLEMENTED`

| Grupo | Acciones |
|---|---|
| Lecturas (11) | `health`, `me`, `jobs`, `job`, `publicJob`, `listCatalogs`, `applications`, `notifications`, `listFilters`, `sync`, `contactOptions` |
| Escrituras (23) | `login`*, `logout`, `registerProfile`, `updateProfile`, `createJob`, `publishJob`, `updateJob`, `changeJobStatus`, `archiveJob`, `deleteJob`, `expressInterest`, `sendReminder`, `changeApplicationStatus`, `saveJob`, `saveCandidate`, `saveFilter`, `deleteFilter`, `syncActions`, `contactEvent`, `registerDevice`, `unregisterDevice`, `markNotificationRead`, `report` |

\* `login` es un **stub de compatibilidad por diseño** (AUTH §5.2): ya no
autentica, responde `AUTH_REQUIRED` con "actualiza la app". La app
2.10.0 no lo llama: tras el sign-in de GoTrue llama directamente a
`me`. Se borra en 2.11.0. No es un pendiente, es la decisión escrita.

## Cambios principales frente al esqueleto

1. **Auth por JWT de Supabase, no Firebase ni sesiones opacas.**
   `verifyFirebaseIdToken()`, `requireAuth()` por hash de sesión y toda
   lectura/escritura en `sesiones` están borrados. Cada petición crea
   un cliente anon por petición y verifica con `auth.getUser()`;
   `AuthContext` sale de `auth.uid()` + `public.usuarios`. Sin
   `FIREBASE_API_KEY`, sin `REQUIRE_EMAIL_VERIFIED`, sin
   `SESSION_TTL_HOURS`, sin `sessionToken` en ninguna respuesta.
2. **`registerProfile` redefinido:** completar/crear el perfil de un
   usuario ya autenticado por GoTrue. Crea o actualiza la fila en
   `usuarios` (id = `auth.uid()`), el perfil por rol, calcula
   `profilePercent` y activa al trabajador con ≥80%. Límite **5/h por
   hash de correo** (como Apps Script P3). Devuelve
   `{userId, role, status, displayName, isNew, profile}` (sin sesión).
3. **`logout`:** revoca el refresh token en Supabase (`signOut()`) y
   da de baja el token FCM si viene en el cuerpo.
4. **`me` con la forma del contrato:** `{userId, role, status,
   displayName, emailMasked, phone, profile, unreadNotifications}`
   (el esqueleto devolvía solo `{user}`). Si el usuario de GoTrue aún
   no tiene fila en `usuarios`, devuelve el perfil `null` y estado
   `incomplete` en vez de fallar.
5. **Las 28 acciones restantes, en el orden de la auditoría**
   (lecturas y `jobs` primero): `jobs` con todos los filtros del
   contrato (q con normalización sin acentos, provincia/municipio,
   `mobilityScope`, salario, `verifiedOnly`, `onlyWithSalary`,
   orden `recent`/`salary`/`match`), `job` con similares y
   `applicationStatus`, `applications` por rol, `notifications`,
   `sync` (pull con `since` + `offset`, 100 por colección),
   `contactOptions` con la regla de autorización (propietario o
   candidatura activa concreta; el número completo solo entonces),
   `updateProfile` con `expectedUpdatedAt` optimista y preferencias
   de contacto, ciclo completo de ofertas (crear → publicar con
   matching → editar → pausar/cerrar → archivar → borrar solo
   borrador sin candidaturas), `expressInterest` con las
   comprobaciones S-05 (empresa activa, no ser el dueño) y
   reactivación de un interés retirado, `sendReminder` (3 días),
   `changeApplicationStatus` con transiciones por rol y
   notificaciones, guardados, filtros (frecuencia normalizada
   `immediate`→`inmediata`, etc.), `syncActions` idempotente por
   `clientActionId` (reserva `processing`, `already_applied`,
   `conflict`, reintento de huérfanas >10 min y de `rejected`),
   `contactEvent`, dispositivos FCM, `markNotificationRead`
   (una o todas) y `report`.
6. **Matching y notificaciones portados de Code.gs:** `computeMatchScore`
   (categoría 40, ubicación 25, habilidades 25, experiencia 10),
   `runMatchingForJob` (umbral `MATCH_THRESHOLD`, tope 200),
   alertas inmediatas de filtros con dedupe contra
   `new_relevant_job`, y `createNotification` con dedupe
   `type:userId:entityId` + push FCM HTTP v1 (JWT RS256 firmado con
   la cuenta de servicio, tokens muertos desactivados).
7. **Resumen diario de filtros (09:00):** implementado como
   `runSavedFiltersDaily()` (exportado). No es una acción del
   contrato: se invoca por `?cron=saved-filters-daily` con el secreto
   `CRON_SECRET` (cabecera `x-cron-secret` o parámetro `secret`).
8. **Rate limiting con `consumir_limite()`:** `expressInterest` 30/h,
   `createJob`/`publishJob` 10/h, `saveJob` 60/h, `contactEvent`
   30/h, `report` 10/h, `registerProfile` 5/h por correo. Los límites
   por correo usan un UUID determinista derivado del hash SHA-256
   (`uuidFromHash`), porque `consumir_limite()` recibe un uuid: es
   solo la llave del límite, nunca una identidad.
9. **`reportes.status`:** en base `abierto`, la API responde `"open"`
   al crear (CONTRACT.md).
10. **Validación por acción:** `rejectUnknownFields` en todas las
    escrituras (el esqueleto no lo tenía), como Apps Script.

## Secretos necesarios (solo nombres, sin valores)

| Secreto | Origen | Obligatorio |
|---|---|---|
| `SUPABASE_URL` | Inyectado por Supabase | Sí |
| `SUPABASE_ANON_KEY` | Inyectado por Supabase | Sí |
| `SUPABASE_SERVICE_ROLE_KEY` | Inyectado por Supabase | Sí |
| `ALLOWED_ORIGIN` | `supabase secrets set` (p. ej. `https://cubapincha.cu`) | Sí |
| `FCM_SERVICE_ACCOUNT` | `supabase secrets set` (JSON de la cuenta de servicio) | No — sin él no hay push, pero las notificaciones se persisten igual |
| `CRON_SECRET` | `supabase secrets set` | No — solo para el resumen diario por HTTP |

**Eliminados:** `FIREBASE_API_KEY`, `REQUIRE_EMAIL_VERIFIED`.
La clave `anon` es pública por diseño (con RLS); `service_role`
nunca sale del servidor.

## Despliegue (cuando haya acceso a Supabase)

```bash
# Desde la raíz del proyecto Supabase (donde vive supabase/config.toml):
cp CubPincha/work/edge-function-2.10.0/index.ts supabase/functions/api/index.ts
supabase link --project-ref ogimwehtnhegfoamiwzm
supabase secrets set ALLOWED_ORIGIN=https://cubapincha.cu
# opcional: supabase secrets set FCM_SERVICE_ACCOUNT='{"type":"service_account",...}'
# opcional: supabase secrets set CRON_SECRET='<secreto>'
supabase functions deploy api
```

Prerrequisitos en staging, en este orden: `001_esquema.sql`,
`002_seguridad_y_funciones.sql` (con los cambios de
`AUTH_SUPABASE.md` §3: `usuarios.id = auth.users.id`, FK con
`ON UPDATE CASCADE`), `datos_prueba.sql` solo para pruebas, bucket
privado `archivos`, y los 3 pg_cron de `002` (expirar ofertas,
purgas). El resumen diario (09:00) necesita además programar la
llamada HTTP con `CRON_SECRET` o una función programada aparte.

## Pruebas de contrato T01–T20 (contra staging, tras desplegar)

Matriz de la guía, Fase 7. Usar los datos de prueba
(`datos_prueba.sql`: trabajadora Ana, empresa El Faro, `job-001` /
`job-002`) y dos cuentas reales de Supabase Auth (una worker, una
company). La sesión de prueba `token-prueba-sesion-trabajadora-001`
**no sirve aquí**: ya no hay sesiones opacas; revocarla antes de
cualquier uso real.

| # | Prueba | Espera |
|---|---|---|
| T01 | `health` por GET y POST, sin JWT | `ok:true`, `version:"2.0.0-supabase"` |
| T02 | `publicJob` con `job-001`, sin JWT | Oferta pública, sin teléfono ni CV |
| T03 | `publicJob` con id inexistente / borrador, sin JWT | `NOT_FOUND` |
| T04 | `listCatalogs`, sin JWT | Mapa `{HAB: [...], ...}` ordenado |
| T05 | `login` con `idToken` antiguo | `AUTH_REQUIRED` "actualiza la app" |
| T06 | `me` con JWT válido, sin fila en `usuarios` | Perfil `null`, `status:"incomplete"`, sin 500 |
| T07 | `registerProfile` worker con JWT (correo = JWT) | Crea usuario + perfil, `isNew:true`, sin `sessionToken` |
| T08 | `registerProfile` con correo distinto al JWT | `VALIDATION_ERROR` |
| T09 | `registerProfile` repetido mismo correo | `DUPLICATE` |
| T10 | `jobs` worker: filtros `q`, provincia, salario, `onlyWithSalary`, `verifiedOnly`, orden `match` | Solo `published` no caducadas, `total`/`hasMore`/`nextCursor` coherentes |
| T11 | `jobs` empresa | Solo sus ofertas, cualquier estado |
| T12 | `job` detalle worker + `expressInterest` | `applicationStatus:"sent"`, segunda llamada `alreadyExpressed:true`, sin duplicado |
| T13 | `expressInterest` 31 veces seguidas | La 31ª `RATE_LIMITED` (429) |
| T14 | `createJob` → `publishJob` (empresa activa) | `status:"published"`, `workersNotified` ≥ 0 |
| T15 | `changeJobStatus` con transición inválida (`draft`→`paused`) | `CONFLICT` |
| T16 | `updateJob` con `salaryMin > salaryMax` | `VALIDATION_ERROR` |
| T17 | `archiveJob` → `changeJobStatus` a `published` (deshacer) | Vuelve a `published` |
| T18 | `deleteJob` de oferta publicada | `CONFLICT`; de borrador sin candidaturas: `{deleted:true}` |
| T19 | `applications` worker y empresa; `changeApplicationStatus` empresa `sent`→`interview` + notificación al trabajador; trabajador retira (`withdrawn`) y vuelve a expresar interés (reactiva a `sent`) | Estados y notificaciones correctos en ambos lados |
| T20 | `notifications` + `markNotificationRead` (una y `all:true`); `saveJob`/`saveFilter`/`listFilters`; `syncActions` con el mismo `clientActionId` dos veces (`already_applied`); `contactOptions` sin candidatura (sin teléfono) y con candidatura (con teléfono); `report` (`status:"open"`); `registerDevice` + `unregisterDevice` | Todo con códigos y formas del contrato; ninguna acción `NOT_IMPLEMENTED` ni 500 |

## Diferencias conocidas frente a Code.gs (decididas, no olvidos)

- **`report.entityType`:** solo `job`/`company`/`worker` (el CHECK de
  `001` no admite `user`, que Code.gs aceptaba; en Postgres daría 500).
- **`me`:** forma del contrato, no `{user}` del esqueleto.
- **`jobs`:** paginación por `cursor` (offset) como en Code.gs; la
  búsqueda es `indexOf` normalizado en memoria sobre ≤500 filas (la
  búsqueda con `tsvector`/`pg_trgm` es P1 de la auditoría, no de
  esta fase).
- **Límite de `jobs`:** se leen como máximo 500 ofertas antes de
  filtrar en memoria; con más volumen, mover los filtros a la
  consulta (ver P1-1 de la auditoría).
- **`consumir_limite()` sin lock consultivo:** la corrección S-04
  (`pg_advisory_xact_lock`) es un cambio de SQL (002), no de esta
  función; aplicarla antes del corte o el límite puede sobrepasarse
  bajo concurrencia.
- **`expresar_interes()` sin S-05 en SQL:** la comprobación de
  empresa activa y no ser el dueño se hace en el handler
  (`handleExpressInterest`); la corrección en la función SQL sigue
  pendiente (AUTH §3.3.3).
- **Sin `expirar_ofertas()` por HTTP:** la caducidad la hace pg_cron
  cada hora (002); no hay endpoint para ella.
- **`sync`:** no devuelve ofertas guardadas ni filtros (Code.gs
  tampoco); el cliente los relee con sus acciones.
- **FCM:** el envío es real (HTTP v1), pero sin `FCM_SERVICE_ACCOUNT`
  configurado no se envía nada y no falla la petición.

## Archivos

- `index.ts` — la función completa (2.10.0).
- `README.md` — este archivo.
