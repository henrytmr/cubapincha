-- CubaPincha · Valoraciones 2.11.0 / Edge API 2.0
-- Se valora únicamente una candidatura contratada y una vez por autor.
CREATE TABLE IF NOT EXISTS valoraciones (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    postulacion_id        uuid NOT NULL REFERENCES postulaciones (id) ON DELETE CASCADE,
    autor_usuario_id      uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    autor_perfil_id       uuid NOT NULL,
    destinatario_perfil_id uuid NOT NULL,
    stars                 smallint NOT NULL CHECK (stars BETWEEN 1 AND 5),
    comment               varchar(1000) NOT NULL DEFAULT '',
    created_at            timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_valoraciones_postulacion_autor UNIQUE (postulacion_id, autor_usuario_id)
);
CREATE INDEX IF NOT EXISTS idx_valoraciones_destinatario
    ON valoraciones (destinatario_perfil_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_valoraciones_postulacion
    ON valoraciones (postulacion_id);

-- Los IDs de autor/destinatario son perfiles, no usuarios.id. La Edge Function
-- verifica que ambos perfiles pertenecen a los lados de una candidatura hired.
ALTER TABLE valoraciones ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS valoraciones_public_read ON valoraciones;
CREATE POLICY valoraciones_public_read ON valoraciones FOR SELECT USING (true);
DROP POLICY IF EXISTS valoraciones_service_write ON valoraciones;
CREATE POLICY valoraciones_service_write ON valoraciones FOR ALL USING (false) WITH CHECK (false);
