-- ============================================================================
-- CubaPincha · 005_permisos_service_role.sql — FIX PERMISOS EDGE FUNCTION
-- ============================================================================
-- Causa: el rebuild (000_reset.sql) hizo DROP SCHEMA public CASCADE, lo que
-- destruyó los privilegios por defecto de Supabase que daban a service_role
-- acceso a las tablas. La 002 solo da GRANTs explícitos a anon y
-- authenticated y asumía que service_role ya lo tenía todo por defecto.
-- La Edge Function usa la service_role key: bypasea RLS, pero sin GRANT
-- sobre la tabla Postgres devuelve 42501 "permission denied for table".
-- Visto en los logs de la función api: DB_ERROR permission denied for
-- table municipios / ofertas (2026-11-21 03:13-03:14 UTC).
--
-- Este parche no toca RLS ni las políticas: solo restaura el acceso de
-- service_role a las tablas y secuencias actuales y futuras de public.
-- Aplicar UNA SOLA VEZ en staging (SQL Editor o Management API).
-- Idempotente: se puede re-ejecutar sin daño.
-- ============================================================================

GRANT USAGE ON SCHEMA public TO service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public
  GRANT ALL ON TABLES TO service_role;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public
  GRANT ALL ON SEQUENCES TO service_role;

-- Verificación: service_role debe tener SELECT sobre las 20 relaciones
-- de public (19 tablas + vista). OJO: information_schema expande ALL en
-- privilegios individuales, así que no busques privilege_type = 'ALL'.
SELECT 'service_role_tablas_con_select' AS comprobacion,
       count(DISTINCT table_name) AS tablas
FROM information_schema.role_table_grants
WHERE grantee = 'service_role'
  AND table_schema = 'public'
  AND privilege_type = 'SELECT';
