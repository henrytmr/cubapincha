-- ============================================================================
-- CubaPincha · 001_esquema.sql
-- Esquema Supabase / Postgres 17 (staging: cubapincha-staging, us-east-1)
-- Fuente de verdad de columnas y enums: cubapincha-supabase/migracion/
--   migrar_sheets_a_supabase.py  (funcion transformar() y ORDEN).
--   Las columnas se escriben en snake_case exactamente como las inserta
--   ese script; los CHECK reproducen sus conjuntos de enums.
-- Contrato: cubapincha-2.9.2/jobmatch-android/CONTRACT.md (API 1.4.1).
-- Edge Function: cubapincha-supabase/supabase/functions/api/index.ts.
--
-- Tablas: 20.
--   17 del script de migracion (ORDEN) + sesiones + archivos + limites_uso.
--   NOTA DE CONTEO: la guia habla de "20 tablas" y el script trae 17;
--   17 + sesiones + archivos = 19. La vigesima es limites_uso, creada
--   aqui porque consumir_limite() (002) necesita registrar intentos de
--   forma atomica ("cuenta intentos, no solo altas", segun index.ts).
--   No hay ninguna otra tabla en las fuentes; no se inventa ninguna mas.
--
-- Sesiones: disenada desde index.ts (requireAuth/handleLogin/handleLogout):
--   sesion opaca de 24 h, guardada solo como hash SHA-256 (session_hash
--   es la PK), con user_id y expires_at. La sesion en si NO se migra
--   (ver migrar_sheets_a_supabase.py).
-- Archivos: disenada desde la nota del script ("archivos (CV y logos en
--   Drive) NO se migra aqui") y los campos cv_path / logo_path de los
--   perfiles (que quedan en "" tras migrar). Registra cada archivo
--   subido al bucket de Storage 'archivos' (ver 002, apartado Storage).
--   SUPOSICION: bucket privado 'archivos', tipo cv | logo | otro,
--   owner_id = usuario dueno del archivo. La Edge Function actual no
--   consulta esta tabla; es para la fase 6 de la guia.
--
-- Idempotencia: CREATE TABLE IF NOT EXISTS / CREATE OR REPLACE VIEW.
--   Si una tabla ya existe con otra definicion, este archivo NO la
--   altera: revisar a mano antes de re-ejecutar sobre un esquema viejo.
-- Ejecutar ANTES que 002_seguridad_y_funciones.sql.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. provincias  (CSV catalogos, catalogType = provincia)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS provincias (
    codigo      text PRIMARY KEY,              -- PRI, ART, HAB, MAY, ... (16)
    nombre      text NOT NULL,                 -- La Habana, Pinar del Rio, ...
    orden       integer NOT NULL DEFAULT 0,
    activo      boolean NOT NULL DEFAULT true
);

-- ---------------------------------------------------------------------------
-- 2. municipios  (CSV catalogos, catalogType = municipio)
--    codigo = PROV-nombre-normalizado, p. ej. HAB-playa
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS municipios (
    provincia_codigo text NOT NULL REFERENCES provincias (codigo),
    codigo           text NOT NULL,
    nombre           text NOT NULL,
    orden            integer NOT NULL DEFAULT 0,
    activo           boolean NOT NULL DEFAULT true,
    PRIMARY KEY (provincia_codigo, codigo)
);

-- ---------------------------------------------------------------------------
-- 3. usuarios
--    firebase_uid queda NULL en la migracion y se vincula en el primer
--    login (por email_hash). email_hash es SHA-256 del correo en minusculas.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    firebase_uid  text UNIQUE,
    email_hash    text NOT NULL UNIQUE,
    email_masked  text NOT NULL DEFAULT '',
    role          text NOT NULL CHECK (role IN ('worker', 'company')),
    status        text NOT NULL DEFAULT 'incomplete'
                  CHECK (status IN ('active', 'incomplete', 'pending_verification',
                                    'suspended', 'deleted')),
    display_name  text NOT NULL DEFAULT '',
    phone         text NOT NULL DEFAULT '',
    created_at    timestamptz DEFAULT now(),
    updated_at    timestamptz DEFAULT now(),
    last_login_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_usuarios_firebase_uid ON usuarios (firebase_uid);
CREATE INDEX IF NOT EXISTS idx_usuarios_role_status ON usuarios (role, status);

-- ---------------------------------------------------------------------------
-- 4. perfiles_trabajador
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS perfiles_trabajador (
    id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id                 uuid NOT NULL UNIQUE REFERENCES usuarios (id) ON DELETE CASCADE,
    headline                varchar(200) NOT NULL DEFAULT '',
    city                    text NOT NULL DEFAULT '',
    country                 text NOT NULL DEFAULT '',
    skills                  text[] NOT NULL DEFAULT '{}',
    experience_years        numeric,
    availability            text NOT NULL DEFAULT '',
    work_modes              text[] NOT NULL DEFAULT '{}',
    salary_min              numeric,
    salary_max              numeric,
    cv_path                 text NOT NULL DEFAULT '',
    profile_percent         integer NOT NULL DEFAULT 0 CHECK (profile_percent BETWEEN 0 AND 100),
    phone                   text NOT NULL DEFAULT '',
    province_code           text REFERENCES provincias (codigo),
    municipality_code       text,
    locality                text NOT NULL DEFAULT '',
    mobility_scope          text CHECK (mobility_scope IN ('mi_municipio', 'mi_provincia',
                                                           'cualquier_lugar', 'remoto')),
    can_relocate            boolean NOT NULL DEFAULT false,
    remote_available        boolean NOT NULL DEFAULT false,
    preferred_salary_period text CHECK (preferred_salary_period IN
                                        ('mensual', 'quincenal', 'semanal', 'diario',
                                         'por_hora', 'por_proyecto', 'comision', 'a_convenir')),
    contact_hours           text NOT NULL DEFAULT '',
    contact_preference      text CHECK (contact_preference IN ('whatsapp', 'llamada', 'correo')),
    created_at              timestamptz DEFAULT now(),
    updated_at              timestamptz DEFAULT now(),
    CONSTRAINT chk_perfil_trabajador_salario CHECK (salary_min IS NULL OR salary_max IS NULL
                                                    OR salary_min <= salary_max),
    CONSTRAINT fk_perfil_trabajador_municipio
        FOREIGN KEY (province_code, municipality_code)
        REFERENCES municipios (provincia_codigo, codigo)
);
CREATE INDEX IF NOT EXISTS idx_perfiles_trabajador_provincia
    ON perfiles_trabajador (province_code, municipality_code);

-- ---------------------------------------------------------------------------
-- 5. perfiles_empresa
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS perfiles_empresa (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id            uuid NOT NULL UNIQUE REFERENCES usuarios (id) ON DELETE CASCADE,
    legal_name         varchar(200) NOT NULL,
    display_name       text NOT NULL DEFAULT '',
    industry           text NOT NULL DEFAULT '',
    size               text NOT NULL DEFAULT '',
    description        varchar(2000) NOT NULL DEFAULT '',
    city               text NOT NULL DEFAULT '',
    website            text NOT NULL DEFAULT '',
    logo_path          text NOT NULL DEFAULT '',
    verified           boolean NOT NULL DEFAULT false,
    verification_level text NOT NULL DEFAULT 'basica'
                       CHECK (verification_level IN ('basica', 'verificada')),
    status             text NOT NULL DEFAULT 'pending_verification'
                       CHECK (status IN ('active', 'pending_verification', 'suspended')),
    org_type           text CHECK (org_type IN ('privada', 'mipyme', 'cooperativa',
                                                'tcp', 'proyecto', 'institucional')),
    phone              text NOT NULL DEFAULT '',
    contact_hours      text NOT NULL DEFAULT '',
    province_code      text REFERENCES provincias (codigo),
    municipality_code  text,
    locality           text NOT NULL DEFAULT '',
    created_at         timestamptz DEFAULT now(),
    updated_at         timestamptz DEFAULT now(),
    CONSTRAINT fk_perfil_empresa_municipio
        FOREIGN KEY (province_code, municipality_code)
        REFERENCES municipios (provincia_codigo, codigo)
);
CREATE INDEX IF NOT EXISTS idx_perfiles_empresa_provincia
    ON perfiles_empresa (province_code, municipality_code);
CREATE INDEX IF NOT EXISTS idx_perfiles_empresa_status ON perfiles_empresa (status);

-- ---------------------------------------------------------------------------
-- 6. ofertas
--    salary_period 'a_convenir' = "A convenir" (sin montos). Salario en CUP.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ofertas (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id            uuid NOT NULL REFERENCES perfiles_empresa (id) ON DELETE CASCADE,
    title                 varchar(200) NOT NULL DEFAULT '',
    category              varchar(120) NOT NULL DEFAULT '',
    description           varchar(10000) NOT NULL DEFAULT '',
    responsibilities      text[] NOT NULL DEFAULT '{}',
    benefits              text[] NOT NULL DEFAULT '{}',
    requirements          jsonb NOT NULL DEFAULT '{}'::jsonb,
    city                  text NOT NULL DEFAULT '',
    province_code         text REFERENCES provincias (codigo),
    municipality_code     text,
    locality              text NOT NULL DEFAULT '',
    work_mode             text CHECK (work_mode IN ('presencial', 'hibrido', 'remoto', 'por_zonas')),
    contract_type         text CHECK (contract_type IN ('indefinido', 'temporal', 'por_proyecto',
                                                        'practicas', 'medio_tiempo', 'tiempo_completo')),
    salary_min            numeric,
    salary_max            numeric,
    salary_period         text NOT NULL DEFAULT 'mensual'
                          CHECK (salary_period IN ('mensual', 'quincenal', 'semanal', 'diario',
                                                   'por_hora', 'por_proyecto', 'comision', 'a_convenir')),
    includes_food         boolean NOT NULL DEFAULT false,
    includes_transport    boolean NOT NULL DEFAULT false,
    includes_accommodation boolean NOT NULL DEFAULT false,
    includes_tips         boolean NOT NULL DEFAULT false,
    payment_notes         varchar(500) NOT NULL DEFAULT '',
    contact_hours         text NOT NULL DEFAULT '',
    start_date            date,
    status                text NOT NULL DEFAULT 'draft'
                          CHECK (status IN ('draft', 'published', 'paused',
                                            'closed', 'expired', 'archived')),
    published_at          timestamptz,
    expires_at            timestamptz,
    archived_at           timestamptz,
    archive_reason        text NOT NULL DEFAULT '',
    created_by            uuid REFERENCES usuarios (id) ON DELETE SET NULL,
    created_at            timestamptz DEFAULT now(),
    updated_at            timestamptz DEFAULT now(),
    CONSTRAINT chk_ofertas_salario CHECK (salary_min IS NULL OR salary_max IS NULL
                                          OR salary_min <= salary_max),
    CONSTRAINT fk_ofertas_municipio
        FOREIGN KEY (province_code, municipality_code)
        REFERENCES municipios (provincia_codigo, codigo)
);
-- Listado publico: solo published y no caducadas (ver v_ofertas_publicas).
CREATE INDEX IF NOT EXISTS idx_ofertas_publicas
    ON ofertas (status, expires_at, published_at DESC) WHERE status = 'published';
CREATE INDEX IF NOT EXISTS idx_ofertas_provincia
    ON ofertas (province_code, municipality_code, status);
CREATE INDEX IF NOT EXISTS idx_ofertas_categoria ON ofertas (category, status);
CREATE INDEX IF NOT EXISTS idx_ofertas_empresa ON ofertas (empresa_id, status);
CREATE INDEX IF NOT EXISTS idx_ofertas_expiracion ON ofertas (expires_at) WHERE status = 'published';

-- ---------------------------------------------------------------------------
-- 7. postulaciones  (CSV postulaciones_intereses)
--    empresa_id es siempre la empresa de la oferta (fuente de verdad).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS postulaciones (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    oferta_id        uuid NOT NULL REFERENCES ofertas (id) ON DELETE CASCADE,
    trabajador_id    uuid NOT NULL REFERENCES perfiles_trabajador (id) ON DELETE CASCADE,
    empresa_id       uuid NOT NULL REFERENCES perfiles_empresa (id) ON DELETE CASCADE,
    status           text NOT NULL DEFAULT 'sent'
                     CHECK (status IN ('sent', 'reviewing', 'interview',
                                       'hired', 'rejected', 'withdrawn')),
    message          text NOT NULL DEFAULT '',
    internal_note    text NOT NULL DEFAULT '',
    last_notified_at timestamptz,
    reminder_sent_at timestamptz,
    created_at       timestamptz DEFAULT now(),
    updated_at       timestamptz DEFAULT now(),
    CONSTRAINT uq_postulaciones_oferta_trabajador UNIQUE (oferta_id, trabajador_id)
);
CREATE INDEX IF NOT EXISTS idx_postulaciones_oferta ON postulaciones (oferta_id, status);
CREATE INDEX IF NOT EXISTS idx_postulaciones_trabajador ON postulaciones (trabajador_id, status);
CREATE INDEX IF NOT EXISTS idx_postulaciones_empresa ON postulaciones (empresa_id, status);

-- ---------------------------------------------------------------------------
-- 8. filtros_guardados
--    NOTA: el script solo escribe frequency inmediata|diaria; el CHECK
--    admite tambien 'desactivada' porque CONTRACT.md la exige para
--    "nunca alerta" (enabled=false gana siempre).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS filtros_guardados (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    name        varchar(120) NOT NULL,
    filters     jsonb NOT NULL DEFAULT '{}'::jsonb,
    frequency   text NOT NULL DEFAULT 'inmediata'
                CHECK (frequency IN ('inmediata', 'diaria', 'desactivada')),
    enabled     boolean NOT NULL DEFAULT true,
    last_run_at timestamptz,
    created_at  timestamptz DEFAULT now(),
    updated_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_filtros_guardados_usuario ON filtros_guardados (user_id, enabled);
CREATE INDEX IF NOT EXISTS idx_filtros_guardados_alertas
    ON filtros_guardados (enabled, frequency) WHERE enabled = true;

-- ---------------------------------------------------------------------------
-- 9. ofertas_guardadas
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ofertas_guardadas (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    oferta_id   uuid NOT NULL REFERENCES ofertas (id) ON DELETE CASCADE,
    folder_name text NOT NULL DEFAULT '',
    active      boolean NOT NULL DEFAULT false,
    created_at  timestamptz DEFAULT now(),
    CONSTRAINT uq_ofertas_guardadas UNIQUE (user_id, oferta_id)
);
CREATE INDEX IF NOT EXISTS idx_ofertas_guardadas_usuario ON ofertas_guardadas (user_id, active);

-- ---------------------------------------------------------------------------
-- 10. candidatos_guardados
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS candidatos_guardados (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id     uuid NOT NULL REFERENCES perfiles_empresa (id) ON DELETE CASCADE,
    trabajador_id  uuid NOT NULL REFERENCES perfiles_trabajador (id) ON DELETE CASCADE,
    postulacion_id uuid REFERENCES postulaciones (id) ON DELETE SET NULL,
    folder_name    text NOT NULL DEFAULT '',
    active         boolean NOT NULL DEFAULT false,
    created_at     timestamptz DEFAULT now(),
    CONSTRAINT uq_candidatos_guardados UNIQUE (empresa_id, trabajador_id)
);
CREATE INDEX IF NOT EXISTS idx_candidatos_guardados_empresa
    ON candidatos_guardados (empresa_id, active);

-- ---------------------------------------------------------------------------
-- 11. contacto_preferencias  (una fila por usuario; PK = user_id)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contacto_preferencias (
    user_id          uuid PRIMARY KEY REFERENCES usuarios (id) ON DELETE CASCADE,
    whatsapp_enabled boolean NOT NULL DEFAULT false,
    phone_enabled    boolean NOT NULL DEFAULT false,
    public_phone     text NOT NULL DEFAULT '',
    contact_policy   text NOT NULL DEFAULT 'in_app_first'
                     CHECK (contact_policy IN ('in_app_first', 'direct')),
    updated_at       timestamptz DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- 12. acciones_sincronizacion  (dedupe offline; PK = usuario + clientActionId)
--     status: processing = reservado antes de ejecutar; applied /
--     already_applied / conflict / rejected segun CONTRACT.md.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS acciones_sincronizacion (
    user_id          uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    client_action_id text NOT NULL,
    action_type      text NOT NULL DEFAULT 'desconocida',
    payload_hash     text NOT NULL DEFAULT 'sin-hash',
    status           text NOT NULL DEFAULT 'rejected'
                     CHECK (status IN ('processing', 'applied', 'already_applied',
                                       'rejected', 'conflict')),
    error_code       text NOT NULL DEFAULT '',
    created_at       timestamptz NOT NULL DEFAULT now(),
    processed_at     timestamptz,
    PRIMARY KEY (user_id, client_action_id)
);
CREATE INDEX IF NOT EXISTS idx_acciones_sincronizacion_estado
    ON acciones_sincronizacion (status, created_at);

-- ---------------------------------------------------------------------------
-- 13. notificaciones
--     dedupe_key es unico en el conjunto migrado (el script lo dedupa
--     en memoria); en vivo es type:userId:entityId (CONTRACT.md).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notificaciones (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    type       text NOT NULL DEFAULT 'general',
    title      text NOT NULL DEFAULT 'Aviso',
    body       text NOT NULL DEFAULT '',
    entity_id  text NOT NULL DEFAULT '',
    route      text NOT NULL DEFAULT '',
    read_at    timestamptz,
    sent_at    timestamptz,
    dedupe_key text NOT NULL UNIQUE,
    created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notificaciones_usuario
    ON notificaciones (user_id, read_at, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notificaciones_pendientes_envio
    ON notificaciones (sent_at) WHERE sent_at IS NULL;

-- ---------------------------------------------------------------------------
-- 14. dispositivos_fcm
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dispositivos_fcm (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    token       text NOT NULL UNIQUE,
    platform    text NOT NULL DEFAULT 'android',
    app_version text NOT NULL DEFAULT '',
    enabled     boolean NOT NULL DEFAULT false,
    last_seen_at timestamptz,
    created_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_dispositivos_fcm_usuario
    ON dispositivos_fcm (user_id, enabled);

-- ---------------------------------------------------------------------------
-- 15. reportes
--     NOTA: el estado en base es abierto|en_revision|resuelto|descartado
--     (script); la API responde status "open" al crear (CONTRACT.md).
--     La Edge Function debe traducir abierto <-> open.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reportes (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_id uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    entity_type text NOT NULL DEFAULT 'job' CHECK (entity_type IN ('job', 'company', 'worker')),
    entity_id   text NOT NULL DEFAULT 'desconocido',
    reason      text NOT NULL DEFAULT 'otro'
                CHECK (reason IN ('pide_dinero', 'salario_enganoso', 'ubicacion_falsa',
                                  'identidad_no_confirmada', 'acoso', 'duplicada', 'otro')),
    details     text NOT NULL DEFAULT '',
    status      text NOT NULL DEFAULT 'abierto'
                CHECK (status IN ('abierto', 'en_revision', 'resuelto', 'descartado')),
    created_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_reportes_estado ON reportes (status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reportes_entidad ON reportes (entity_type, entity_id);

-- ---------------------------------------------------------------------------
-- 16. configuracion  (clave/valor; PK = clave)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS configuracion (
    clave      text PRIMARY KEY,
    valor      text NOT NULL DEFAULT '',
    tipo       text NOT NULL DEFAULT 'string',
    updated_at timestamptz NOT NULL DEFAULT now(),
    updated_by text NOT NULL DEFAULT ''
);

-- ---------------------------------------------------------------------------
-- 17. auditoria  (solo insercion; ver 002: trigger + RLS sin UPDATE/DELETE)
--     actor_id es texto en el script (puede ser un UUID o un id legado),
--     por eso NO es FK. Se anade id propio con default para identificar
--     cada fila; el script inserta sin id y el default lo rellena.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_id    text NOT NULL DEFAULT '',
    action      text NOT NULL DEFAULT 'legacy',
    entity_type text NOT NULL DEFAULT '',
    entity_id   text NOT NULL DEFAULT '',
    before_json jsonb,
    after_json  jsonb,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_auditoria_actor ON auditoria (actor_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_auditoria_entidad ON auditoria (entity_type, entity_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- 18. sesiones  (nueva; ver cabecera. NO se migra desde Sheets.)
--     session_hash = SHA-256 hex del token opaco (64 caracteres).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sesiones (
    session_hash text PRIMARY KEY CHECK (char_length(session_hash) = 64),
    user_id      uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    expires_at   timestamptz NOT NULL,
    created_at   timestamptz NOT NULL DEFAULT now(),
    last_seen_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_sesiones_usuario ON sesiones (user_id, expires_at);
CREATE INDEX IF NOT EXISTS idx_sesiones_expiracion ON sesiones (expires_at);

-- ---------------------------------------------------------------------------
-- 19. archivos  (nueva; ver cabecera. CV y logos, bucket 'archivos'.)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS archivos (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id         uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    tipo             text NOT NULL DEFAULT 'otro' CHECK (tipo IN ('cv', 'logo', 'otro')),
    bucket           text NOT NULL DEFAULT 'archivos',
    storage_path     text NOT NULL UNIQUE,
    nombre_original  text NOT NULL DEFAULT '',
    mime_type        text NOT NULL DEFAULT '',
    tamano_bytes     bigint CHECK (tamano_bytes IS NULL OR tamano_bytes >= 0),
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_archivos_owner ON archivos (owner_id, tipo);

-- ---------------------------------------------------------------------------
-- 20. limites_uso  (nueva; ver cabecera. Libro de intentos para
--     consumir_limite() en 002. Se purga por pg_cron, > 24 h.)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS limites_uso (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES usuarios (id) ON DELETE CASCADE,
    accion     text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_limites_uso_ventana
    ON limites_uso (user_id, accion, created_at DESC);

-- ---------------------------------------------------------------------------
-- updated_at automatico en UPDATE (solo tablas que lo tienen)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

DO $$
DECLARE
    t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['usuarios', 'perfiles_trabajador', 'perfiles_empresa',
                             'ofertas', 'postulaciones', 'filtros_guardados',
                             'contacto_preferencias', 'configuracion', 'archivos']
    LOOP
        EXECUTE format(
            'DROP TRIGGER IF EXISTS trg_%s_updated_at ON %I; '
            'CREATE TRIGGER trg_%s_updated_at BEFORE UPDATE ON %I '
            'FOR EACH ROW EXECUTE FUNCTION set_updated_at();',
            t, t, t, t);
    END LOOP;
END;
$$;

-- ---------------------------------------------------------------------------
-- Vista publica: solo ofertas published y no caducadas, sin telefonos,
-- sin CV, sin notas internas. La Edge Function (publicJob) lee de aqui.
-- security_invoker = false: la vista se ejecuta con los derechos de su
-- dueno y aplica su propio filtro; el acceso directo a las tablas sigue
-- protegido por RLS (ver 002). En Supabase, conceder SELECT sobre la
-- vista a anon y authenticated.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_ofertas_publicas WITH (security_invoker = false) AS
SELECT
    o.id,
    o.empresa_id,
    e.display_name AS empresa_nombre,
    e.verified AS empresa_verificada,
    e.verification_level,
    o.title,
    o.category,
    o.description,
    o.responsibilities,
    o.benefits,
    o.requirements,
    o.city,
    o.province_code,
    p.nombre AS province_name,
    o.municipality_code,
    m.nombre AS municipality_name,
    o.locality,
    o.work_mode,
    o.contract_type,
    o.salary_min,
    o.salary_max,
    o.salary_period,
    o.includes_food,
    o.includes_transport,
    o.includes_accommodation,
    o.includes_tips,
    o.payment_notes,
    o.contact_hours,
    o.start_date,
    o.status,
    o.published_at,
    o.expires_at,
    o.created_at,
    o.updated_at
FROM ofertas o
JOIN perfiles_empresa e ON e.id = o.empresa_id
LEFT JOIN provincias p ON p.codigo = o.province_code
LEFT JOIN municipios m
       ON m.provincia_codigo = o.province_code
      AND m.codigo = o.municipality_code
WHERE o.status = 'published'
  AND (o.expires_at IS NULL OR o.expires_at > now());

-- Fin de 001_esquema.sql
