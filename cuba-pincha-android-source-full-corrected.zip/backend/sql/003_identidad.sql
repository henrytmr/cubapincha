-- ============================================================================
-- CubaPincha · 003_identidad.sql
-- Migración de identidad: usuarios.id pasa a ser el UUID de Supabase Auth.
-- Postgres 17 / Supabase. Ejecutar DESPUES de 001_esquema.sql y
-- 002_seguridad_y_funciones.sql. No reescribe 001/002: los corrige
-- con ALTER / CREATE OR REPLACE, para que 003 sea re-ejecutable.
--
-- Qué hace, en orden:
--   §1  Todas las FK a usuarios(id) pasan a ON UPDATE CASCADE (para
--       poder re-apuntar un id legado a su auth.uid() sin reescribir
--       cada tabla a mano).
--   §2  usuarios.id pierde el DEFAULT gen_random_uuid() y, si no hay
--       filas huérfanas, gana REFERENCES auth.users(id) ON DELETE CASCADE.
--   §3  Trigger handle_new_user en auth.users (crea/vincula la fila
--       de public.usuarios por email_hash al registrarse un usuario).
--   §4  S-04: consumir_limite() con pg_advisory_xact_lock (sin
--       sobrepaso del límite bajo concurrencia).
--   §5  S-05: expresar_interes() comprueba empresa activa y que el
--       trabajador no sea el dueño de la oferta.
--   §6  S-06: expirar_ofertas() deja de ser ejecutable por
--       authenticated (solo service_role / pg_cron).
--   §7  Se borra la tabla sesiones y sus helpers crear_sesion /
--       revocar_sesion / limpiar_sesiones_expiradas.
--
-- Por qué se puede borrar sesiones: la Edge Function 2.10.0
-- (work/edge-function-2.10.0/index.ts) ya no la lee ni la escribe:
-- la única mención es un comentario ("No hay sesiones opacas ni
-- tabla sesiones"). La autenticación es JWT de Supabase Auth.
-- La sesión de prueba de datos_prueba.sql
-- (token-prueba-sesion-trabajadora-001) deja de servir: revocarla
-- antes de cualquier uso real ya estaba ordenado en PLAN.md.
--
-- CÓMO APLICAR EN STAGING (cubapincha-staging, ogimwehtnhegfoamiwzm):
--   1. Crear primero los auth.users (vía A: Admin API con
--      email_confirm=true para los 14 migrados; vía B: enlace
--      mágico / restablecimiento para cada usuario) y construir
--      el mapa email_hash -> auth.uid().
--   2. Re-apuntar las filas legadas ANTES de que §2 añada la FK:
--        UPDATE usuarios SET id = '<auth uid>'
--         WHERE email_hash = '<hash del correo en minúsculas>';
--      (con ON UPDATE CASCADE de §1, perfiles, ofertas, filtros,
--      notificaciones, etc. se re-apuntan solos).
--      Si al correr 003 quedan filas con id fuera de auth.users,
--      §2 NO falla: avisa con NOTICE y se salta la FK. Re-ejecutar
--      003 tras re-apuntar para que la FK quede creada.
--   3. Correr este archivo en el SQL Editor de Supabase (o psql).
--   4. Quitar el trabajo pg_cron 'purga-sesiones-03-30' si llegó a
--      crearse (003 intenta borrarlo si pg_cron existe; si no,
--      borrarlo a mano en el panel).
--   5. Verificar después (ver §8, al final del archivo):
--      - 19 tablas en public (sesiones ya no está).
--      - pg_constraint muestra fk_usuarios_id_auth_users.
--      - auth.users tiene el trigger on_auth_user_created.
--      - Crear un usuario de prueba en Auth y comprobar que
--        aparece su fila en public.usuarios (status 'incomplete').
--      - RLS sigue vivo: anon ve ofertas publicadas y catálogo,
--        0 filas de usuarios; un usuario autenticado ve solo
--        sus filas.
--      - T13 de contrato: expressInterest 31 veces -> la 31ª
--        RATE_LIMITED (consumir_limite con lock).
--
-- EN UN POSTGRES LOCAL ("pelado", sin esquema auth): §2 y §3 se
-- saltan solos con NOTICE (auth.users no existe) y el resto se
-- verifica igual. Por eso la verificación local de este archivo
-- usa un stub de auth.users opcional (ver informe de verificación).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- §0. pgcrypto: digest() / encode() para el email_hash en handle_new_user.
--     En Supabase ya está disponible; aquí se pide explícitamente.
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- §1. FK a usuarios(id) con ON UPDATE CASCADE.
--     Se borra cualquier FK existente de cada tabla hacia usuarios
--     (el nombre lo puso Postgres al crear la tabla inline) y se
--     recrea con nombre explícito y ON UPDATE CASCADE. Se conserva
--     el ON DELETE original de 001 (SET NULL solo en
--     ofertas.created_by; CASCADE en el resto).
--     sesiones NO está en la lista: se borra en §7.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    r record;
    v_con text;
BEGIN
    FOR r IN SELECT * FROM (VALUES
        ('perfiles_trabajador',   'user_id',     'fk_perfiles_trabajador_user_id_usuarios',   'CASCADE'),
        ('perfiles_empresa',      'user_id',     'fk_perfiles_empresa_user_id_usuarios',      'CASCADE'),
        ('ofertas',               'created_by',  'fk_ofertas_created_by_usuarios',            'SET NULL'),
        ('filtros_guardados',     'user_id',     'fk_filtros_guardados_user_id_usuarios',     'CASCADE'),
        ('ofertas_guardadas',     'user_id',     'fk_ofertas_guardadas_user_id_usuarios',     'CASCADE'),
        ('contacto_preferencias', 'user_id',     'fk_contacto_preferencias_user_id_usuarios', 'CASCADE'),
        ('acciones_sincronizacion','user_id',    'fk_acciones_sincronizacion_user_id_usuarios','CASCADE'),
        ('notificaciones',        'user_id',     'fk_notificaciones_user_id_usuarios',        'CASCADE'),
        ('dispositivos_fcm',      'user_id',     'fk_dispositivos_fcm_user_id_usuarios',      'CASCADE'),
        ('reportes',              'reporter_id', 'fk_reportes_reporter_id_usuarios',          'CASCADE'),
        ('archivos',              'owner_id',    'fk_archivos_owner_id_usuarios',             'CASCADE'),
        ('limites_uso',           'user_id',     'fk_limites_uso_user_id_usuarios',           'CASCADE')
    ) AS v(tbl, col, con, del)
    LOOP
        FOR v_con IN
            SELECT conname FROM pg_constraint
             WHERE conrelid = r.tbl::regclass
               AND contype = 'f'
               AND confrelid = 'public.usuarios'::regclass
        LOOP
            EXECUTE format('ALTER TABLE %I DROP CONSTRAINT %I', r.tbl, v_con);
        END LOOP;
        EXECUTE format(
            'ALTER TABLE %I ADD CONSTRAINT %I '
            'FOREIGN KEY (%I) REFERENCES public.usuarios (id) '
            'ON DELETE %s ON UPDATE CASCADE',
            r.tbl, r.con, r.col, r.del);
        RAISE NOTICE 'FK % actualizada con ON UPDATE CASCADE', r.con;
    END LOOP;
END $$;

-- ---------------------------------------------------------------------------
-- §2. usuarios.id: sin DEFAULT, con FK a auth.users(id).
--     El id lo crea Supabase Auth (Admin API o registro), nunca la
--     app ni el script de migración: a partir de aquí, cargar
--     usuarios exige id explícito (= auth.uid()).
--     La FK solo se crea si auth.users existe Y no hay filas
--     huérfanas (id fuera de auth.users). Si hay huérfanas, se
--     avisa y se salta: re-apuntar primero (ver cabecera) y
--     re-ejecutar 003. En un Postgres local sin auth.users, se
--     salta con NOTICE y el resto de la migración sigue.
-- ---------------------------------------------------------------------------
ALTER TABLE usuarios ALTER COLUMN id DROP DEFAULT;
COMMENT ON COLUMN usuarios.id IS
    'UUID de Supabase Auth (auth.users.id). Lo crea Auth, nunca la app.';
COMMENT ON COLUMN usuarios.email_hash IS
    'SHA-256 del correo en minúsculas. Llave de unión de la migración, no identidad.';
COMMENT ON COLUMN usuarios.firebase_uid IS
    'Legado, solo auditoría. No se usa para autenticar ni para RLS.';

DO $$
DECLARE
    v_huerfanas integer := 0;
    v_existe boolean := false;
BEGIN
    IF to_regclass('auth.users') IS NULL THEN
        RAISE NOTICE '§2 saltado: auth.users no existe en esta base (Postgres local). En staging se crea la FK.';
        RETURN;
    END IF;
    SELECT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conrelid = 'public.usuarios'::regclass
           AND conname = 'fk_usuarios_id_auth_users'
    ) INTO v_existe;
    IF v_existe THEN
        RAISE NOTICE '§2: fk_usuarios_id_auth_users ya existe, no se recrea.';
        RETURN;
    END IF;
    SELECT count(*) INTO v_huerfanas FROM usuarios u
     WHERE NOT EXISTS (SELECT 1 FROM auth.users a WHERE a.id = u.id);
    IF v_huerfanas > 0 THEN
        RAISE NOTICE '§2 saltado: hay % fila(s) en usuarios con id fuera de auth.users. Re-apuntarlas por email_hash y re-ejecutar 003.', v_huerfanas;
        RETURN;
    END IF;
    ALTER TABLE usuarios
        ADD CONSTRAINT fk_usuarios_id_auth_users
        FOREIGN KEY (id) REFERENCES auth.users (id) ON DELETE CASCADE;
    RAISE NOTICE '§2: fk_usuarios_id_auth_users creada.';
END $$;

-- ---------------------------------------------------------------------------
-- §3. handle_new_user: al crear un auth.users, crea o vincula su fila
--     en public.usuarios por email_hash.
--       - Si existe una fila migrada con ese email_hash, su id se
--         actualiza al nuevo auth.uid() (ON UPDATE CASCADE de §1
--         re-apunta perfiles, ofertas, filtros, etc. automáticamente).
--       - Si no existe, se inserta con status 'incomplete'; el rol y
--         el nombre salen de raw_user_meta_data (por defecto 'worker').
--     La función se crea siempre (no depende de auth.users); el
--     trigger solo se crea donde auth.users existe (en staging sí,
--     en un Postgres local sin auth.users se salta con NOTICE).
--     SECURITY DEFINER: el trigger corre con los derechos del dueño
--     de la función, no del usuario que se registra.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION handle_new_user() RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
-- search_path incluye extensions: en Supabase pgcrypto vive en el
-- esquema extensions, no en public. Con search_path = public solo,
-- digest() no se resuelve (ERROR 42883) y el trigger aborta la
-- creación de cada auth.user ("Database error creating new user").
SET search_path = public, extensions
AS $$
DECLARE
    v_hash text;
    v_role text;
    v_display text;
    v_masked text;
BEGIN
    IF NEW.email IS NULL OR btrim(NEW.email) = '' THEN
        RETURN NEW;
    END IF;
    v_hash := encode(digest(lower(btrim(NEW.email)), 'sha256'), 'hex');
    v_role := COALESCE(NULLIF(NEW.raw_user_meta_data ->> 'role', ''), 'worker');
    IF v_role NOT IN ('worker', 'company') THEN
        v_role := 'worker';
    END IF;
    v_display := COALESCE(
        NULLIF(NEW.raw_user_meta_data ->> 'display_name', ''),
        split_part(NEW.email, '@', 1), '');
    v_masked := left(split_part(NEW.email, '@', 1), 1)
                || '***@' || split_part(NEW.email, '@', 2);

    -- La fila ya existe con este auth id (la creó registerProfile
    -- antes que el trigger): no hacer nada.
    IF EXISTS (SELECT 1 FROM public.usuarios WHERE id = NEW.id) THEN
        RETURN NEW;
    END IF;
    -- Fila migrada con este correo: vincularla al nuevo auth uid.
    UPDATE public.usuarios
       SET id = NEW.id, updated_at = now()
     WHERE email_hash = v_hash AND id <> NEW.id;
    IF FOUND THEN
        RETURN NEW;
    END IF;
    -- Usuario nuevo: crear la fila.
    BEGIN
        INSERT INTO public.usuarios
            (id, email_hash, email_masked, role, status, display_name)
        VALUES (NEW.id, v_hash, v_masked, v_role, 'incomplete', v_display);
    EXCEPTION WHEN unique_violation THEN
        -- Carrera con registerProfile: vincular por email_hash.
        UPDATE public.usuarios
           SET id = NEW.id, updated_at = now()
         WHERE email_hash = v_hash;
    END;
    RETURN NEW;
END;
$$;

DO $$
BEGIN
    IF to_regclass('auth.users') IS NULL THEN
        RAISE NOTICE '§3 trigger saltado: auth.users no existe en esta base (Postgres local). En staging se crea on_auth_user_created.';
        RETURN;
    END IF;
    DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
    CREATE TRIGGER on_auth_user_created
        AFTER INSERT ON auth.users
        FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
    RAISE NOTICE '§3: trigger on_auth_user_created creado en auth.users.';
END $$;

-- ---------------------------------------------------------------------------
-- §4. S-04: consumir_limite() con bloqueo consultivo por (usuario,
--     acción). Sin el lock, dos llamadas concurrentes pueden contar
--     a la vez y pasar de 30/h. pg_advisory_xact_lock se libera solo
--     al final de la transacción. El resto de la función es idéntico
--     a 002 (inserta el intento y luego cuenta la última hora).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION consumir_limite(
    p_usuario uuid,
    p_accion text,
    p_max integer DEFAULT 30
) RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_count integer;
BEGIN
    PERFORM pg_advisory_xact_lock(hashtext(p_usuario::text || ':' || p_accion)::bigint);
    INSERT INTO limites_uso (user_id, accion) VALUES (p_usuario, p_accion);
    SELECT count(*) INTO v_count FROM limites_uso
     WHERE user_id = p_usuario
       AND accion = p_accion
       AND created_at >= now() - interval '1 hour';
    RETURN v_count <= p_max;
END;
$$;

-- ---------------------------------------------------------------------------
-- §5. S-05: expresar_interes() comprueba en la base (defensa en
--     profundidad; la Edge Function ya lo comprueba en el handler)
--     que la empresa de la oferta esté 'active' y que el trabajador
--     no sea el dueño de la oferta. El resto es idéntico a 002.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION expresar_interes(
    p_oferta uuid,
    p_trabajador uuid,
    p_mensaje text DEFAULT ''
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_empresa_id uuid;
    v_status text;
    v_expires_at timestamptz;
    v_empresa_status text;
    v_trabajador_user uuid;
    v_app postulaciones%ROWTYPE;
BEGIN
    SELECT empresa_id, status, expires_at
      INTO v_empresa_id, v_status, v_expires_at
      FROM ofertas WHERE id = p_oferta;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'NOT_FOUND: Oferta no encontrada.';
    END IF;
    IF v_status <> 'published' THEN
        RAISE EXCEPTION 'CONFLICT: La oferta no está publicada.';
    END IF;
    IF v_expires_at IS NOT NULL AND v_expires_at <= now() THEN
        RAISE EXCEPTION 'CONFLICT: La oferta ha caducado.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM perfiles_trabajador WHERE id = p_trabajador) THEN
        RAISE EXCEPTION 'NOT_FOUND: Perfil de trabajador no encontrado.';
    END IF;

    SELECT status INTO v_empresa_status
      FROM perfiles_empresa WHERE id = v_empresa_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'CONFLICT: La empresa de la oferta no existe.';
    END IF;
    IF v_empresa_status <> 'active' THEN
        RAISE EXCEPTION 'CONFLICT: La empresa no está activa.';
    END IF;

    SELECT user_id INTO v_trabajador_user
      FROM perfiles_trabajador WHERE id = p_trabajador;
    IF EXISTS (SELECT 1 FROM perfiles_empresa
                WHERE id = v_empresa_id AND user_id = v_trabajador_user) THEN
        RAISE EXCEPTION 'CONFLICT: No puedes postular a tu propia oferta.';
    END IF;

    SELECT * INTO v_app FROM postulaciones
     WHERE oferta_id = p_oferta AND trabajador_id = p_trabajador;
    IF FOUND THEN
        RETURN jsonb_build_object(
            'applicationId', v_app.id, 'jobId', p_oferta, 'status', v_app.status,
            'alreadyExpressed', true, 'createdAt', v_app.created_at);
    END IF;

    INSERT INTO postulaciones (oferta_id, trabajador_id, empresa_id, status, message)
    VALUES (p_oferta, p_trabajador, v_empresa_id, 'sent', COALESCE(p_mensaje, ''))
    ON CONFLICT (oferta_id, trabajador_id) DO NOTHING
    RETURNING * INTO v_app;

    IF NOT FOUND THEN -- carrera con otra llamada: leer la existente
        SELECT * INTO v_app FROM postulaciones
         WHERE oferta_id = p_oferta AND trabajador_id = p_trabajador;
        RETURN jsonb_build_object(
            'applicationId', v_app.id, 'jobId', p_oferta, 'status', v_app.status,
            'alreadyExpressed', true, 'createdAt', v_app.created_at);
    END IF;

    RETURN jsonb_build_object(
        'applicationId', v_app.id, 'jobId', p_oferta, 'status', v_app.status,
        'alreadyExpressed', false, 'createdAt', v_app.created_at);
END;
$$;

-- ---------------------------------------------------------------------------
-- §6. S-06: expirar_ofertas() solo para service_role / pg_cron.
--     Es mantenimiento, no una acción de usuario: authenticated no
--     debe poder ejecutarla. (En 002 tenía GRANT a authenticated.)
--     Ojo: en Postgres, CREATE FUNCTION concede EXECUTE a PUBLIC por
--     defecto, así que revocar solo de authenticated NO basta: hay
--     que revocar también de PUBLIC. Lo mismo para
--     limpiar_limites_antiguos() (en 002 solo tenía GRANT a
--     service_role, pero PUBLIC lo dejaba abierto).
-- ---------------------------------------------------------------------------
REVOKE EXECUTE ON FUNCTION expirar_ofertas() FROM PUBLIC, authenticated;
GRANT EXECUTE ON FUNCTION expirar_ofertas() TO service_role;
REVOKE EXECUTE ON FUNCTION limpiar_limites_antiguos() FROM PUBLIC, authenticated;
GRANT EXECUTE ON FUNCTION limpiar_limites_antiguos() TO service_role;

-- ---------------------------------------------------------------------------
-- §7. Borrar sesiones y sus helpers.
--     La Edge Function 2.10.0 ya no usa la tabla (ver cabecera).
--     Se intenta borrar el trabajo pg_cron de purga de sesiones si
--     pg_cron existe; si no, borrarlo a mano en el panel de Supabase.
--     DROP TABLE CASCADE borra también sus índices y su política RLS.
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron')
       AND EXISTS (SELECT 1 FROM information_schema.tables
                    WHERE table_schema = 'cron' AND table_name = 'job') THEN
        BEGIN
            DELETE FROM cron.job WHERE jobname = 'purga-sesiones-03-30';
            RAISE NOTICE '§7: trabajo pg_cron purga-sesiones-03-30 borrado (si existía).';
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE '§7: no se pudo borrar el trabajo pg_cron purga-sesiones-03-30 (%); borrarlo a mano en el panel.', SQLERRM;
        END;
    ELSE
        RAISE NOTICE '§7: pg_cron no está instalado aquí; si el trabajo purga-sesiones-03-30 existe en staging, borrarlo en el panel.';
    END IF;
END $$;

DROP TABLE IF EXISTS sesiones CASCADE;
DROP FUNCTION IF EXISTS crear_sesion(uuid, text, timestamptz);
DROP FUNCTION IF EXISTS revocar_sesion(text);
DROP FUNCTION IF EXISTS limpiar_sesiones_expiradas();

-- ---------------------------------------------------------------------------
-- §8. Resumen de verificación (solo NOTICEs, no falla nunca).
--     Después de correr 003, comprobar en el SQL Editor:
--       SELECT count(*) FROM information_schema.tables
--        WHERE table_schema = 'public' AND table_type = 'BASE TABLE';
--         -- 19 (sesiones ya no está)
--       SELECT conname FROM pg_constraint
--        WHERE conname = 'fk_usuarios_id_auth_users';
--         -- 1 fila en staging (0 en local sin auth.users)
--       SELECT tgname FROM pg_trigger WHERE tgname = 'on_auth_user_created';
--         -- 1 fila en staging (0 en local sin auth.users)
--       SELECT to_regclass('public.sesiones');  -- NULL
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    v_tablas integer;
    v_fk integer;
    v_trg integer;
BEGIN
    SELECT count(*) INTO v_tablas FROM information_schema.tables
     WHERE table_schema = 'public' AND table_type = 'BASE TABLE';
    SELECT count(*) INTO v_fk FROM pg_constraint
     WHERE conname = 'fk_usuarios_id_auth_users';
    SELECT count(*) INTO v_trg FROM pg_trigger
     WHERE tgname = 'on_auth_user_created';
    RAISE NOTICE '003 OK: % tablas en public, fk_usuarios_id_auth_users=% (0 en local), trigger on_auth_user_created=% (0 en local), sesiones existe=%',
        v_tablas, v_fk, v_trg, (to_regclass('public.sesiones') IS NOT NULL);
END $$;

-- Fin de 003_identidad.sql
