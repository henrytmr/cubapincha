-- ============================================================================
-- CubaPincha · 002_seguridad_y_funciones.sql
-- RLS + funciones atomicas. Postgres 17 / Supabase.
-- Ejecutar DESPUES de 001_esquema.sql.
--
-- MODELO DE ACCESO (leer antes de tocar las politicas):
--   * La app NO habla directa a PostgREST: habla a la Edge Function
--     (supabase/functions/api/index.ts) con la service_role key.
--     service_role BYPASEA RLS en Supabase: es el unico escritor de
--     sesiones, auditoria, configuracion y limites_uso.
--   * anon solo lee el catalogo y las ofertas publicadas (directo o
--     a traves de v_ofertas_publicas). Nada mas.
--   * authenticated solo toca SUS filas. Las politicas usan auth.uid(),
--     que es el UUID de Supabase Auth. HOY los usuarios se autentican
--     con Firebase y su id en usuarios.id es un UUID propio de la app,
--     NO el de Supabase Auth: mientras no se adopte Supabase Auth,
--     auth.uid() es NULL para la app y estas politicas niegan el acceso
--     directo (fail-closed). Ese es el comportamiento buscado: el
--     acceso directo queda cerrado y todo pasa por la Edge Function.
--     Si algun dia se adopta Supabase Auth con los mismos UUID, las
--     politicas empiezan a aplicarse sin cambiar este archivo.
--   * Este archivo asume los roles anon / authenticated / service_role
--     y la funcion auth.uid() de Supabase. En un Postgres local
--     "pelado" hay que crearlos antes (ver PLAN.md, apartado de
--     verificacion); en Supabase ya existen.
--
-- AUDITORIA: solo insercion. Sin politicas de UPDATE/DELETE para
--   nadie, REVOKE explicito y trigger que rechaza UPDATE/DELETE.
--   (service_role tampoco deberia modificarla; si un dia hiciera falta
--   corregir una fila, hacerlo desde el panel con postgres, nunca
--   desde la app.)
-- ============================================================================

-- ---------------------------------------------------------------------------
-- RLS en las 20 tablas
-- ---------------------------------------------------------------------------
ALTER TABLE provincias ENABLE ROW LEVEL SECURITY;
ALTER TABLE municipios ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE perfiles_trabajador ENABLE ROW LEVEL SECURITY;
ALTER TABLE perfiles_empresa ENABLE ROW LEVEL SECURITY;
ALTER TABLE ofertas ENABLE ROW LEVEL SECURITY;
ALTER TABLE postulaciones ENABLE ROW LEVEL SECURITY;
ALTER TABLE filtros_guardados ENABLE ROW LEVEL SECURITY;
ALTER TABLE ofertas_guardadas ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidatos_guardados ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacto_preferencias ENABLE ROW LEVEL SECURITY;
ALTER TABLE acciones_sincronizacion ENABLE ROW LEVEL SECURITY;
ALTER TABLE notificaciones ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispositivos_fcm ENABLE ROW LEVEL SECURITY;
ALTER TABLE reportes ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracion ENABLE ROW LEVEL SECURITY;
ALTER TABLE auditoria ENABLE ROW LEVEL SECURITY;
ALTER TABLE sesiones ENABLE ROW LEVEL SECURITY;
ALTER TABLE archivos ENABLE ROW LEVEL SECURITY;
ALTER TABLE limites_uso ENABLE ROW LEVEL SECURITY;

-- ---------------------------------------------------------------------------
-- Catalogo publico (provincias / municipios): lectura para todos,
-- escritura solo via service_role (sin politica = denegado para anon/auth).
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_provincias_public_read ON provincias;
CREATE POLICY p_provincias_public_read ON provincias
    FOR SELECT TO anon, authenticated USING (activo = true);
DROP POLICY IF EXISTS p_municipios_public_read ON municipios;
CREATE POLICY p_municipios_public_read ON municipios
    FOR SELECT TO anon, authenticated USING (activo = true);

-- ---------------------------------------------------------------------------
-- Usuarios: cada uno ve y edita solo su fila.
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_usuarios_select_own ON usuarios;
CREATE POLICY p_usuarios_select_own ON usuarios
    FOR SELECT TO authenticated USING (id = auth.uid());
DROP POLICY IF EXISTS p_usuarios_update_own ON usuarios;
CREATE POLICY p_usuarios_update_own ON usuarios
    FOR UPDATE TO authenticated USING (id = auth.uid())
    WITH CHECK (id = auth.uid());

-- ---------------------------------------------------------------------------
-- Perfiles: solo el dueno. (El perfil publico de empresa que necesita
-- la vista publica lo sirve v_ofertas_publicas, no esta tabla.)
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_perfil_trabajador_own ON perfiles_trabajador;
CREATE POLICY p_perfil_trabajador_own ON perfiles_trabajador
    FOR ALL TO authenticated USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS p_perfil_empresa_own ON perfiles_empresa;
CREATE POLICY p_perfil_empresa_own ON perfiles_empresa
    FOR ALL TO authenticated USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Ofertas: publico lee published no caducadas; la empresa duena ve y
-- gestiona las suyas. La creacion/publicacion pasa por la Edge Function.
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_ofertas_public_read ON ofertas;
CREATE POLICY p_ofertas_public_read ON ofertas
    FOR SELECT TO anon, authenticated
    USING (status = 'published' AND (expires_at IS NULL OR expires_at > now()));
DROP POLICY IF EXISTS p_ofertas_company_own ON ofertas;
CREATE POLICY p_ofertas_company_own ON ofertas
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM perfiles_empresa e
                   WHERE e.id = ofertas.empresa_id AND e.user_id = auth.uid()))
    WITH CHECK (EXISTS (SELECT 1 FROM perfiles_empresa e
                        WHERE e.id = ofertas.empresa_id AND e.user_id = auth.uid()));

-- ---------------------------------------------------------------------------
-- Postulaciones: el trabajador ve las suyas; la empresa ve y actualiza
-- las de sus ofertas. El alta es via expresar_interes() (Edge Function).
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_postulaciones_worker_read ON postulaciones;
CREATE POLICY p_postulaciones_worker_read ON postulaciones
    FOR SELECT TO authenticated
    USING (EXISTS (SELECT 1 FROM perfiles_trabajador t
                   WHERE t.id = postulaciones.trabajador_id AND t.user_id = auth.uid()));
DROP POLICY IF EXISTS p_postulaciones_company ON postulaciones;
CREATE POLICY p_postulaciones_company ON postulaciones
    FOR SELECT TO authenticated
    USING (EXISTS (SELECT 1 FROM perfiles_empresa e
                   WHERE e.id = postulaciones.empresa_id AND e.user_id = auth.uid()));
DROP POLICY IF EXISTS p_postulaciones_company_update ON postulaciones;
CREATE POLICY p_postulaciones_company_update ON postulaciones
    FOR UPDATE TO authenticated
    USING (EXISTS (SELECT 1 FROM perfiles_empresa e
                   WHERE e.id = postulaciones.empresa_id AND e.user_id = auth.uid()))
    WITH CHECK (EXISTS (SELECT 1 FROM perfiles_empresa e
                        WHERE e.id = postulaciones.empresa_id AND e.user_id = auth.uid()));

-- ---------------------------------------------------------------------------
-- Listas y filtros del usuario: CRUD solo propio.
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_filtros_own ON filtros_guardados;
CREATE POLICY p_filtros_own ON filtros_guardados
    FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS p_ofertas_guardadas_own ON ofertas_guardadas;
CREATE POLICY p_ofertas_guardadas_own ON ofertas_guardadas
    FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS p_candidatos_guardados_company ON candidatos_guardados;
CREATE POLICY p_candidatos_guardados_company ON candidatos_guardados
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM perfiles_empresa e
                   WHERE e.id = candidatos_guardados.empresa_id AND e.user_id = auth.uid()))
    WITH CHECK (EXISTS (SELECT 1 FROM perfiles_empresa e
                        WHERE e.id = candidatos_guardados.empresa_id AND e.user_id = auth.uid()));
DROP POLICY IF EXISTS p_contacto_own ON contacto_preferencias;
CREATE POLICY p_contacto_own ON contacto_preferencias
    FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS p_acciones_own ON acciones_sincronizacion;
CREATE POLICY p_acciones_own ON acciones_sincronizacion
    FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Notificaciones: leer y marcar como leidas, solo propias.
-- El alta la hace el servidor (Edge Function / triggers futuros).
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_notificaciones_select_own ON notificaciones;
CREATE POLICY p_notificaciones_select_own ON notificaciones
    FOR SELECT TO authenticated USING (user_id = auth.uid());
DROP POLICY IF EXISTS p_notificaciones_update_own ON notificaciones;
CREATE POLICY p_notificaciones_update_own ON notificaciones
    FOR UPDATE TO authenticated USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Dispositivos FCM: CRUD solo propio.
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_dispositivos_own ON dispositivos_fcm;
CREATE POLICY p_dispositivos_own ON dispositivos_fcm
    FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Reportes: crear y ver los propios. Sin UPDATE/DELETE para el usuario.
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_reportes_insert_own ON reportes;
CREATE POLICY p_reportes_insert_own ON reportes
    FOR INSERT TO authenticated WITH CHECK (reporter_id = auth.uid());
DROP POLICY IF EXISTS p_reportes_select_own ON reportes;
CREATE POLICY p_reportes_select_own ON reportes
    FOR SELECT TO authenticated USING (reporter_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Sin politica para anon/authenticated (solo service_role, que bypassa
-- RLS): configuracion, auditoria, sesiones, archivos (lectura propia
-- abajo), limites_uso.
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS p_archivos_select_own ON archivos;
CREATE POLICY p_archivos_select_own ON archivos
    FOR SELECT TO authenticated USING (owner_id = auth.uid());

-- Vista publica: lectura para anon y authenticated.
GRANT SELECT ON v_ofertas_publicas TO anon, authenticated;

-- ---------------------------------------------------------------------------
-- GRANTs de tabla (la otra mitad de RLS: una politica sin GRANT no da
-- acceso). En Supabase, anon/authenticated ya traen GRANTs amplios por
-- defecto; aqui se explicitan para que el archivo tambien funcione en
-- un Postgres "pelado" y para que quede claro quien puede tocar que.
-- Las politicas de arriba siguen filtrando fila a fila.
-- ---------------------------------------------------------------------------
GRANT SELECT ON provincias, municipios, ofertas TO anon, authenticated;
GRANT SELECT ON usuarios, perfiles_trabajador, perfiles_empresa, postulaciones,
    filtros_guardados, ofertas_guardadas, candidatos_guardados,
    contacto_preferencias, acciones_sincronizacion, notificaciones,
    dispositivos_fcm, reportes, archivos TO authenticated;
GRANT INSERT ON filtros_guardados, ofertas_guardadas, candidatos_guardados,
    contacto_preferencias, acciones_sincronizacion, dispositivos_fcm,
    reportes TO authenticated;
GRANT UPDATE ON usuarios, perfiles_trabajador, perfiles_empresa, ofertas,
    postulaciones, filtros_guardados, ofertas_guardadas, candidatos_guardados,
    contacto_preferencias, acciones_sincronizacion, notificaciones,
    dispositivos_fcm TO authenticated;
GRANT DELETE ON filtros_guardados, ofertas_guardadas, candidatos_guardados,
    contacto_preferencias, acciones_sincronizacion, dispositivos_fcm
    TO authenticated;
-- Sin GRANT para anon/authenticated (solo service_role): configuracion,
-- auditoria (INSERT solo via service_role), sesiones, limites_uso.

-- ---------------------------------------------------------------------------
-- Auditoria de solo insercion: sin politicas de UPDATE/DELETE, REVOKE
-- explicito y trigger que rechaza cualquier modificacion.
-- ---------------------------------------------------------------------------
REVOKE UPDATE, DELETE ON auditoria FROM anon, authenticated, public;

CREATE OR REPLACE FUNCTION impedir_modificar_auditoria() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'La auditoria es de solo insercion: no se puede % una fila.', TG_OP;
END;
$$;

DROP TRIGGER IF EXISTS trg_auditoria_solo_insercion ON auditoria;
CREATE TRIGGER trg_auditoria_solo_insercion
    BEFORE UPDATE OR DELETE ON auditoria
    FOR EACH ROW EXECUTE FUNCTION impedir_modificar_auditoria();

-- ---------------------------------------------------------------------------
-- Funciones atomicas (SECURITY DEFINER: las llama la Edge Function con
-- service_role; el chequeo de permisos lo hace la Edge Function antes,
-- segun CONTRACT.md. Los errores usan el prefijo NOT_FOUND: / CONFLICT:
-- que index.ts traduce a 404 / 409.)
-- ---------------------------------------------------------------------------

-- expresar_interes: crea la postulacion o devuelve la existente.
-- Devuelve el mismo objeto que CONTRACT.md: applicationId, jobId,
-- status, alreadyExpressed, createdAt.
CREATE OR REPLACE FUNCTION expresar_interes(
    p_oferta uuid,
    p_trabajador uuid,
    p_mensaje text DEFAULT ''
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_empresa_id uuid;
    v_status text;
    v_expires_at timestamptz;
    v_app postulaciones%ROWTYPE;
BEGIN
    SELECT empresa_id, status, expires_at
      INTO v_empresa_id, v_status, v_expires_at
      FROM ofertas WHERE id = p_oferta;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'NOT_FOUND: Oferta no encontrada.';
    END IF;
    IF v_status <> 'published' THEN
        RAISE EXCEPTION 'CONFLICT: La oferta no está publicada.';
    END IF;
    IF v_expires_at IS NOT NULL AND v_expires_at <= now() THEN
        RAISE EXCEPTION 'CONFLICT: La oferta ha caducado.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM perfiles_trabajador WHERE id = p_trabajador) THEN
        RAISE EXCEPTION 'NOT_FOUND: Perfil de trabajador no encontrado.';
    END IF;

    SELECT * INTO v_app FROM postulaciones
     WHERE oferta_id = p_oferta AND trabajador_id = p_trabajador;
    IF FOUND THEN
        RETURN jsonb_build_object(
            'applicationId', v_app.id, 'jobId', p_oferta, 'status', v_app.status,
            'alreadyExpressed', true, 'createdAt', v_app.created_at);
    END IF;

    INSERT INTO postulaciones (oferta_id, trabajador_id, empresa_id, status, message)
    VALUES (p_oferta, p_trabajador, v_empresa_id, 'sent', COALESCE(p_mensaje, ''))
    ON CONFLICT (oferta_id, trabajador_id) DO NOTHING
    RETURNING * INTO v_app;

    IF NOT FOUND THEN -- carrera con otra llamada: leer la existente
        SELECT * INTO v_app FROM postulaciones
         WHERE oferta_id = p_oferta AND trabajador_id = p_trabajador;
        RETURN jsonb_build_object(
            'applicationId', v_app.id, 'jobId', p_oferta, 'status', v_app.status,
            'alreadyExpressed', true, 'createdAt', v_app.created_at);
    END IF;

    RETURN jsonb_build_object(
        'applicationId', v_app.id, 'jobId', p_oferta, 'status', v_app.status,
        'alreadyExpressed', false, 'createdAt', v_app.created_at);
END;
$$;

-- consumir_limite: registra el intento y dice si sigue dentro del maximo
-- en la ultima hora. Cuenta intentos, no solo altas: la fila se inserta
-- ANTES de contar. Con p_max = 30, el intento 30 pasa y el 31 no.
CREATE OR REPLACE FUNCTION consumir_limite(
    p_usuario uuid,
    p_accion text,
    p_max integer DEFAULT 30
) RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_count integer;
BEGIN
    INSERT INTO limites_uso (user_id, accion) VALUES (p_usuario, p_accion);
    SELECT count(*) INTO v_count FROM limites_uso
     WHERE user_id = p_usuario
       AND accion = p_accion
       AND created_at >= now() - interval '1 hour';
    RETURN v_count <= p_max;
END;
$$;

-- expirar_ofertas: published con expires_at vencido -> expired.
-- Devuelve cuantas caduco. Pensada para pg_cron cada hora.
CREATE OR REPLACE FUNCTION expirar_ofertas() RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_n integer;
BEGIN
    UPDATE ofertas
       SET status = 'expired', updated_at = now()
     WHERE status = 'published'
       AND expires_at IS NOT NULL
       AND expires_at <= now();
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$;

-- ---------------------------------------------------------------------------
-- Sesiones: helpers. La Edge Function consulta/inserta/borra directamente
-- en sesiones (requireAuth/handleLogin/handleLogout); estos helpers son
-- para pruebas, mantenimiento y pg_cron. El token nunca se guarda en
-- claro: solo su hash SHA-256 (ver index.ts).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION crear_sesion(
    p_user_id uuid,
    p_session_hash text,
    p_expires_at timestamptz
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO sesiones (session_hash, user_id, expires_at)
    VALUES (p_session_hash, p_user_id, p_expires_at)
    ON CONFLICT (session_hash) DO UPDATE
        SET user_id = EXCLUDED.user_id,
            expires_at = EXCLUDED.expires_at,
            last_seen_at = NULL;
END;
$$;

CREATE OR REPLACE FUNCTION revocar_sesion(p_session_hash text) RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    DELETE FROM sesiones WHERE session_hash = p_session_hash;
    RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION limpiar_sesiones_expiradas() RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_n integer;
BEGIN
    DELETE FROM sesiones WHERE expires_at <= now();
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$;

CREATE OR REPLACE FUNCTION limpiar_limites_antiguos() RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_n integer;
BEGIN
    DELETE FROM limites_uso WHERE created_at < now() - interval '24 hours';
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$;

GRANT EXECUTE ON FUNCTION expresar_interes(uuid, uuid, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION consumir_limite(uuid, text, integer) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION expirar_ofertas() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION crear_sesion(uuid, text, timestamptz) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION revocar_sesion(text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION limpiar_sesiones_expiradas() TO service_role;
GRANT EXECUTE ON FUNCTION limpiar_limites_antiguos() TO service_role;

-- ---------------------------------------------------------------------------
-- pg_cron y Storage: NO se pueden probar en un Postgres local y NO se
-- ejecutan aqui. En Supabase, hacerlo desde el panel / SQL editor del
-- proyecto cubapincha-staging, una vez aplicadas 001 y 002:
--
--   -- Extension (una vez, en Supabase: Database > Extensions, o SQL):
--   -- CREATE EXTENSION IF NOT EXISTS pg_cron;
--   SELECT cron.schedule('expirar-ofertas-cada-hora', '0 * * * *',
--                        $$SELECT expirar_ofertas();$$);
--   SELECT cron.schedule('purga-sesiones-03-30', '30 3 * * *',
--                        $$SELECT limpiar_sesiones_expiradas();$$);
--   SELECT cron.schedule('purga-limites-03-35', '35 3 * * *',
--                        $$SELECT limpiar_limites_antiguos();$$);
--   -- El resumen diario de filtros (09:00, CONTRACT.md) NO se programa
--   -- todavia: su funcion aun no existe (Edge Function fase 5).
--
--   -- Storage (una vez, en Supabase: Storage > New bucket):
--   -- Bucket 'archivos', PRIVADO (public = false). Los CV y logos se
--   -- suben con la service_role key desde la Edge Function y se
--   -- registran en la tabla archivos. Equivalente SQL (solo en Supabase,
--   -- el esquema storage no existe en un Postgres local):
--   -- INSERT INTO storage.buckets (id, name, public)
--   -- VALUES ('archivos', 'archivos', false)
--   -- ON CONFLICT (id) DO NOTHING;
--   -- Las politicas de Storage (quien sube/lee cada ruta) se definen
--   -- en el panel de Storage; no van en este archivo.
-- ---------------------------------------------------------------------------

-- Fin de 002_seguridad_y_funciones.sql
