-- ============================================================================
-- CubaPincha · 003a_fix_handle_new_user.sql — parche del trigger
-- ============================================================================
-- BUG (staging 2026-11-21): crear un auth.user fallaba con
-- "Database error creating new user" porque handle_new_user() tenía
-- SET search_path = public y llama a digest(), pero en Supabase
-- pgcrypto vive en el esquema extensions. Con search_path = public
-- solo, digest() no se resuelve (ERROR 42883), el trigger falla y
-- GoTrue aborta la creación del usuario.
--
-- FIX: search_path = public, extensions (único cambio; la lógica
-- del trigger es idéntica a la de 003_identidad.sql).
--
-- Aplicar UNA SOLA VEZ en el SQL Editor de staging, DESPUÉS de la
-- 003 y ANTES de crear ningún auth.user. Re-ejecutar la 003 después
-- es seguro: recrea esta misma función corregida.
-- ============================================================================

CREATE OR REPLACE FUNCTION handle_new_user() RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
-- search_path incluye extensions: en Supabase pgcrypto vive en el
-- esquema extensions, no en public. Con search_path = public solo,
-- digest() no se resuelve (ERROR 42883) y el trigger aborta la
-- creación de cada auth.user ("Database error creating new user").
SET search_path = public, extensions
AS $$
DECLARE
    v_hash text;
    v_role text;
    v_display text;
    v_masked text;
BEGIN
    IF NEW.email IS NULL OR btrim(NEW.email) = '' THEN
        RETURN NEW;
    END IF;
    v_hash := encode(digest(lower(btrim(NEW.email)), 'sha256'), 'hex');
    v_role := COALESCE(NULLIF(NEW.raw_user_meta_data ->> 'role', ''), 'worker');
    IF v_role NOT IN ('worker', 'company') THEN
        v_role := 'worker';
    END IF;
    v_display := COALESCE(
        NULLIF(NEW.raw_user_meta_data ->> 'display_name', ''),
        split_part(NEW.email, '@', 1), '');
    v_masked := left(split_part(NEW.email, '@', 1), 1)
                || '***@' || split_part(NEW.email, '@', 2);

    -- La fila ya existe con este auth id (la creó registerProfile
    -- antes que el trigger): no hacer nada.
    IF EXISTS (SELECT 1 FROM public.usuarios WHERE id = NEW.id) THEN
        RETURN NEW;
    END IF;
    -- Fila migrada con este correo: vincularla al nuevo auth uid.
    UPDATE public.usuarios
       SET id = NEW.id, updated_at = now()
     WHERE email_hash = v_hash AND id <> NEW.id;
    IF FOUND THEN
        RETURN NEW;
    END IF;
    -- Usuario nuevo: crear la fila.
    BEGIN
        INSERT INTO public.usuarios
            (id, email_hash, email_masked, role, status, display_name)
        VALUES (NEW.id, v_hash, v_masked, v_role, 'incomplete', v_display);
    EXCEPTION WHEN unique_violation THEN
        -- Carrera con registerProfile: vincular por email_hash.
        UPDATE public.usuarios
           SET id = NEW.id, updated_at = now()
         WHERE email_hash = v_hash;
    END;
    RETURN NEW;
END;
$$;

-- Verificación: digest() debe resolverse y dar este hash exacto.
-- (Es el email_hash del usuario legado Henry Ruz Tamayo.)
SELECT encode(digest('henryruztamayo@gmail.com', 'sha256'), 'hex') AS hash;
-- Esperado: 678fad0e89d579896b104d95e68d260ca803bb1e35fa7cab9ee7f2ccc30e4727
