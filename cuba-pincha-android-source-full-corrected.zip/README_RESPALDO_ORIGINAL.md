# CubaPincha 2.10.0 — Punto de guardado (respaldo completo)

**Fecha del respaldo:** 2026-11-21 · **App:** `com.cubapincha.job`,
`versionCode 25`, `versionName "2.10.0"` · **Entorno:** desarrollo (staging)

Si pierdes el proyecto, este archivo es el punto de partida: código fuente,
APK debug, keystore de producción, servidor completo (base + función),
datos y toda la documentación. Sigue los pasos de "Cómo retomarlo" en orden.

## Qué hay dentro

| Carpeta / archivo | Contenido |
|---|---|
| `CREDENCIALES.md` | Todas las claves y accesos del entorno de desarrollo |
| `codigo-fuente-2.10.0/` | Proyecto Android completo (Java, Gradle 8.9, AGP 8.5.2) |
| `apk/debug.apk` | APK debug 2.10.0 (8,6 MB), firmada con debug, instalada y probada |
| `keystore/` | Keystore de producción + contraseñas + guía |
| `firebase/` | Clave privada FCM (`fcm-service-account.json`) |
| `backend/edge-function/` | Edge Function `api` v2 (`index.ts`, 34 acciones) |
| `backend/sql/` | Esquema y seguridad: 001, 002, 003, 003a, 005 |
| `backend/carga-datos/` | Carga inicial: 000, 004a, 004b, 18 CSV, guías |
| `docs/` | Guía de implementación, arquitectura, auditorías |
| `docs/CAMBIO_QUITAR_PANTALLA_CONEXION.md` | Cambio pendiente: quitar la pantalla de conexión y dejar URL, anon y Client ID fijos dentro de la app |

## Cómo retomarlo

### 1. La app

1. Descomprime `codigo-fuente-2.10.0/` y ábrelo en Android Studio.
2. Crea `local.properties` en la raíz del proyecto (no va al repo):
   ```properties
   supabaseUrl=https://ogimwehtnhegfoamiwzm.supabase.co
   supabaseAnonKey=<la de CREDENCIALES.md>
   googleWebClientId=<el de CREDENCIALES.md>
   ```
   Los valores exactos están en `CREDENCIALES.md`.
3. Compila en debug (`./gradlew assembleDebug`) y prueba en el teléfono.
4. Para la release: firma con `keystore/cubapincha-release.jks` (alias
   `cubapincha`, contraseñas en `keystore/contrasenas.txt`). La release
   actual del código se firma con debug: hay que corregir `app/build.gradle`
   para leer el keystore desde `local.properties` (ver `docs/IMPLEMENTACION_APK_2.10.0.md`,
   sección de firma). El paquete final para Play es AAB, no APK.

### 2. El servidor (solo si se pierde el proyecto de Supabase)

Orden exacto en el SQL Editor, todo con éxito antes de seguir:

1. `backend/carga-datos/000_reset.sql` (vacía el esquema `public`)
2. `backend/sql/001_esquema.sql` (20 tablas, vista `v_ofertas_publicas`)
3. `backend/sql/002_seguridad_y_funciones.sql` (RLS, funciones, bucket `archivos`)
4. `backend/carga-datos/004a_carga_datos.sql` (212 INSERTs)
5. `backend/carga-datos/004b_carga_datos.sql` (84 INSERTs)
6. `backend/sql/003_identidad.sql` (identidad Supabase Auth, trigger)
7. `backend/sql/003a_fix_handle_new_user.sql` (parche del trigger)
8. `backend/sql/005_permisos_service_role.sql` (permisos tras el rebuild)

**La carga de datos (004a/004b) se ejecuta una sola vez**: la tabla de
auditoría no tiene clave única y se duplicaría. Resultado esperado: 19
tablas, 296 filas, 12 ofertas públicas.

9. Despliega la Edge Function `api` con `backend/edge-function/index.ts`
   (`verify_jwt=false`, hay acciones públicas). La función recibe la clave
   del servidor sola del entorno.
10. Activa Google en Auth → Providers con el Client ID y el secreto de
    `CREDENCIALES.md`, y los trabajos programados (caducidad de ofertas
    cada hora, purga de límites 03:35) descritos en `docs/`.

### 3. Cuentas

Crea la cuenta Auth de `henryruztamayo@gmail.com` desde el panel (auto-confirm)
y cambia su contraseña temporal tras el primer inicio. Los otros 13 usuarios
de los datos son cuentas de prueba y empresas de ejemplo: no hace falta
crearles cuenta Auth.

## Lógica de la app (resumen)

- **Entrada:** correo + contraseña (GoTrue `/auth/v1/token`) o Google
  (ID token → `/auth/v1/token?grant_type=id_token`). JWT de 1 h con refresh.
- **Sesión:** `SessionManager` guarda los tokens cifrados; ante un 401 la
  app refresca una vez y si no, cierra sesión.
- **Datos:** todo pasa por la Edge Function `api` (`/functions/v1/api`),
  respuesta única `{ok, data, error, requestId}`. 34 acciones: salud,
  catálogos, ofertas, postulaciones, perfiles, guardados, notificaciones,
  sincronización y límites de uso.
- **Reglas en el servidor:** RLS por `auth.uid()`, `public.usuarios.id =
  auth.users.id`, límites de uso por acción, caducidad de ofertas por
  trabajo programado. Nada secreto vive en la app: solo la URL pública y
  la clave anon.
- **Sin conexión:** cola offline con `clientActionId`; al reconectar se
  sincroniza con `syncActions` (formato anidado).
- **Push:** FCM solo para mensajes, no para iniciar sesión (cuenta de
  servicio pendiente de configurar).

## Conexión (resumen)

| Pieza | Valor |
|---|---|
| Proyecto Supabase | `https://ogimwehtnhegfoamiwzm.supabase.co` |
| Auth | `…/auth/v1` (correo, Google, refresh) |
| API | `…/functions/v1/api` (cabeceras `apikey` + `Authorization: Bearer <JWT>`) |
| Deep link | `cubapincha://auth/callback` |
| Paquete | `com.cubapincha.job`, minSdk 24, targetSdk 34 |

## Estructura del código

```
codigo-fuente-2.10.0/
├── app/build.gradle            # versión, SDK, firma (hoy: release = debug)
├── app/src/main/AndroidManifest.xml   # deep link, permisos, FCM
├── app/src/main/java/com/cubapincha/job/
│   ├── data/                   # SupabaseAuthRest, SupabaseApiClient, Repository
│   ├── ui/                     # Login, registro, ofertas, perfil
│   ├── util/                   # SessionManager, SecureDefaults
│   └── ...
├── gradle/wrapper/             # Gradle 8.9
└── debug.keystore              # firma debug (SHA-1 90:95:12:51:…)
```

Documentación completa de cada pantalla, cada acción y cada prueba en
`docs/IMPLEMENTACION_APK_2.10.0.md` (guía única, 15 secciones).

## Estado al hacer este respaldo (2026-11-21)

- Login por correo y por Google verificados en la app, con las dos cuentas.
- Edge Function `api` v2 activa; base con 19 tablas y 296 filas.
- APK debug analizada: 2.10.0, versionCode 25, firmada con debug, con
  restos viejos de Firebase dentro y sin la librería `androidx.browser`.
- Pendiente para publicar: firma release, claves en el código, limpieza de
  Firebase, cliente OAuth Android, pantalla de consentimiento de Google con
  URLs reales, proyecto de producción, cuenta de Play y AAB.
