# CubaPincha 2.10.0 — Guía completa de implementación en la APK

**Fecha:** 2026-11-21 · **App:** `com.cubapincha.job`, `versionCode 25`, `versionName "2.10.0"`
**Backend:** Supabase, proyecto `cubapincha-staging`, ref `ogimwehtnhegfoamiwzm`, región `us-east-1`
**Lenguaje:** Java 100 %, sin Kotlin · **HTTP:** `HttpURLConnection` + `org.json` (patrón actual del proyecto)
**Estado del backend (verificado 2026-11-21):** base con 19 tablas y 296 filas de datos reales,
Edge Function `api` desplegada y activa, login con correo y con Google habilitados,
trabajos programados activos (caducidad de ofertas cada hora, purga de límites 03:35).

Este es el único documento necesario para implementar la 2.10.0. Describe el sistema tal como
es: qué valores lleva la app, cómo se conecta, cómo se autentica, las 34 acciones de la API
con sus campos y respuestas, la lógica de cada pantalla, la sincronización sin conexión,
las notificaciones push, la firma de release y las pruebas en el teléfono. Nada de lo
escrito aquí requiere otro documento.

---

## 1. Valores de conexión

| Dato | Valor |
|---|---|
| Project URL | `https://ogimwehtnhegfoamiwzm.supabase.co` |
| Auth (GoTrue) | `https://ogimwehtnhegfoamiwzm.supabase.co/auth/v1` |
| Edge Function `api` | `https://ogimwehtnhegfoamiwzm.supabase.co/functions/v1/api` |
| Clave anon | Settings › API Keys › View legacy API keys › `anon` / `public` › Copy |
| Versión de la API | `2.0.0-supabase` (la devuelve `health`) |
| JWT | expira en 3600 s (1 h), con refresh token de rotación |

La clave anon es pública por diseño (la base filtra por RLS). Va fija en `BuildConfig`,
nunca editable desde Perfil, nunca en `SharedPreferences` sin cifrar, nunca en un repo
público. La clave `service_role` **nunca** va en la app: vive solo en el servidor.

### 1.1 `local.properties` (no va al repo)

```properties
supabaseUrl=https://ogimwehtnhegfoamiwzm.supabase.co
supabaseAnonKey=<la copiada del panel>
googleWebClientId=<ID de cliente del cliente OAuth web "CubaPincha Supabase", Google Cloud → Credenciales>
storeFile=/ruta/a/cubapincha-release.jks
storePassword=<de contrasenas.txt>
keyAlias=cubapincha
keyPassword=<de contrasenas.txt>
```

### 1.2 `app/build.gradle`

```gradle
plugins {
    id 'com.android.application'
}

android {
    namespace 'com.cubapincha.job'
    compileSdk 34

    defaultConfig {
        applicationId "com.cubapincha.job"
        minSdk 24
        targetSdk 34
        versionCode 25
        versionName "2.10.0"
    }

    signingConfigs {
        release {
            storeFile file(localProperties['storeFile'])
            storePassword localProperties['storePassword']
            keyAlias localProperties['keyAlias']
            keyPassword localProperties['keyPassword']
        }
        debug {
            storeFile file("../debug.keystore")
            storePassword "android"
            keyAlias "androiddebugkey"
            keyPassword "android"
        }
    }

    buildTypes {
        debug { debuggable true }
        release {
            minifyEnabled false
            signingConfig signingConfigs.release
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    buildFeatures { buildConfig true }

    buildTypes.each {
        it.buildConfigField "String", "SUPABASE_URL", "\"${localProperties['supabaseUrl']}\""
        it.buildConfigField "String", "SUPABASE_ANON_KEY", "\"${localProperties['supabaseAnonKey']}\""
        it.buildConfigField "String", "EDGE_FUNCTION_URL", "\"${localProperties['supabaseUrl']}/functions/v1/api\""
        it.buildConfigField "String", "GOOGLE_WEB_CLIENT_ID", "\"${localProperties['googleWebClientId']}\""
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.recyclerview:recyclerview:1.3.2'
    implementation 'androidx.swiperefreshlayout:swiperefreshlayout:1.1.0'
    implementation 'com.google.firebase:firebase-messaging:23.4.0'
    implementation 'com.google.android.gms:play-services-auth:21.2.0'
    implementation 'androidx.security:security-crypto:1.1.0-alpha06'
    implementation 'androidx.work:work-runtime:2.9.0'
    implementation 'androidx.browser:browser:1.8.0'
}
```

`androidx.browser:browser` es para el inicio con Google por navegador (respaldo, §5.4).
El resto de dependencias ya existen en la 2.9.2 y se conservan.

### 1.3 `AndroidManifest.xml` (añadir)

```xml
<!-- Deep link de retorno del inicio con Google por navegador -->
<activity android:name=".ui.AuthCallbackActivity"
    android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="cubapincha" android:host="auth" android:path="/callback" />
    </intent-filter>
</activity>
```

El servicio de push (`CubaPinchaMessagingService`) y los permisos de internet ya existen
y no cambian.

### 1.4 Firma de release

- Keystore: `cubapincha-release.jks`, alias `cubapincha`, RSA 2048, válido hasta 2051-11-14.
- SHA-1: `0D:C9:E9:A4:2A:BB:12:17:69:9F:55:3F:98:DF:D1:96:DD:63:6D:C5`
- SHA-256: `BB:D8:06:1D:C0:FF:F0:19:FE:1B:3C:ED:7B:A0:60:EC:AF:74:9F:4B:FE:48:37:5F:47:F0:DD:2D:C8:2E:21:A0`
- Contraseñas: en `work/keystore/contrasenas.txt` (0600). Copiarlas a un gestor de
  contraseñas y hacer una copia cifrada del `.jks` fuera de la máquina. Perderlo es
  perder la capacidad de actualizar la app.
- La SHA-1 de producción debe estar registrada en el cliente OAuth Android de Google
  Cloud (paquete `com.cubapincha.job`). Sin esto, el inicio con Google falla en la
  release aunque funcione en debug.
- Desinstalar la 2.9.2 firmada con debug antes de instalar la 2.10.0 firmada con
  producción: no se puede actualizar encima por el cambio de firma.

---

## 2. Arquitectura

```
┌────────────────────── APK (Java, com.cubapincha.job) ──────────────────────┐
│ UI (Fragments) → Repository → SupabaseApiClient → Edge Function api        │
│                          ↘ SupabaseAuthRest → GoTrue /auth/v1             │
│ SessionManager (EncryptedSharedPreferences) guarda access + refresh token │
│ LocalDb (caché) · SyncWorker (cola sin conexión) · FCM (push)            │
└────────────────────────────────────────────────────────────────────────────┘
        │ HTTPS                              │ HTTPS
        ▼                                    ▼
  GoTrue: registro, login,               Edge Function api (Deno):
  Google, refresh, reset                 34 acciones, verifica el JWT,
  (Postgres auth.users)                  aplica RLS y responde {ok,data,error}
        │                                    │
        └────────► Postgres 17 (public) ◄────┘
                   19 tablas · RLS por auth.uid() · Storage (bucket archivos, privado)
```

Reglas que mandan en toda la app:

1. **La base de datos manda.** RLS, constraints y funciones deciden quién ve y toca qué.
   La app nunca confía en sus propios controles: si el servidor dice `FORBIDDEN_ROLE`
   o `NOT_FOUND`, es que no se puede, aunque la pantalla lo muestre.
2. **Nada secreto en la app.** Solo la URL pública y la clave anon/publicable.
3. **Fallar cerrado.** Sin sesión válida no hay datos: se vuelve al login. Un error
   de red no se disfraza de éxito.
4. **Un solo contrato de respuesta.** Toda acción responde
   `{ok, data, error, requestId}`. `ok:false` trae `error: {code, message}`.
5. **El JWT va en la cabecera.** `Authorization: Bearer <access_token>`. Nunca en el
   cuerpo y nunca en la URL (las URLs quedan en registros).
6. **Toda petición lleva `requestId`.** UUID nuevo por petición. Sirve para
   correlacionar con los registros del servidor.

---

## 3. Archivos: qué se crea, qué se retira, qué se conserva

| Archivo | Acción |
|---|---|
| `data/SupabaseAuthRest.java` | **Crear.** §5. `signIn`, `signUp`, `signInWithGoogleIdToken`, `refresh`, `resetPassword`, `signOut`, `getUser`. |
| `data/SupabaseApiClient.java` | **Crear.** §6. Implementa `ApiClient`, POST a la Edge Function con `Authorization: Bearer`. |
| `data/FirebaseAuthRest.java` | **Retirar.** Sus métodos los sustituye `SupabaseAuthRest`. |
| `data/AppsScriptApiClient.java` | **Retirar** y sustituir por `SupabaseApiClient`. |
| `data/SecureDefaults.java` | **Retirar entero.** La URL y la anon key van en `BuildConfig` (§1). |
| `data/SessionManager.java` | **Reescribir las claves de sesión** (§4). Conservar `EncryptedSharedPreferences` y el fallo cerrado si el almacén seguro no está disponible. |
| `data/DemoApiClient.java` | Conservar intacto. El modo demo no necesita backend. |
| `data/Repository.java` | Cambiar la construcción del cliente y el refresco (§6.5). El contrato de 34 acciones no cambia. |
| `data/ApiClient.java` | Conservar la interfaz. Cambia solo `loginWithIdToken`: ahora recibe el JWT de Supabase y llama a `me` directamente (§6.5). |
| `ui/AuthCallbackActivity.java` | **Crear.** Recibe el deep link `cubapincha://auth/callback` (§5.4). |
| `ui/LoginFragment.java` | Adaptar: login por correo, Google por Play Services, reset y enlace mágico (§5). |
| `util/PushManager.java`, `util/CubaPinchaMessagingService.java` | Conservar. Solo cambia el registro del token (§10). |
| `data/SyncWorker.java`, `data/SyncScheduler.java` | Conservar la forma. La identidad que viaja es el JWT (§9). |

---

## 4. Sesión y tokens: `SessionManager`

Los tokens viven solo en `EncryptedSharedPreferences` (AndroidX Security, con Keystore).
Nada de sesión en `SharedPreferences` normal, nada en `LocalDb`, nada en registros
(`Log`), nada en `Bundle` guardado.

### 4.1 Claves (borrar todas las anteriores de sesión)

| Clave | Contenido |
|---|---|
| `KEY_SUPABASE_ACCESS_TOKEN` | JWT de acceso (1 h) |
| `KEY_SUPABASE_REFRESH_TOKEN` | Refresh token (rotación) |
| `KEY_SUPABASE_EXPIRES_AT` | `expires_at` en milisegundos (epoch) |
| `KEY_SUPABASE_USER_ID` | `auth.users.id` (UUID) |
| `KEY_SUPABASE_EMAIL` | Correo en minúsculas |
| `KEY_USER_ID`, `KEY_ROLE`, `KEY_STATUS`, `KEY_DISPLAY_NAME`, `KEY_PROFILE_PERCENT` | Perfil (de `me`), se conservan |

Borrar de `SessionManager`: `KEY_FIREBASE_API_KEY`, `KEY_FIREBASE_ID_TOKEN`,
`KEY_FIREBASE_REFRESH_TOKEN`, `KEY_PENDING_GOOGLE_ID_TOKEN`, `KEY_API_URL` editable,
`KEY_GOOGLE_CLIENT_ID` de Perfil. La pantalla Perfil deja de aceptar URL de API y
claves: esos campos se eliminan de la UI.

### 4.2 Métodos que debe exponer

```java
public void saveSupabaseSession(String accessToken, String refreshToken,
                                long expiresAtMs, String userId, String email);
public String getAccessToken();          // null si no hay sesión
public String getRefreshToken();
public long getExpiresAtMs();
public boolean isLoggedIn();             // access token presente
public boolean isAccessTokenExpiringSoon(); // expires_at - ahora < 5 min
public void clearSession();              // borra tokens y perfil
```

### 4.3 Primera apertura de la 2.10.0

La 2.10.0 no reutiliza ninguna sesión anterior: al abrir por primera vez borra los
tokens guardados y muestra una sola pantalla, "Inicia sesión de nuevo", con tres vías:
correo + contraseña nueva (enlace de restablecimiento), enlace mágico, o Google (§5).
Tras el login, `me` devuelve el perfil; si el perfil está `incomplete`, la app fuerza
completarlo con el flujo de registro ya existente.

---

## 5. Autenticación: `SupabaseAuthRest` (GoTrue)

Base: `https://ogimwehtnhegfoamiwzm.supabase.co/auth/v1` (o `BuildConfig.SUPABASE_URL + "/auth/v1"`).
**Cabecera en todas las llamadas:** `apikey: <anon key>` y `Content-Type: application/json`.
Todas las llamadas son `POST` con cuerpo JSON y se ejecutan en segundo plano
(mismo patrón que el `FirebaseAuthRest` anterior: `HttpURLConnection` + `JSONObject` +
`ApiResult`). Nunca en el hilo principal.

Respuesta de sesión (login, registro, Google, refresh):

```json
{
  "access_token": "<jwt, 1 h>",
  "refresh_token": "<token de rotación>",
  "expires_in": 3600,
  "token_type": "bearer",
  "user": { "id": "<uuid>", "email": "henryruztamayo@gmail.com", "email_confirmed_at": "..." }
}
```

Guardar: `access_token`, `refresh_token`, `expires_at = ahora + expires_in * 1000`,
`user.id`, `user.email`. Si `email_confirmed_at` es `null`, la cuenta aún no confirmó
el correo (ver §5.5).

### 5.1 Métodos y endpoints

| Método | Endpoint | Cuerpo | Respuesta |
|---|---|---|---|
| `signUp(email, password, role, displayName)` | `POST /signup` | `{email, password, data: {role, display_name}}` | Sesión + `user`. Si la confirmación está activada, el correo de confirmación llega por email y la sesión puede venir sin `access_token`: mostrar "Revisa tu correo". |
| `signIn(email, password)` | `POST /token?grant_type=password` | `{email, password}` | Sesión completa (§5, arriba). |
| `signInWithGoogleIdToken(idToken, nonce)` | `POST /token?grant_type=id_token` | `{provider: "google", id_token, nonce}` | Sesión completa. El `idToken` viene de Play Services (§5.3). |
| `refresh(refreshToken)` | `POST /token?grant_type=refresh_token` | `{refresh_token}` | Sesión nueva (rotación: el refresh token viejo queda revocado). |
| `resetPassword(email)` | `POST /recover` | `{email}` | `{}`. Siempre responde éxito aunque el correo no exista: no revelar si existe. |
| `sendMagicLink(email)` | `POST /otp` | `{email, create_user: true}` | `{}`. El enlace llega por correo y abre `cubapincha://auth/callback`. |
| `signOut(accessToken, refreshToken)` | `POST /logout` | `{}` con `Authorization: Bearer <access_token>` | `{}`. Revoca el refresh token en el servidor. |
| `getUser(accessToken)` | `GET /user` | — con `Authorization: Bearer <access_token>` | `{id, email, ...}` o 401 si el JWT no vale. |

Errores de GoTrue (cuerpo `{error, error_description, msg}` o `{message}`): traducir a
mensajes de pantalla. Los habituales: `invalid_grant` (correo o contraseña incorrectos),
`email_not_confirmed` (falta confirmar el correo), `user_already_exists` (registro
duplicado), `over_email_send_rate_limit` (demasiados correos, esperar), `weak_password`
(mínimo 6 caracteres, pedir más larga).

### 5.2 Esqueleto completo de `SupabaseAuthRest`

```java
package com.cubapincha.job.data;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class SupabaseAuthRest {

    private SupabaseAuthRest() {}

    public static class AuthTokens {
        public final String accessToken;
        public final String refreshToken;
        public final long expiresAtMs;
        public final String userId;
        public final String email;
        public AuthTokens(String accessToken, String refreshToken, long expiresAtMs,
                          String userId, String email) {
            this.accessToken = accessToken;
            this.refreshToken = refreshToken;
            this.expiresAtMs = expiresAtMs;
            this.userId = userId;
            this.email = email;
        }
    }

    private static String post(String path, JSONObject body, String accessToken)
            throws Exception {
        URL url = new URL(BuildConfig.SUPABASE_URL + "/auth/v1" + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY);
        conn.setRequestProperty("Content-Type", "application/json");
        if (accessToken != null) {
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        }
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        String text = readAll(conn, code);
        if (code < 200 || code >= 300) {
            throw new AuthException(code, text);
        }
        return text;
    }

    private static String readAll(HttpURLConnection conn, int code) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(),
                StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    /** Convierte la respuesta de sesión en AuthTokens. Devuelve null si no trae sesión
     *  (registro con confirmación de correo pendiente). */
    private static AuthTokens parseSession(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        if (!o.has("access_token")) return null;
        long expiresIn = o.optLong("expires_in", 3600);
        JSONObject user = o.optJSONObject("user");
        return new AuthTokens(
                o.getString("access_token"),
                o.getString("refresh_token"),
                System.currentTimeMillis() + expiresIn * 1000L,
                user != null ? user.optString("id", "") : "",
                user != null ? user.optString("email", "") : "");
    }

    public static ApiResult<AuthTokens> signIn(String email, String password) {
        try {
            JSONObject body = new JSONObject();
            body.put("email", email.trim().toLowerCase());
            body.put("password", password);
            return ApiResult.ok(parseSession(
                    post("/token?grant_type=password", body, null)));
        } catch (AuthException e) {
            return ApiResult.error(mapAuthError(e));
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    public static ApiResult<AuthTokens> signUp(String email, String password,
                                               String role, String displayName) {
        try {
            JSONObject body = new JSONObject();
            body.put("email", email.trim().toLowerCase());
            body.put("password", password);
            JSONObject data = new JSONObject();
            data.put("role", role);
            data.put("display_name", displayName);
            body.put("data", data);
            return ApiResult.ok(parseSession(post("/signup", body, null)));
        } catch (AuthException e) {
            return ApiResult.error(mapAuthError(e));
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    public static ApiResult<AuthTokens> signInWithGoogleIdToken(String idToken) {
        try {
            JSONObject body = new JSONObject();
            body.put("provider", "google");
            body.put("id_token", idToken);
            return ApiResult.ok(parseSession(
                    post("/token?grant_type=id_token", body, null)));
        } catch (AuthException e) {
            return ApiResult.error(mapAuthError(e));
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    public static ApiResult<AuthTokens> refresh(String refreshToken) {
        try {
            JSONObject body = new JSONObject();
            body.put("refresh_token", refreshToken);
            return ApiResult.ok(parseSession(
                    post("/token?grant_type=refresh_token", body, null)));
        } catch (AuthException e) {
            return ApiResult.error(mapAuthError(e));
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    public static ApiResult<Void> resetPassword(String email) {
        try {
            JSONObject body = new JSONObject();
            body.put("email", email.trim().toLowerCase());
            post("/recover", body, null);
            return ApiResult.ok(null);
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    public static ApiResult<Void> sendMagicLink(String email) {
        try {
            JSONObject body = new JSONObject();
            body.put("email", email.trim().toLowerCase());
            body.put("create_user", true);
            post("/otp", body, null);
            return ApiResult.ok(null);
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    public static ApiResult<Void> signOut(String accessToken) {
        try {
            post("/logout", new JSONObject(), accessToken);
            return ApiResult.ok(null);
        } catch (Exception e) {
            return ApiResult.error("NETWORK_ERROR");
        }
    }

    /** Error de GoTrue: guarda el código HTTP y el cuerpo para traducirlo. */
    public static final class AuthException extends Exception {
        public final int httpCode;
        public final String body;
        AuthException(int httpCode, String body) {
            super(body);
            this.httpCode = httpCode;
            this.body = body;
        }
    }

    /** Traduce un error de GoTrue a un código de pantalla. */
    private static String mapAuthError(AuthException e) {
        String b = e.body != null ? e.body : "";
        if (b.contains("invalid_grant")) return "INVALID_CREDENTIALS";
        if (b.contains("email_not_confirmed")) return "EMAIL_NOT_CONFIRMED";
        if (b.contains("user_already_exists") || b.contains("already registered"))
            return "EMAIL_IN_USE";
        if (b.contains("over_email_send_rate_limit")) return "RATE_LIMITED";
        if (b.contains("weak_password")) return "WEAK_PASSWORD";
        return "AUTH_FAILED";
    }
}
```

`ApiResult` ya existe en el proyecto (`data/ApiResult.java`): `ok(data)` y `error(code)`.
Si `parseSession` devuelve `null` (registro con confirmación pendiente), el llamador
muestra "Revisa tu correo" y no guarda sesión.

### 5.3 Inicio con Google por Play Services (vía principal)

El código de `LoginFragment` con `GoogleSignInClient` se conserva, con dos cambios:

```java
GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID) // ID del cliente OAuth WEB, no el Android
        .requestEmail()
        .build();
GoogleSignInClient googleClient = GoogleSignIn.getClient(requireContext(), gso);
```

Tras `getSignedInAccountFromIntent`:

```java
GoogleSignInAccount account = task.getResult(ApiException.class);
String idToken = account.getIdToken();
ApiResult<SupabaseAuthRest.AuthTokens> r =
        SupabaseAuthRest.signInWithGoogleIdToken(idToken);
// Si r.ok: SessionManager.saveSupabaseSession(...); Repository.me(...) → pantalla principal
// Si r.error: mostrar el error traducido (§5.1)
```

Notas:

- `.requestIdToken()` exige el ID de cliente del cliente OAuth **web** "CubaPincha Supabase"
  (Google Cloud → Credenciales). El cliente OAuth **Android** (paquete + SHA-1 de
  producción) es lo que hace que Play Services funcione en la release; sin él, el
  inicio con Google falla en release aunque funcione en debug.
- No se usa `account.getServerAuthCode()`: GoTrue acepta el `id_token` directo.
- Si el correo de Google ya existe como cuenta de correo, GoTrue lo une a la misma
  cuenta (mismo correo = misma cuenta). No crear dos cuentas.
- Tras el primer inicio con Google, la app llama a `me`: si el perfil es `null` o
  `status:"incomplete"`, abre el registro con el correo y el nombre de Google
  prellenados (`registerProfile`, §7.2).

### 5.4 Inicio con Google por navegador (respaldo, PKCE)

Si Play Services no está disponible o falla, abrir en Custom Tabs:

```
https://ogimwehtnhegfoamiwzm.supabase.co/auth/v1/authorize
  ?provider=google
  &redirect_to=cubapincha://auth/callback
```

`AuthCallbackActivity` recibe el deep link con `#access_token=...&refresh_token=...`
(o `?code=...` si se usa PKCE). Extraer los tokens del fragmento, guardarlos en
`SessionManager` y llamar a `me`. Las URLs de redirección registradas en Supabase son:
`cubapincha://auth/callback`, `https://cubapincha.cu/auth/callback`,
`http://localhost:3000/auth/callback` (solo desarrollo). La URL `https://cubapincha.cu`
es el Site URL.

### 5.5 Confirmación de correo

"Confirm email" está activado en Supabase. Flujo:

1. Registro por correo → Supabase envía el correo de confirmación (plantilla en español).
2. El usuario abre el enlace → su cuenta queda confirmada.
3. Si intenta entrar sin confirmar, GoTrue responde `email_not_confirmed`: mostrar
   "Confirma tu correo. Revisa la bandeja de entrada y el spam." con botón
   "Reenviar correo" (repite el `signUp` con los mismos datos o llama a
   `POST /auth/v1/resend {email, type: "signup"}`).
4. Un usuario con el correo sin confirmar **no** puede usar la app: el login se niega
   antes de llamar a `me`.

### 5.6 Refresco de tokens (reglas)

- **Proactivo:** antes de cada llamada a la API, si `expires_at - ahora < 5 min`,
  refrescar primero (§6.4).
- **Reactivo:** ante 401 de la Edge Function, refrescar **una sola vez** y reintentar
  la petición. Si vuelve a fallar, borrar la sesión local y llevar al login.
- **Rotación:** cada refresh devuelve un refresh token nuevo y revoca el viejo.
  Guardar siempre el nuevo. Si dos hilos refrescan a la vez, uno gana y el otro
  recibe 401: serializar el refresh con un bloqueo (`synchronized`) en `Repository`.
- **Cierre de sesión:** `signOut` (revoca en el servidor) + `registerDevice` inverso
  (`unregisterDevice`, §7.3) + `clearSession()` local. Aunque `signOut` falle por red,
  borrar la sesión local igualmente.

---

## 6. Transporte a la API: `SupabaseApiClient`

Un solo endpoint para las 34 acciones: `POST` a `BuildConfig.EDGE_FUNCTION_URL`.
Cuerpo JSON: `{ "action": "<accion>", "requestId": "<uuid>", ...campos }`.
**Sin `accessToken` en el cuerpo.** La autenticación va solo en cabeceras.

### 6.1 Cabeceras

| Cabecera | Valor |
|---|---|
| `Content-Type` | `application/json` |
| `apikey` | `BuildConfig.SUPABASE_ANON_KEY` (siempre, con y sin sesión) |
| `Authorization` | `Bearer <access_token>` si hay sesión; `Bearer <anon key>` si no la hay (acciones públicas) |

### 6.2 Sobre la respuesta

```json
{ "ok": true, "data": { ... }, "error": null, "requestId": "..." }
{ "ok": false, "data": null, "error": { "code": "AUTH_REQUIRED", "message": "..." }, "requestId": "..." }
```

- `ok:true` → usar `data`. `ok:false` → leer `error.code`.
- El `requestId` de la respuesta es el mismo que envió la app (o uno nuevo del
  servidor si faltaba). Guardarlo en los registros de error.
- HTTP 200 con `ok:false` es un error de aplicación, no de red: no reintentar.
  HTTP 5xx o fallo de red: reintentar una vez con espera (1 s).

### 6.3 Códigos de error y qué hace la app con cada uno

| Código | HTTP | Acción de la app |
|---|---|---|
| `AUTH_REQUIRED` | 401 | Refrescar el token una vez y reintentar (§6.4). Si vuelve a fallar, borrar sesión e ir al login. |
| `FORBIDDEN_ROLE` | 403 | Mostrar "No tienes permiso para esto". No reintentar. |
| `VALIDATION_ERROR` | 400 | Mostrar `error.message` junto al campo. No reintentar. |
| `NOT_FOUND` | 404 | Mostrar "No existe o ya no está disponible". |
| `DUPLICATE` | 409 | Mostrar "Ya existe" (p. ej. correo ya registrado, interés ya expresado). |
| `CONFLICT` | 409 | Mostrar el mensaje (transición de estado inválida, perfil cambiado: releer con `me`). |
| `RATE_LIMITED` | 429 | Mostrar "Demasiados intentos. Espera un momento." Respetar el reintento: no reintentar en bucle. |
| `INTERNAL_ERROR` | 500 | Mostrar "Error interno. Inténtalo de nuevo." Reintentar una vez. |
| `NETWORK_ERROR` | — | Sin red o timeout: guardar en cola offline si la acción lo admite (§9), si no, "Sin conexión". |

### 6.4 Esqueleto de `SupabaseApiClient`

```java
package com.cubapincha.job.data;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class SupabaseApiClient implements ApiClient {

    private final SessionManager session;
    private final Object refreshLock = new Object();

    public SupabaseApiClient(SessionManager session) { this.session = session; }

    /** Una llamada a la Edge Function. Devuelve el JSONObject "data" o lanza ApiException. */
    public JSONObject call(String action, JSONObject fields) throws ApiException {
        return call(action, fields, true);
    }

    private JSONObject call(String action, JSONObject fields, boolean allowRetry) throws ApiException {
        ensureFreshToken();
        try {
            return doCall(action, fields);
        } catch (ApiException e) {
            if (allowRetry && "AUTH_REQUIRED".equals(e.code)) {
                synchronized (refreshLock) {
                    if (refreshSession()) {
                        return doCall(action, fields); // un solo reintento
                    }
                }
            }
            throw e;
        }
    }

    private JSONObject doCall(String action, JSONObject fields) throws ApiException {
        try {
            URL url = new URL(BuildConfig.EDGE_FUNCTION_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY);
            String token = session.getAccessToken();
            conn.setRequestProperty("Authorization",
                    "Bearer " + (token != null ? token : BuildConfig.SUPABASE_ANON_KEY));

            JSONObject body = new JSONObject();
            body.put("action", action);
            body.put("requestId", UUID.randomUUID().toString());
            if (fields != null) {
                for (String k : JSONObject.getNames(fields)) body.put(k, fields.get(k));
            }
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            String text = readAll(conn, code);
            JSONObject resp = new JSONObject(text);
            if (!resp.optBoolean("ok", false)) {
                JSONObject err = resp.optJSONObject("error");
                throw new ApiException(
                        err != null ? err.optString("code", "INTERNAL_ERROR") : "INTERNAL_ERROR",
                        err != null ? err.optString("message", "") : "",
                        code);
            }
            return resp.optJSONObject("data");
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException("NETWORK_ERROR", e.getMessage(), 0);
        }
    }

    /** Refresco proactivo: si el JWT caduca en menos de 5 minutos, renovarlo ahora. */
    private void ensureFreshToken() {
        if (session.getAccessToken() == null) return;
        if (!session.isAccessTokenExpiringSoon()) return;
        synchronized (refreshLock) { refreshSession(); }
    }

    /** Renueva la sesión. Devuelve false si el refresh falló (hay que ir al login). */
    private boolean refreshSession() {
        String rt = session.getRefreshToken();
        if (rt == null) return false;
        ApiResult<SupabaseAuthRest.AuthTokens> r = SupabaseAuthRest.refresh(rt);
        if (!r.ok || r.data == null) return false;
        session.saveSupabaseSession(r.data.accessToken, r.data.refreshToken,
                r.data.expiresAtMs, r.data.userId, r.data.email);
        return true;
    }

    private static String readAll(HttpURLConnection conn, int code) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(),
                StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    /** Error de aplicación: código del contrato + HTTP. */
    public static final class ApiException extends Exception {
        public final String code;
        public final int httpCode;
        public ApiException(String code, String message, int httpCode) {
            super(message);
            this.code = code;
            this.httpCode = httpCode;
        }
    }

    // ... los 34 métodos de ApiClient (§7) llaman a call("accion", campos) ...
}
```

Reglas del transporte:

- `health` es `GET` o `POST`: usar `GET .../api?action=health` sin cabecera
  `Authorization` para la comprobación de arranque.
- Campos desconocidos en escrituras se rechazan (`VALIDATION_ERROR`): enviar
  solo los campos listados en §7 para cada acción, sin extras.
- `null` no se envía: los opcionales que no se usan se omiten del JSON.
- Timeout: 15 s de conexión, 20 s de lectura. `sync` y `jobs` pueden tardar: 30 s.
- Todas las llamadas van en segundo plano (hilo de `Repository` / `Executor`).
  Nunca en el hilo principal.

### 6.5 Cambios en `Repository`

- Construir `SupabaseApiClient` con `SessionManager`. El modo demo sigue con
  `DemoApiClient`.
- **Desaparece el paso "login contra la Edge Function".** Tras el sign-in de GoTrue
  se llama directamente a `me` con el JWT. La acción `login` de la API es solo un
  stub que responde `AUTH_REQUIRED` ("actualiza la app"): la app 2.10.0 **no la llama**.
- `login(email, password, ...)`: `SupabaseAuthRest.signIn` → guardar sesión →
  `me()` → si `status:"incomplete"`, abrir el registro.
- `loginWithGoogle(idToken, ...)`: `SupabaseAuthRest.signInWithGoogleIdToken` →
  guardar sesión → `me()` → si no hay perfil, abrir el registro prellenado.
- `logout()`: `unregisterDevice` (si hay token FCM) → `SupabaseAuthRest.signOut` →
  `clearSession()` → modo demo o login. Aunque falle la red, borrar la sesión local.
- `resetPassword(email)`: `SupabaseAuthRest.resetPassword` (siempre muestra
  "Si el correo existe, te enviamos el enlace").
- El resto de métodos de `Repository` no cambia de firma: solo cambia por dentro
  el cliente que ejecuta las acciones.

---

## 7. Las 34 acciones de la API

Todas son `POST` al endpoint de §6 salvo `health` (GET o POST). La columna "Auth"
dice si la acción exige JWT de usuario. Las públicas (`health`, `publicJob`,
`listCatalogs`, `login` stub) van sin JWT, con `Bearer <anon key>`.

### 7.1 Lecturas

| Acción | Auth | Parámetros | Respuesta (`data`) |
|---|---|---|---|
| `health` | No | — | `{status: "ok", version: "2.0.0-supabase", backend: "supabase", time}` |
| `me` | Sí | — | `{userId, role, status, displayName, emailMasked, phone, profile, unreadNotifications}`. Si el usuario de Auth aún no tiene fila de perfil: `profile: null`, `status: "incomplete"`. |
| `jobs` | Sí | `q, category, workMode, city, provinceCode, municipalityCode, mobilityScope, contractType, minSalary, maxSalary, verifiedOnly, onlyWithSalary, status, page, limit` | `{items: [job], total, hasMore, nextCursor}` |
| `job` | Sí | `id` | `{job, similar: [job], applicationStatus, saved}` |
| `publicJob` | No | `id` | `{job, similarJobs}`. Solo ofertas `published` o `closed`. Nunca devuelve teléfonos, CV ni notas internas. |
| `listCatalogs` | No | — | `{ "HAB": ["Playa", ...], ... }` municipios activos por provincia, ordenados. |
| `applications` | Sí | `status, page, limit` | `{items: [application], total, hasMore}` |
| `notifications` | Sí | `unreadOnly` (bool) | `{items: [notification], unread}` |
| `listFilters` | Sí | — | `{items: [filter]}` |
| `sync` | Sí | `since` (ISO) | `{serverTime, jobs, applications, notifications, hasMore}` |
| `contactOptions` | Sí | `entityType` (`job`\|`company`\|`worker`), `entityId` | `{entityType, entityId, whatsappEnabled, phoneEnabled, phoneMasked, phone, whatsappUrl, contactPolicy, contactHours}`. El número completo solo se entrega al propietario o a quien tiene una candidatura activa para esa oferta concreta. |

Reglas de lectura:

- Un trabajador solo ve ofertas `published` y no caducadas. Una empresa ve solo
  sus ofertas, en cualquier estado.
- `mobilityScope` se evalúa contra el perfil del trabajador: `mi_municipio` /
  `mi_provincia` comparan con su municipio/provincia, `remoto` exige
  `workMode=remoto`, `cualquier_lugar` no filtra.
- `onlyWithSalary` exige `salaryMin` o `salaryMax` presentes (un `a_convenir`
  sin montos no cuenta como salario visible).
- `jobs`: paginación por `cursor` (offset). La respuesta trae `total`, `hasMore` y
  `nextCursor`; pedir la siguiente página con `page: nextCursor`. Límite por
  página: 20 por defecto.
- `sync`: pull con `since` + `offset`, 100 por colección. Repetir con el nuevo
  `since` mientras `hasMore` sea `true`.

### 7.2 Escrituras

| Acción | Auth | Campos | Respuesta |
|---|---|---|---|
| `login` | No | — | **Stub. No llamarla.** Responde `AUTH_REQUIRED` ("actualiza la app"). Se retira en 2.11.0. |
| `logout` | Sí | `fcmToken?` | `{loggedOut: true}`. Revoca el refresh token y da de baja el FCM si viene. |
| `registerProfile` | Sí | Ver §7.3 | `{userId, role, status, displayName, isNew, profile}` (sin sesión). Límite 5/h por correo. |
| `updateProfile` | Sí | Campos del perfil + `expectedUpdatedAt?` | `{profile, status}`. Con `expectedUpdatedAt` distinto al actual: `CONFLICT`. |
| `createJob` | Sí (empresa) | Ver §7.4 | `{job}` en estado `draft`. Límite 10/h. |
| `updateJob` | Sí (empresa) | `jobId` + campos de §7.4 | `{job}` |
| `publishJob` | Sí (empresa) | `jobId` | `{job, workersNotified}`. Exige cuenta `active` y `title, category, description, workMode, contractType`. Ejecuta el matching una sola vez. Límite 10/h. |
| `changeJobStatus` | Sí (empresa) | `jobId, status` (`published`\|`paused`\|`closed`) | `{job}` (+ `workersNotified` al publicar). `draft`→`paused` es `CONFLICT`. |
| `archiveJob` | Sí (empresa) | `jobId, reason?` | `{job}` en `archived`, con `archivedAt` y `archiveReason`. |
| `deleteJob` | Sí (empresa) | `jobId` | `{deleted: true}`. Solo borrador sin candidaturas; si no, `CONFLICT`. |
| `expressInterest` | Sí (trabajador) | `jobId, message?` | `{applicationId, jobId, status, alreadyExpressed, createdAt}`. Segunda llamada: `alreadyExpressed: true`, sin duplicado. Límite 30/h. |
| `sendReminder` | Sí (trabajador) | `applicationId` | `{reminded: true}`. Solo `sent` y ≥3 días sin respuesta. |
| `changeApplicationStatus` | Sí | `applicationId, status, internalNote?` | `{applicationId, status}`. Retirar interés es `status: "withdrawn"`, solo desde `sent` o `reviewing` y solo el propio trabajador. |
| `saveJob` | Sí | `jobId, active, folderName?` | `{jobId, saved}`. `active` es booleano (no `save`). |
| `saveCandidate` | Sí (empresa) | `workerId, applicationId?, active, folderName?` | `{workerId, saved}` |
| `saveFilter` | Sí | `filterId?, name, filters, frequency, enabled` | `{filterId, name, frequency, enabled}` |
| `deleteFilter` | Sí | `filterId` | `{deleted: true}` |
| `syncActions` | Sí | `actions: [{clientActionId, actionType, payload}]` | `{results: [{clientActionId, result, errorCode, data}], applied, total, serverTime}`. Ver §9. |
| `contactEvent` | Sí | `entityType, entityId, channel` | `{recorded: true, channel}`. Límite 30/h. |
| `registerDevice` | Sí | `token, platform, appVersion?` | `{deviceId, registered: true}`. `token` es el token FCM real, nunca un UUID. |
| `unregisterDevice` | Sí | `token` | `{unregistered: true}` (idempotente). |
| `markNotificationRead` | Sí | `notificationId` o `all: true` | `{notificationId, read: true}` o `{marked, all: true}` |
| `report` | Sí | `entityType` (`job`\|`company`\|`worker`), `entityId, reason, details?` | `{reportId, status: "open"}`. En base se guarda `abierto`. Límite 10/h. |

### 7.3 `registerProfile`: campos

Obligatorios: `role` (`worker`|`company`), `termsAccepted: true`.
El correo se toma del JWT: si se envía `email`, debe ser idéntico al del JWT o
responde `VALIDATION_ERROR`. Si el correo ya existe en otra cuenta: `DUPLICATE`.

| Campo | Trabajador | Empresa |
|---|---|---|
| `displayName` | Nombre visible | Nombre de la empresa |
| `phone` | Teléfono | Teléfono |
| `city`, `country` | Texto heredado | Texto heredado |
| `headline` | Titular profesional | — |
| `skills` | Lista de habilidades | — |
| `experienceYears` | Años (número) | — |
| `availability` | Texto | — |
| `workModes` | Lista (`presencial`, `hibrido`, `remoto`, `por_zonas`) | — |
| `salaryMin`, `salaryMax` | Números (CUP) | — |
| `provinceCode`, `municipalityCode`, `locality` | Códigos de catálogo (§8.2) | Igual |
| `mobilityScope` | `mi_municipio`, `mi_provincia`, `cualquier_lugar`, `remoto` | — |
| `canRelocate`, `remoteAvailable` | Booleanos | — |
| `preferredSalaryPeriod` | Ver §8.1 | — |
| `contactHours`, `contactPreference` | Horario, `whatsapp`\|`llamada`\|`correo` | Igual |
| `legalName`, `industry`, `size`, `description`, `website`, `orgType` | — | Datos de la empresa |

Respuesta: crea o actualiza la fila de usuario (id = `auth.uid()`), el perfil por rol,
calcula `profilePercent` y activa al trabajador con ≥80 %. `isNew: true` si es la
primera vez. No devuelve sesión: la sesión ya la tiene la app desde GoTrue.

### 7.4 `createJob` / `updateJob`: campos

`createJob` exige `title` (máx 200 caracteres). `updateJob` exige `jobId` y solo los
campos que cambian. Al publicar (`publishJob`) son obligatorios
`title, category, description, workMode, contractType`.

| Campo | Tipo | Notas |
|---|---|---|
| `title` | texto | Obligatorio al crear |
| `category` | texto | Categoría (p. ej. `Gastronomía`) |
| `description` | texto | Obligatoria al publicar |
| `responsibilities`, `requirements`, `benefits` | listas / objeto | |
| `city` | texto | Heredado |
| `provinceCode`, `municipalityCode`, `locality` | códigos | Recomendados; una oferta remota puede no tener provincia |
| `workMode` | `presencial`, `hibrido`, `remoto`, `por_zonas` | Obligatorio al publicar |
| `contractType` | `tiempo_completo`, `medio_tiempo`, `temporal`, `por_proyecto`, `indefinido`, `practicas` | Obligatorio al publicar |
| `salaryMin`, `salaryMax` | números (CUP) | Si `salaryMin > salaryMax`: `VALIDATION_ERROR` |
| `salaryPeriod` | `mensual`, `quincenal`, `semanal`, `diario`, `por_hora`, `por_proyecto`, `comision`, `a_convenir` | `a_convenir` = "A convenir", sin montos. Por defecto `mensual`. |
| `includesFood`, `includesTransport`, `includesAccommodation`, `includesTips` | booleanos | |
| `paymentNotes`, `contactHours` | texto | |
| `startDate` | fecha ISO | |
| `expiresAt` | fecha ISO | Caducidad: pasada esa fecha la oferta se cierra sola (cada hora, en el servidor) |
| `experienceMin` | número | |
| `languages`, `keywords` | listas | |

El salario es siempre en CUP y nunca se convierte. `createJob` crea la oferta en
`draft`. El ciclo es: `draft` → `publishJob` → `published` ⇄ `paused` ⇄ `closed` →
`archiveJob` → `archived` (desde `archived` se puede volver a `published`, `paused`
o `closed`: es el Deshacer). `deleteJob` solo admite borradores sin candidaturas.

### 7.5 Enumeraciones canónicas

| Campo | Valores |
|---|---|
| `contractType` | `tiempo_completo`, `medio_tiempo`, `temporal`, `por_proyecto`, `indefinido`, `practicas` |
| `workMode` | `presencial`, `hibrido`, `remoto`, `por_zonas` |
| `job.status` | `draft`, `published`, `paused`, `closed`, `expired`, `archived` |
| `application.status` | `sent`, `reviewing`, `interview`, `hired`, `rejected`, `withdrawn` |
| `report.reason` | `pide_dinero`, `salario_enganoso`, `ubicacion_falsa`, `identidad_no_confirmada`, `acoso`, `duplicada`, `otro` |
| `provinceCode` | `PRI`, `ART`, `HAB`, `MAY`, `MAT`, `CFG`, `VCL`, `SSP`, `CAV`, `CAM`, `LTU`, `HOL`, `GRA`, `SCU`, `GUA`, `IJ` |
| `salaryPeriod` | `mensual`, `quincenal`, `semanal`, `diario`, `por_hora`, `por_proyecto`, `comision`, `a_convenir` |
| `mobilityScope` | `mi_municipio`, `mi_provincia`, `cualquier_lugar`, `remoto` |
| `orgType` | `privada`, `mipyme`, `cooperativa`, `tcp`, `proyecto`, `institucional` |
| `contactPreference` | `whatsapp`, `llamada`, `correo` |
| `filter.frequency` | `inmediata`, `diaria`, `desactivada` |
| `contactEvent.channel` | `whatsapp`, `call`, `copy`, `request` |
| `user.role` | `worker`, `company` |
| `user.status` | `active`, `incomplete`, `pending_verification`, `suspended`, `deleted` |

Etiquetas visibles: `tiempo_completo` → "Tiempo completo", `medio_tiempo` → "Medio tiempo",
`temporal` → "Temporal", `por_proyecto` → "Por proyecto", `indefinido` → "Indefinido",
`practicas` → "Prácticas", `por_zonas` → "Por zonas".

---

## 8. Modelos y catálogos

### 8.1 Formas JSON que devuelve la API

`me` → `data`:

```json
{
  "userId": "8e0994b5-efec-45b1-a62c-fa49b0148b94",
  "role": "worker",
  "status": "active",
  "displayName": "Henry Ruz Tamayo",
  "emailMasked": "h***@gmail.com",
  "phone": "+53 5...",
  "profile": { "...campos del perfil según §7.3, más profilePercent, updatedAt..." },
  "unreadNotifications": 2
}
```

`jobs` → `data.items[]` (oferta):

```json
{
  "id": "a46c160e-1eb7-5130-9442-3c1fb066be61",
  "companyId": "c06419b6-f589-5178-839d-823cc1e442e7",
  "companyName": "Restaurante El Jardín",
  "companyVerified": true,
  "title": "Cocinero/a de línea",
  "category": "Gastronomía",
  "description": "...",
  "responsibilities": ["..."],
  "requirements": {},
  "benefits": ["..."],
  "city": "La Habana",
  "provinceCode": "HAB",
  "provinceName": "La Habana",
  "municipalityCode": "HAB-Plaza de la Revolución",
  "municipalityName": "Plaza de la Revolución",
  "locality": "Vedado",
  "workMode": "presencial",
  "contractType": "tiempo_completo",
  "salaryMin": 8000,
  "salaryMax": 12000,
  "salaryPeriod": "mensual",
  "includesFood": true,
  "includesTransport": false,
  "includesAccommodation": false,
  "includesTips": false,
  "paymentNotes": "",
  "contactHours": "9:00 - 17:00",
  "startDate": "2026-12-01",
  "expiresAt": "2027-01-15T00:00:00Z",
  "status": "published",
  "matchScore": 82,
  "createdAt": "2026-11-20T15:00:00Z",
  "updatedAt": "2026-11-20T15:00:00Z"
}
```

`publicJob` devuelve la misma oferta **sin** teléfono, CV ni notas internas.
`job` (detalle con sesión) añade `similar: [job]`, `applicationStatus`
(`null` si no hay candidatura, o `sent`, `reviewing`, ...) y `saved` (bool).

`applications` → `items[]`:

```json
{
  "id": "...",
  "jobId": "...",
  "jobTitle": "Cocinero/a de línea",
  "jobProvinceName": "La Habana",
  "jobMunicipalityName": "Plaza de la Revolución",
  "workerId": "...",
  "workerName": "Henry Ruz Tamayo",
  "workerProvinceName": "La Habana",
  "workerMunicipalityName": "Diez de Octubre",
  "status": "sent",
  "message": "...",
  "createdAt": "...",
  "updatedAt": "...",
  "reminderSentAt": null
}
```

`notifications` → `items[]`: `{id, type, title, body, route, entityId, read, createdAt}`.
Tipos: `new_relevant_job`, `application_status`, `saved_filter_match`, `interest_received`,
`job_expiring`, `system`. `route` dice a qué pantalla lleva al tocarla.

`listFilters` → `items[]`: `{id, name, filters: {...}, frequency, enabled, lastRunAt}`.
`sync` → `{serverTime, jobs: [...], applications: [...], notifications: [...], hasMore}`.

### 8.2 Catálogos

- `listCatalogs` (pública, sin sesión) devuelve los 168 municipios activos por
  provincia: 16 provincias (`PRI` … `IJ`), ordenados por provincia y nombre.
- `Repository.refreshCatalogs()` la llama al arrancar y guarda el mapa en `LocalDb`.
  La UI (registro, filtros, crear oferta) usa el caché; si falla, usa el último
  guardado; si no hay ninguno, muestra el error y reintenta.
- El código de municipio es `PROV-nombre-normalizado` (p. ej. `HAB-Plaza de la Revolución`).

### 8.3 Matching (lo calcula el servidor)

Al publicar una oferta, el servidor calcula la afinidad con cada trabajador:
categoría 40, ubicación 25, habilidades 25, experiencia 10. Umbral configurable
(60 por defecto), tope 200 trabajadores notificados. La app solo muestra
`matchScore` (0–100) y lo ordena con `orden: "match"` en `jobs`. No recalcular
nada en el cliente.

---

## 9. Sincronización sin conexión

### 9.1 Cola de acciones (`syncActions`)

La app encola acciones con `clientActionId` (UUID nuevo por acción) y las envía
como `{clientActionId, actionType, payload}` con el **payload anidado**.
Acciones que se pueden encolar: `saveJob`, `expressInterest`, `sendReminder`,
`saveFilter`, `updateProfile`, `registerDevice`, `markNotificationRead`,
`contactEvent`, `changeApplicationStatus`, `withdrawInterest`.

El servidor reserva cada ID antes de ejecutarlo (estado `processing` + hash del
contenido): un ID repetido con el mismo contenido devuelve `already_applied`,
con otro contenido `conflict`. Resultados por acción: `applied`,
`already_applied`, `conflict`, `rejected` (+ `errorCode`). **El cliente marca
cada acción según su resultado, nunca todas por el contador global.**
Reintentar las `rejected` y las huérfanas en `processing` más de 10 minutos.

`SyncWorker` (WorkManager, ya existe) envía la cola al recuperar la red y
después hace el pull de `sync`.

### 9.2 Pull (`sync`)

`sync` con `since` (ISO, última sincronización guardada) devuelve
`{serverTime, jobs, applications, notifications, hasMore}` (100 por colección).
Repetir con el nuevo `since` mientras `hasMore` sea `true`. Persistir ofertas,
candidaturas y notificaciones en `LocalDb`. `sync` **no** devuelve ofertas
guardadas ni filtros: el cliente los relee con `listFilters` y sus acciones.

### 9.3 Borradores de empresa sin conexión

Las mutaciones de empresa (`createJob`, `updateJob`, `publishJob`,
`changeJobStatus`, `archiveJob`, `deleteJob`) **no** se sincronizan offline:
sin conexión la app guarda el borrador en el teléfono (tabla `drafts` de
`LocalDb`) y lo publica al recuperar la red (`publishDraft` ya existe en
`Repository`).

---

## 10. Notificaciones push (FCM)

- `firebase-messaging` se conserva **solo para push**. Sus valores de proyecto
  van en `BuildConfig`, no en Perfil.
- Al iniciar sesión (y al cambiar el token): `registerDevice` con
  `{token: <token FCM real>, platform: "android", appVersion: "2.10.0"}`.
  El token lo da `FirebaseMessaging.getInstance().getToken()`.
- Al cerrar sesión: `unregisterDevice` con el mismo token (idempotente).
- `CubaPinchaMessagingService` recibe el push (payload solo de datos:
  `notificationId, type, route, title, body`, sin campo `notification`) y
  muestra la notificación siempre, aunque la app esté abierta. Al tocarla,
  abre la `route` indicada.
- El servidor persiste cada notificación en la base antes de enviar el push.
  Un token que responde `UNREGISTERED`, `NOT_FOUND` o `INVALID_ARGUMENT`
  se desactiva solo (`enabled=false`): la próxima vez que la app arranque,
  vuelve a llamar a `registerDevice`.
- Alertas de filtros: `frequency=inmediata` avisa al publicar una oferta que
  coincida; `diaria` manda un resumen diario (09:00, en el servidor);
  `desactivada` nunca avisa. `enabled=false` gana siempre. Si el usuario ya
  recibió `new_relevant_job` por una oferta, no recibe además
  `saved_filter_match` por esa misma oferta.

---

## 11. Flujos por pantalla

### 11.1 Arranque (`SplashFragment`)

1. `health` por GET. Si falla por red: entrar en modo demo o mostrar "Sin conexión".
2. Si hay sesión guardada y el token no caduca en 5 min: `me()` → principal.
   Si caduca pronto: refresh → `me()`.
3. Si no hay sesión: pantalla de login (o demo).

### 11.2 Login por correo (`LoginFragment`)

1. Validar correo y contraseña (no vacíos).
2. `SupabaseAuthRest.signIn` → guardar sesión (§4.2).
3. `me()` → guardar perfil en `SessionManager` → principal.
4. `EMAIL_NOT_CONFIRMED` → pantalla de confirmación con "Reenviar correo".
5. `INVALID_CREDENTIALS` → "Correo o contraseña incorrectos."

### 11.3 Registro

1. `signUp(email, password, role, displayName)` → si viene sesión, guardarla;
   si no (confirmación pendiente), mostrar "Revisa tu correo" y esperar.
2. Tras confirmar (o si la sesión ya venía), `registerProfile` con el resto
   de campos (§7.3). El correo debe ser el mismo del JWT.
3. `DUPLICATE` → "Ya existe una cuenta con ese correo. Inicia sesión."
4. Con perfil `incomplete` la app no deja usar la principal hasta completarlo.

### 11.4 Recuperar contraseña y enlace mágico

- Recuperar: `resetPassword(email)` → siempre "Si el correo existe, te enviamos
  el enlace". El enlace abre el navegador y después el deep link; la app pide
  la contraseña nueva y la cambia con `POST /auth/v1/user` (con el JWT del
  enlace) o con el flujo de `verify` de GoTrue.
- Mágico: `sendMagicLink(email)` → "Te enviamos un enlace para entrar".
  El enlace abre `cubapincha://auth/callback` → `AuthCallbackActivity`
  extrae los tokens → `me()` → principal.

### 11.5 Inicio (`HomeFragment`, `SearchFragment`)

- `listCatalogs` desde caché para los filtros de provincia/municipio.
- `jobs` con los filtros de la UI (`q`, `provinceCode`, `municipalityCode`,
  `category`, `workMode`, `contractType`, `minSalary`, `maxSalary`,
  `verifiedOnly`, `onlyWithSalary`, orden `recent`/`salary`/`match`).
- Paginación con `nextCursor` hasta `hasMore: false`. Guardar en caché.
- Detalle: `job(id)` → `similar`, `applicationStatus`, `saved`.

### 11.6 Expresar interés (`JobDetailFragment`)

1. `expressInterest(jobId, message?)` → `applicationId`, `status: "sent"`.
2. Segunda vez: `alreadyExpressed: true`, sin duplicado: mostrar "Ya expresaste
   interés".
3. Sin conexión: encolar en `syncActions` (§9.1) y mostrar "Se enviará al
   recuperar la red".
4. `contactOptions(job, jobId)`: muestra el teléfono solo si la app ya tiene
   candidatura activa; si no, muestra el teléfono enmascarado y el botón de
   WhatsApp desactivado. Al tocar un contacto disponible: `contactEvent`.

### 11.7 Empresa: mis ofertas (`MyJobsFragment`, `CreateJobFragment`)

- `jobs` con `status` (sin filtro = todas las suyas).
- Crear: `createJob` → `draft` → `publishJob` → `published` (`workersNotified`).
- Editar: `updateJob`. Pausar/cerrar: `changeJobStatus`. Archivar: `archiveJob`.
  Borrar: `deleteJob` (solo borrador sin candidaturas).
- Candidatos: `applications` filtrado por oferta → `changeApplicationStatus`
  (`reviewing`, `interview`, `hired`, `rejected`) → `saveCandidate` para guardar.
- Recordatorio: `sendReminder(applicationId)` solo si lleva ≥3 días en `sent`.

### 11.8 Notificaciones y guardados

- `notifications(unreadOnly)` → lista; `markNotificationRead(id)` o `all: true`.
- `saveJob(jobId, active)` / `saveCandidate(workerId, applicationId, active)`.
- `saveFilter` / `listFilters` / `deleteFilter` con `frequency` y `enabled`.

### 11.9 Reportar

- `report(entityType, entityId, reason, details?)` → `{reportId, status: "open"}`.
  `reason` solo admite los valores de §7.5.

---

## 12. Seguridad en la app

1. **Nunca** la clave `service_role`, ni la contraseña de la base, ni secretos
   de servidor en la app, en `BuildConfig`, en `local.properties` del repo ni
   en registros.
2. Los tokens solo en `EncryptedSharedPreferences`. Al cerrar sesión, borrarlos.
3. Nunca registrar (`Log`) tokens, JWT, correos completos ni cuerpos de petición
   con datos personales. Los errores se registran con `requestId` y código.
4. Validar en el cliente lo que el servidor valida (salario mínimo ≤ máximo,
   campos obligatorios), pero **no confiar** en esa validación: el servidor
   es quien decide.
5. La anon key es pública, pero no va en URLs ni en `Intent` que salgan de la app.
6. Las fotos y CV (si se añaden) van al bucket `archivos` (privado) solo con
   URL firmada de corta duración, nunca con la URL pública directa.
7. `minifyEnabled false` en release (la 2.9.2 ya lo tiene así): no ofuscar en
   esta versión para poder leer los reportes de fallos.

---

## 13. Pruebas en el teléfono (contra staging)

Desinstalar la 2.9.2 antes de instalar la 2.10.0. Cuenta de prueba: crear una
cuenta nueva por correo (o usar la cuenta existente de staging). Probar en este orden:

| # | Prueba | Espera |
|---|---|---|
| T01 | `health` por GET y POST, sin sesión | `ok:true`, `version:"2.0.0-supabase"` |
| T02 | `publicJob` con una oferta publicada, sin sesión | Oferta pública, sin teléfono ni CV |
| T03 | `publicJob` con id inexistente o borrador, sin sesión | `NOT_FOUND` |
| T04 | `listCatalogs`, sin sesión | Mapa `{HAB: [...], ...}` ordenado |
| T05 | Acción `login` (no debe llamarse) | Si se llama: `AUTH_REQUIRED` "actualiza la app" |
| T06 | `me` con JWT válido, sin perfil creado | Perfil `null`, `status:"incomplete"`, sin 500 |
| T07 | `registerProfile` trabajador con JWT | Crea usuario + perfil, `isNew:true`, sin `sessionToken` |
| T08 | `registerProfile` con correo distinto al JWT | `VALIDATION_ERROR` |
| T09 | `registerProfile` repetido mismo correo | `DUPLICATE` |
| T10 | `jobs` trabajador: `q`, provincia, salario, `onlyWithSalary`, `verifiedOnly`, orden `match` | Solo `published` no caducadas, `total`/`hasMore`/`nextCursor` coherentes |
| T11 | `jobs` empresa | Solo sus ofertas, cualquier estado |
| T12 | `job` detalle + `expressInterest` | `applicationStatus:"sent"`, segunda llamada `alreadyExpressed:true`, sin duplicado |
| T13 | `expressInterest` 31 veces seguidas | La 31ª `RATE_LIMITED` (429) |
| T14 | `createJob` → `publishJob` (empresa activa) | `status:"published"`, `workersNotified` ≥ 0 |
| T15 | `changeJobStatus` con transición inválida (`draft`→`paused`) | `CONFLICT` |
| T16 | `updateJob` con `salaryMin > salaryMax` | `VALIDATION_ERROR` |
| T17 | `archiveJob` → `changeJobStatus` a `published` (deshacer) | Vuelve a `published` |
| T18 | `deleteJob` de oferta publicada | `CONFLICT`; de borrador sin candidaturas: `{deleted:true}` |
| T19 | `applications` trabajador y empresa; `changeApplicationStatus` empresa `sent`→`interview` + notificación al trabajador; trabajador retira (`withdrawn`) y vuelve a expresar interés (reactiva a `sent`) | Estados y notificaciones correctos en ambos lados |
| T20 | `notifications` + `markNotificationRead` (una y `all:true`); `saveJob`/`saveFilter`/`listFilters`; `syncActions` con el mismo `clientActionId` dos veces (`already_applied`); `contactOptions` sin candidatura (sin teléfono) y con candidatura (con teléfono); `report` (`status:"open"`); `registerDevice` + `unregisterDevice` | Todo con códigos y formas del contrato; ninguna acción sin implementar ni 500 |

Más pruebas obligatorias:

- **Login con Google** (Play Services y por navegador) con una cuenta nueva y con
  una que ya existe por correo: debe entrar a la misma cuenta.
- **Refresh:** entrar, esperar a que el JWT caduque (1 h) o forzar `expires_at`
  pasado, y usar la app: debe refrescar sola sin pedir la contraseña.
- **Sin sesión:** matar la app, borrar datos, abrir: pide login, no muestra datos
  de la cuenta anterior.
- **Sin red:** expresar interés y guardar oferta sin conexión, recuperar la red:
  la cola se envía y no se duplica (`already_applied`).
- **Roles cruzados:** un trabajador no ve lo de otro; una empresa no ve las
  ofertas de otra; `contactOptions` no entrega el teléfono sin candidatura.
- **Push:** registrar el dispositivo, publicar una oferta que coincida con el
  perfil: llega la notificación y abre la pantalla correcta.

---

## 14. Checklist final antes de publicar

- [ ] `versionCode 25`, `versionName "2.10.0"`, firma release con el keystore de
  producción (SHA-1 registrada en Google Cloud).
- [ ] `BuildConfig` con URL, anon key y `GOOGLE_WEB_CLIENT_ID` correctos (staging).
- [ ] Sin claves ni secretos en el código, en `local.properties` del repo ni en
  los registros. Sin archivos retirados (§3) en el proyecto.
- [ ] Login por correo, por Google (Play Services y navegador), restablecimiento
  y enlace mágico probados en el teléfono.
- [ ] T01–T20 pasadas contra staging.
- [ ] Refresh automático y cierre de sesión probados (el refresh viejo no sirve).
- [ ] Cola offline sin duplicados. Push registrado y recibido.
- [ ] La 2.9.2 desinstalada del teléfono de pruebas antes de instalar la 2.10.0.
- [ ] Copia cifrada del `.jks` y contraseñas en el gestor de contraseñas.

---

## 15. Referencia rápida

| Qué | Dónde |
|---|---|
| Project URL | `https://ogimwehtnhegfoamiwzm.supabase.co` |
| Edge Function | `https://ogimwehtnhegfoamiwzm.supabase.co/functions/v1/api` |
| Auth | `https://ogimwehtnhegfoamiwzm.supabase.co/auth/v1` |
| Panel (Auth › Providers) | `https://supabase.com/dashboard/project/ogimwehtnhegfoamiwzm/auth/providers` |
| Panel (Edge Functions) | `https://supabase.com/dashboard/project/ogimwehtnhegfoamiwzm/functions` |
| Google Cloud (proyecto `cubapincha`) | `https://console.cloud.google.com/apis/credentials?project=cubapincha` |
| Código de la Edge Function | `work/edge-function-2.10.0/index.ts` (34/34 acciones) |
| Esquema y seguridad de la base | `work/supabase/001_esquema.sql`, `002_seguridad_y_funciones.sql`, `003_identidad.sql`, `005_permisos_service_role.sql` |
| Keystore de producción | `work/keystore/cubapincha-release.jks` (contraseñas en `contrasenas.txt`, 0600) |
