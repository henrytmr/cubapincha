# CubaPincha — Toda la información del proyecto

**Fecha:** 2026-11-21 · **Proyecto:** `cubapincha-staging` · **Dueño:** Henry Ruz Tamayo
**Cuenta Google:** henryruztamayo@gmail.com · **GitHub:** henrytmr

Este documento reúne todo lo trabajado en el proyecto: Supabase, base de datos,
Edge Function, Auth, Google Cloud, Firebase, firma y archivos. Las claves y
contraseñas **no** llevan su valor escrito aquí: cada una indica dónde está
guardada o cómo recuperarla. Los valores secretos solo se muestran una vez
en su panel de origen; si se pierden, se revocan y se crean de nuevo.

---

## 1. Supabase — Proyecto

| Dato | Valor |
|---|---|
| Proyecto | `cubapincha-staging` |
| Ref | `ogimwehtnhegfoamiwzm` |
| URL | `https://ogimwehtnhegfoamiwzm.supabase.co` |
| Región | `us-east-1` |
| Plan | Free (NANO) |
| Organización | CubaPincha |
| Postgres | 17.12 |
| Auth | 2.198 |
| PostgREST | 14.18 |
| Estado | Healthy (verificado 2026-11-21) |
| Panel | `https://supabase.com/dashboard/project/ogimwehtnhegfoamiwzm` |

### 1.1 Claves de API (anon y publicable)

- **Clave anon (legacy):** Settings › API Keys › View legacy API keys › `anon` / `public` › Copy.
  Es pública por diseño (la base filtra por RLS). Va en `BuildConfig` de la app.
  Supabase avisa que las claves legacy se retiran a principios de 2027; ya existe
  una clave publicable `default` para usar en su lugar.
- **Clave publicable (`default`):** Settings › API Keys › clave `default`.
- **Clave `service_role`: NO va en la app ni se comparte.** Vive solo en el
  servidor (la Edge Function la recibe inyectada). Solo se consulta en el panel
  si hace falta para el servidor, nunca en el chat ni en un archivo.
- **Valor de la anon key:** no está escrito en ningún archivo de este trabajo
  porque nunca se pegó en el chat. Se copia del panel con la ruta de arriba.

### 1.2 Token personal de acceso (API de Supabase)

- Token viejo `muse-cli`: vence el **27 de noviembre de 2026**. Su valor no es
  recuperable (Supabase solo lo muestra al crearlo).
- Token nuevo `cubapincha`: creado por el usuario el 2026-11-21, organización
  CubaPincha, **sin caducidad**, permisos de lectura y escritura.
- El token está guardado en la conexión segura `custom.supabase` (bearer a
  `api.supabase.com`) y lo usa el conector de este trabajo para desplegar y
  consultar el proyecto. Su valor no se puede volver a ver: si se pierde, se
  revoca en `https://supabase.com/dashboard/account/tokens` y se crea otro.
- El token viejo `muse-cli` se puede revocar cuando ya no se use.

### 1.3 Base de datos (esquema `public`)

- **19 tablas, 296 filas** de datos reales (verificado 2026-11-21).
- Tablas: `acciones_sincronizacion`, `archivos`, `auditoria`,
  `candidatos_guardados`, `configuracion`, `contacto_preferencias`,
  `dispositivos_fcm`, `filtros_guardados`, `limites_uso`, `municipios`,
  `notificaciones`, `ofertas`, `ofertas_guardadas`, `perfiles_empresa`,
  `perfiles_trabajador`, `postulaciones`, `provincias`, `reportes`, `usuarios`.
- Vista `v_ofertas_publicas`: 12 ofertas publicadas.
- Datos: 16 provincias, 168 municipios, 14 usuarios, 5 perfiles de trabajador,
  9 perfiles de empresa, 12 ofertas, 4 postulaciones, 4 ofertas guardadas,
  4 notificaciones, 6 dispositivos FCM, 1 reporte, 11 claves de configuración,
  42 filas de auditoría.
- RLS activo en las 19 tablas. `usuarios.id` es `auth.users.id` (sin columna
  separada). Trigger `on_auth_user_created` activo.
- No existe la tabla `sesiones` (eliminada por diseño).
- Bucket Storage `archivos`: privado, límite 50 MB, 0 políticas.
- Archivos SQL (en `work/supabase/` y `work/rebuild/`):
  `000_reset.sql`, `001_esquema.sql`, `002_seguridad_y_funciones.sql`,
  `003_identidad.sql`, `003a_fix_handle_new_user.sql`,
  `004a_carga_datos.sql`, `004b_carga_datos.sql`,
  `005_permisos_service_role.sql`.

### 1.4 Trabajos programados (pg_cron)

| Trabajo | Horario | Acción | Estado |
|---|---|---|---|
| `expirar-ofertas-cada-hora` | `0 * * * *` | `SELECT public.expirar_ofertas();` | Activo (id 1) |
| `purga-limites-03-35` | `35 3 * * *` | `SELECT public.limpiar_limites_antiguos();` | Activo (id 2) |

### 1.5 Edge Function `api`

| Dato | Valor |
|---|---|
| Nombre / slug | `api` |
| URL | `https://ogimwehtnhegfoamiwzm.supabase.co/functions/v1/api` |
| ID | `8449947e-a545-49f4-81cf-b0a525eceef2` |
| Versión | 1, estado `ACTIVE` |
| `verify_jwt` | `false` (hay acciones públicas; la función verifica el JWT por su cuenta) |
| Acciones | 34 de 34 |
| Código | `work/edge-function-2.10.0/index.ts` (4.198 líneas) |
| Desplegada | 2026-11-21 23:13 CDT, vía Management API |
| Salud | `GET .../api?action=health` → `ok:true`, `version:"2.0.0-supabase"` (verificado) |
| Pruebas | `listCatalogs` y `publicJob` devuelven datos reales (verificado). Sin JWT, `me` y `jobs` responden `AUTH_REQUIRED`. |

Secretos de la función (solo nombres, los pone Supabase): `SUPABASE_URL`,
`SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` (inyectados),
`ALLOWED_ORIGIN` (por defecto `https://cubapincha.cu` en el código),
`FCM_SERVICE_ACCOUNT` (opcional, solo push), `CRON_SECRET` (opcional).

### 1.6 Auth (Supabase)

| Ajuste | Valor |
|---|---|
| Email | ENABLED, registro permitido, **Confirm email ON** |
| Google | **ENABLED** (desde 2026-11-21 23:09 CDT) |
| Demás proveedores | DISABLED |
| JWT | expira en 3600 s, refresh con rotación |
| Site URL | `https://cubapincha.cu` |
| Redirect URLs | `cubapincha://auth/callback`, `https://cubapincha.cu/auth/callback`, `http://localhost:3000/auth/callback` (solo desarrollo) |

**Cuenta creada:** henryruztamayo@gmail.com, auth id
`8e0994b5-efec-45b1-a62c-fa49b0148b94`, auto-confirmada. Corresponde al usuario
Henry Ruz Tamayo (trabajador, carpintero, Diez de Octubre), con su perfil y sus
3 ofertas guardadas vinculadas. Cambiar la contraseña temporal tras el primer
inicio de sesión. Los otros 13 usuarios de ejemplo no tienen cuenta Auth por
decisión del dueño.

---

## 2. Google Cloud — Proyecto `cubapincha`

| Dato | Valor |
|---|---|
| Proyecto | `cubapincha` |
| Número | `654632132778` |
| Cuenta | henryruztamayo@gmail.com |
| Consola | `https://console.cloud.google.com/apis/credentials?project=cubapincha` |

### 2.1 Cliente OAuth web "CubaPincha Supabase"

- Tipo: Aplicación web. Creado el 2026-11-21.
- Redirect URI autorizado (exacto):
  `https://ogimwehtnhegfoamiwzm.supabase.co/auth/v1/callback`
- **Client ID y Client Secret:** están en Google Cloud → Credenciales →
  cliente "CubaPincha Supabase". El secreto solo se muestra al crearlo; el
  ID se puede copiar del panel. Ya están pegados en Supabase › Authentication
  › Providers › Google (proveedor ENABLED, verificado).
- **Valor del Client Secret:** no está escrito en ningún archivo de este
  trabajo. Si se pierde, se genera uno nuevo en el mismo cliente y se
  actualiza en Supabase.

### 2.2 Cliente OAuth Android (pendiente de crear)

- Paquete: `com.cubapincha.job`
- Huella SHA-1 de producción (keystore de la §4):
  `0D:C9:E9:A4:2A:BB:12:17:69:9F:55:3F:98:DF:D1:96:DD:63:6D:C5`
- Sin este cliente, el inicio con Google falla en la release aunque funcione
  en debug. Crear en Google Cloud → Credenciales → Crear credenciales →
  ID de cliente de OAuth → Android.

### 2.3 Pantalla de consentimiento OAuth

- Audiencia: Externa, **en producción**. Correo de asistencia:
  henryruztamayo@gmail.com.
- **Sin guardar a propósito:** Google exige URL de página principal y URL de
  política de privacidad, y no existe sitio real de CubaPincha
  (`https://cubapincha.firebaseapp.com/` da Site Not Found). La marca guardada
  sigue como `project-654632132778`.
- Al publicar la app o el sitio: añadir una URL real de página principal y de
  política de privacidad en Información de marca
  (`https://console.cloud.google.com/auth/branding?project=cubapincha`)
  y guardar el nombre `CubaPincha`.

---

## 3. Firebase (proyecto `cubapincha`)

| Dato | Valor |
|---|---|
| Proyecto | `cubapincha` (nº 654632132778) |
| Dueño | henryruztamayo@gmail.com |
| Consola | `https://console.firebase.google.com/project/cubapincha` |
| Uso actual | Solo push (FCM). La autenticación es Supabase Auth. |

**Datos de FCM para la app** (API key, Project ID, App ID, Sender ID):
están en Firebase Console → Configuración del proyecto → Tus apps →
app Android `com.cubapincha.job`. Si la app no aparece registrada, hay que
añadirla con el paquete y la huella SHA-1 de producción (§4). La cuenta de
servicio de FCM vive solo en el servidor (secreto de Supabase), nunca en la
app ni en el repo. No hay `google-services.json` en el proyecto y no se
configuró cuenta de servicio en Apps Script.

---

## 4. Firma release (keystore de producción)

| Dato | Valor |
|---|---|
| Archivo | `work/keystore/cubapincha-release.jks` |
| Alias | `cubapincha` |
| Tipo | RSA 2048, SHA256withRSA |
| Válido | 2026-11-20 a 2051-11-14 |
| SHA-1 | `0D:C9:E9:A4:2A:BB:12:17:69:9F:55:3F:98:DF:D1:96:DD:63:6D:C5` |
| SHA-256 | `BB:D8:06:1D:C0:FF:F0:19:FE:1B:3C:ED:7B:A0:60:EC:AF:74:9F:4B:FE:48:37:5F:47:F0:DD:2D:C8:2E:21:A0` |
| Contraseñas | **Solo** en `work/keystore/contrasenas.txt` (permisos 600). Copiarlas a un gestor de contraseñas y hacer copia cifrada del `.jks`. |
| Guía | `work/keystore/README.md` |

El keystore de debug (`debug.keystore`, alias `androiddebugkey`) sigue en el
proyecto original. La 2.9.2 está firmada con debug; la 2.10.0 debe firmarse con
producción y hay que desinstalar la 2.9.2 antes de instalarla (no se puede
actualizar encima por el cambio de firma).

---

## 5. Cuentas y accesos

| Servicio | Cuenta | Estado |
|---|---|---|
| Google (Sheets, Firebase, Cloud) | henryruztamayo@gmail.com | Conectado |
| GitHub | henrytmr | Conectado, sin repositorio del proyecto |
| Supabase (vía GitHub) | henrytmr, org CubaPincha | Conectado |
| Hoja principal "CubaPincha DB" | ID `11BsGkkK6IBFHlNHKrFKdcAJCwjcqdLZGjUI6K2tu-Vo` | Solo lectura |
| Copia staging de la hoja | ID `1qVoVNIJ19hbV8JX4mE33BaDrJ7BQ1hGhyz67hdCvr0c` | — |
| Apps Script "CubaPincha API" | ID `11uRKvWB9JPbX9VDhB-UM83fhjY8lXXGyIrVZ5LHc-xFcgvDMlVegLzLa` | — |
| PC Windows | `DESKTOP-AQC626V`, usuario MrSys, Tailscale `100.117.51.111` | SSH con clave, solo con permiso explícito |

---

## 6. Archivos del trabajo (`~/workspace/CubPincha/work/`)

| Archivo | Contenido |
|---|---|
| `IMPLEMENTACION_APK_2.10.0.md` | Guía completa para implementar la 2.10.0 en la APK (un solo archivo) |
| `AUDITORIA_PROFUNDA.md` | Auditoría de la 2.9.2 |
| `SHEETS_ESTUDIO.md` | Estudio de la hoja viva (agregados, sin datos personales) |
| `ARQUITECTURA_BASE.md` | Principios y proceso de versiones |
| `AUTH_SUPABASE.md` | Diseño de Supabase Auth |
| `CONNECT_APP.md` | Guía de conexión (parcialmente desactualizada: la 003 y el despliegue ya se hicieron) |
| `PLAN.md` | Plan y verificación |
| `supabase/001_esquema.sql` | Esquema (543 líneas) |
| `supabase/002_seguridad_y_funciones.sql` | RLS y funciones (450 líneas) |
| `supabase/003_identidad.sql` | Identidad Supabase Auth (431 líneas) |
| `supabase/005_permisos_service_role.sql` | Permisos de service_role (fix del 2026-11-21) |
| `rebuild/000_reset.sql`, `004a_carga_datos.sql`, `004b_carga_datos.sql`, `REBUILD.md` | Rebuild fresco aplicado en staging |
| `migracion/csv/` (18 CSV) + `REPORTE_CSV.md` | Exportación de la hoja (303 filas) |
| `migracion/CARGA_STAGING.md` | Guía de carga |
| `edge-function-2.10.0/index.ts` + `README.md` | Edge Function `api` (34/34 acciones) |
| `keystore/cubapincha-release.jks`, `contrasenas.txt`, `README.md` | Firma de producción |
| `../custom-connectors/custom.supabase/` | Conector Supabase (Management API) con sus helpers |

Proyecto original (sin modificar): `~/workspace/CubPincha/extracted/` (443 archivos).
Paquete original: `~/workspace/CubPincha/cubapincha-supabase-paquete-2.9.2.rar`
(12.700.551 bytes).

---

## 7. Estado actual y pendientes

**Hecho y verificado en staging:**
- Base con 19 tablas y 296 filas reales, RLS, vista pública con 12 ofertas.
- Edge Function `api` desplegada, activa, con salud y lecturas públicas funcionando.
- Google Auth habilitado (cliente OAuth web + proveedor en Supabase).
- Cuenta Auth del dueño creada y vinculada a su perfil.
- pg_cron: caducidad de ofertas cada hora y purga de límites.
- Keystore de producción generado, con huellas registradas en este documento.

**Pendiente (lo hace el dueño):**
1. Crear el cliente OAuth **Android** en Google Cloud con la SHA-1 de producción (§2.2).
2. Compilar la APK 2.10.0 en Android Studio con la guía
   (`work/IMPLEMENTACION_APK_2.10.0.md`) y probarla en su teléfono:
   login por correo y por Google, T01–T20.
3. Cambiar la contraseña temporal de su cuenta Auth tras el primer inicio.
4. Al publicar la app o el sitio: guardar la pantalla de consentimiento con
   URL real de página principal y de política de privacidad (§2.3).
5. Para producción: SMTP propio en Supabase Auth (el de Supabase marca spam
   con facilidad) y proyecto Supabase de producción separado de staging.

**Nota sobre la contraseña temporal de la cuenta Auth:** es débil (la eligió el
dueño). Cambiarla tras el primer inicio de sesión. No está escrita en ningún
archivo de este trabajo.
