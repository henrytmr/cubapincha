# Cambio: quitar la pantalla de conexión — todo fijo dentro de la app

**Objetivo:** que el usuario nunca vea ni configure nada de conexión. La URL,
la clave anon y el Client ID de Google van programados dentro de la app
(`BuildConfig`), no pegados a mano en Perfil. Una instalación nueva debe
entrar directo al inicio de sesión, sin modo demo.

**Valores (están en `CREDENCIALES.md` del respaldo):**
- URL: `https://ogimwehtnhegfoamiwzm.supabase.co`
- Clave anon: la de `CREDENCIALES.md` (pública por diseño)
- Google Client ID: el del cliente `CubaPincha Supabase`

## 1. `app/build.gradle`

- Activar `buildConfig`.
- Leer `local.properties` (no va al repo) y exponer tres campos:
  - `SUPABASE_URL` (valor por defecto: la URL de arriba)
  - `SUPABASE_ANON_KEY` (sin valor por defecto: si falta, que falle la compilación)
  - `GOOGLE_WEB_CLIENT_ID` (sin valor por defecto: si falta, que falle la compilación)

## 2. `SessionManager.java` (`data/`)

- `getSupabaseApiKey()`: devolver `BuildConfig.SUPABASE_ANON_KEY`, sin leer
  preferencias.
- `getGoogleClientId()`: devolver `BuildConfig.GOOGLE_WEB_CLIENT_ID`, sin
  leer preferencias ni `SecureDefaults` (el respaldo viejo de Firebase ya
  no se usa).
- `getApiUrl()` / `getSupabaseProjectUrl()`: ya devuelven la URL fija, se quedan.
- Borrar `setSupabaseApiKey()`, `setGoogleClientId()`, `setApiUrl()` y sus
  claves de preferencias.
- El modo demo desaparece: `isDemoMode()` debe ser siempre falso en la
  versión final (si la clave falta en compilación, falla antes de instalar).

## 3. `ProfileFragment.java` (Perfil)

- Borrar toda la sección de conexión: los campos de URL, clave anon y
  Client ID de Google, el botón de probar conexión y el texto de resultado
  (`btn_test_connection`, `connection_result` y los `EditText` asociados).
- El resto del perfil se queda igual (datos del usuario, cerrar sesión, etc.).
- No debe quedar ninguna pantalla ni opción donde el usuario pueda ver o
  cambiar estos valores.

## 4. Limpieza

- Borrar `SecureDefaults.java` y sus referencias (ya no hace falta el
  respaldo de valores viejos).
- Borrar las claves viejas de Firebase de `SessionManager`.

## 5. Verificación

1. Desinstalar la app y reinstalar desde cero.
2. No debe aparecer ninguna pantalla de conexión ni de configuración.
3. Entrar con correo y con Google sin pegar nada: las dos deben funcionar.
4. La app no debe arrancar nunca en modo demo.
