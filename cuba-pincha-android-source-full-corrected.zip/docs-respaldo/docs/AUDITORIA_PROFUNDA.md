# CubaPincha — Auditoría profunda (2.9.2 / backend 1.4.1)

**Fecha:** 2026-11-21 · **Alcance:** solo el paquete extraído en
`~/workspace/CubPincha/extracted/` (443 archivos, 17 MB) y el SQL borrador en
`~/workspace/CubPincha/work/supabase/`. **No** se contactó con GitHub, Google,
Supabase ni Firebase, **no** se ejecutó código del proyecto, Gradle ni
archivos `.pyc`, y **no** se probó nada en un teléfono ni contra el despliegue
real. Lectura de texto únicamente.

**Base auditada:** app Android 2.9.2 (`com.cubapincha.job`, versionCode 24,
Java, Gradle 8.9 + AGP 8.5.2, JDK 17, compileSdk/targetSdk 34, minSdk 24),
backend Apps Script `Code.gs` 1.4.1 (3.689 líneas, 18 pestañas en Sheets),
`CONTRACT.md` 1.4.1 (34 acciones), Edge Function `index.ts` (esqueleto),
script `migrar_sheets_a_supabase.py` (640 líneas, 8 pruebas unitarias) y
SQL borrador `001_esquema.sql` (543 líneas) + `002_seguridad_y_funciones.sql`
(425 líneas). Staging Supabase ya creado: `cubapincha-staging`, Postgres 17,
región us-east-1, plan Free.

**Veredicto en una frase:** es un proyecto serio y bien documentado, con
una arquitectura honesta y varias decisiones de seguridad mejores que la
media de un MVP — pero hoy es una beta controlada, no un producto listo
para publicar: la base de datos es una hoja de cálculo, la firma de release
es una clave de debug, la migración a Supabase está al ~20 % y casi nada
de lo que importa se ha probado en un teléfono real ni contra datos reales.

---

## 1. Arquitectura actual

### Diagrama (texto)

```
Teléfono Android (Java, 70 archivos, 21 fragments)
  ├─ ui/ → data/Repository (único punto de acceso a datos)
  │     ├─ ApiClient: DemoApiClient (datos locales) | AppsScriptApiClient (HTTP)
  │     ├─ FirebaseAuthRest (Identity Toolkit por REST, sin SDK)
  │     ├─ SessionManager (EncryptedSharedPreferences + Keystore)
  │     ├─ LocalDb (SQLite v4, AES-256-GCM con CryptoHelper)
  │     └─ SyncWorker + SyncScheduler (WorkManager, cada 6 h)
  │
  ├─→ POST https://script.google.com/macros/s/…/exec   (Apps Script Web App)
  │     ├─ 301/302 → GET a script.googleusercontent.com (el cliente lo gestiona)
  │     ├─ Code.gs 1.4.1: doGet/doPost, allowlist de 34 acciones,
  │     │   verificación de ID token Firebase, sesiones opacas 24 h
  │     ├─ Google Sheets «CubaPincha DB»: 18 pestañas = la base de datos
  │     ├─ Triggers: expirar ofertas cada hora, resúmenes 9:00, purga sesiones 03:30
  │     └─ FCM HTTP v1 (cuenta de servicio en PropertiesService) → push
  │
  ├─→ Firebase Auth (proyecto `cubapincha`): correo/contraseña + Google
  │     (signInWithIdp). Sin google-services.json: valores pegados en Perfil
  │     o integrados cifrados (SecureDefaults, AES-256-GCM + PBKDF2).
  │
  └─→ Web PWA (cubapincha-web/, estática)
        └─ fetch("data/jobs.json")  ← datos de demostración locales.
            NO llama a la API. Es un folleto, no un cliente.
```

### Flujo de datos

1. **Arranque:** la app pinta primero la caché local (`LocalDb`: ofertas,
   candidaturas, notificaciones) y refresca en segundo plano; vigilante de
   15 s contra el esqueleto colgado. Sync cada 6 h y al abrir/entrar.
2. **Lectura:** `jobs` es POST con el `accessToken` en el cuerpo (Apps Script
   no puede leer cabeceras; el token nunca va en la URL). Solo `health` y
   `publicJob` son públicos.
3. **Escritura offline:** la app encola acciones con `clientActionId` (UUID)
   en `pending_actions` y las envía en lote con `syncActions`; el servidor
   reserva cada ID (`processing` + `payloadHash`) y responde por acción
   `applied / already_applied / conflict / rejected`. Las mutaciones de
   empresa (`createJob`, `publishJob`…) **no** se sincronizan: sin red se
   guarda borrador local (`drafts`) y se publica al recuperar la red.
4. **Auth:** Firebase (correo o Google) → ID token → el backend lo verifica
   con Identity Toolkit y emite una sesión opaca de 24 h (solo se guarda su
   hash SHA-256 en `sesiones`). Al caducar, la app renueva el ID token con
   el refresh token y vuelve a hacer `login`, sin pedir la contraseña.
5. **Push:** cada notificación se persiste primero en `notificaciones` y
   luego se intenta enviar por FCM HTTP v1; tokens `UNREGISTERED` /
   `NOT_FOUND` se desactivan. `unregisterDevice` al cerrar sesión.
6. **Matching y alertas:** al publicar una oferta, `runMatchingForJob_` (umbral
   `MATCH_THRESHOLD = 60` en `configuracion`) notifica a trabajadores
   compatibles (`new_relevant_job`); los filtros guardados con
   `frequency=inmediata` se evalúan contra la oferta nueva y los de
   `diaria` se resumen a las 9:00. Dedupe: si ya recibió `new_relevant_job`
   por esa oferta, no recibe además `saved_filter_match`.

### Qué funciona bien (mérito real, no cortesía)

- **Contrato primero:** `CONTRACT.md` 1.4.1 es canónico y versionado; los
  cambios van al contrato antes que al código. La Edge Function lo replica
  (`{ok, data, error, requestId}`, mismos códigos de error).
- **Un solo punto de acceso a datos:** `Repository` centraliza demo/remoto,
  refresco de sesión y cola offline. No hay llamadas HTTP desperdigadas.
- **Cifrado local serio:** `EncryptedSharedPreferences` con clave en
  Keystore; si el Keystore falla, la sesión **falla cerrada** en vez de
  degradar a texto claro (corrección de la auditoría 2.3.0). Borradores,
  cola, candidaturas y notificaciones con AES-256-GCM (`CryptoHelper`).
- **Idempotencia offline pensada:** reserva de `clientActionId` antes de
  ejecutar, `already_applied` vs `conflict` según el contenido, y el
  cliente marca cada acción por su resultado, no por un contador global.
- **Defensa en profundidad en el backend:** allowlist de acciones, campos
  desconocidos rechazados, sin stack traces ni correos completos en las
  respuestas, `LockService` en crear-ID / buscar-duplicado / escribir,
  y límites por hora (ver §2).
- **Verificación automática:** `verify_release.py` con 168 comprobaciones
  en 2.9.2 (0 fallos según `TEST_LOG.md`), `lintVitalRelease` dentro del
  build, `apksigner verify` y `aapt dump badging` en cada versión. Es
  verificación estática, no pruebas de comportamiento (ver QA-01), pero
  es mucho más de lo habitual.
- **Catálogo cubano como dato, no como texto libre:** 16 provincias +
  168 municipios sembrados, códigos `PROV-nombre-normalizado`, ubicación
  estructurada en perfiles, ofertas y filtros. Eso es lo que hace posible
  el matching por `mi_municipio / mi_provincia`.
- **La migración ya tiene esqueleto útil:** el script de migración es
  tolerante (nunca lanza, omite o corrige y lo registra en el informe),
  `ON CONFLICT DO NOTHING` (re-ejecutable), UUID5 determinista para IDs
  legados (`job-001` → mismo UUID siempre), y el SQL borrador reproduce
  fielmente sus columnas y enums (ver §3.5).

---

## 2. Seguridad

Leyenda: **Cerrado** = verificado en el código y ya corregido en 1.4.1 /
2.9.2. **Abierto** = sigue vigente. **Parcial** = corregido en un sitio y
abierto en otro. No se inventa ninguna vulnerabilidad: todo lo que sigue
cita archivo y observación concreta.

### 2.1 Los 6 hallazgos altos de la auditoría (LEEME_ENTREGA.md)

| # | Hallazgo | Estado | Evidencia |
|---|---|---|---|
| SEC-01 | Correo sin verificar | **Parcial — abierto por defecto, a propósito** | `Code.gs:12-15` y `DEFAULT_CONFIG`: `REQUIRE_EMAIL_VERIFIED: '0'` por defecto, con el comentario explícito «NO poner '1' hasta que la app envíe el correo de verificación». `requireVerifiedEmail_` existe (Code.gs:877). En la Edge Function, en cambio, `index.ts: requireVerified` usa `"1"` por defecto. **Al migrar, el comportamiento cambia sin que nadie lo haya decidido en una reunión:** cuentas que hoy entran sin verificar dejarán de entrar. Es la decisión correcta a largo plazo, pero hay que coordinarla con el envío del correo de verificación en la app (Fase 3 de la guía) y comunicarla, no descubrirla en staging. |
| SEC-09 | Release firmada con clave de debug | **Abierto — el más grave para publicar** | `app/build.gradle`: `release { signingConfig signingConfigs.debug }` con `storeFile file("../debug.keystore")`, alias `androiddebugkey`, contraseñas `android` (las de debug, públicas y conocidas). `BUILD_REPORT.md` lo documenta sin tapujos: la llave de 2.9.1 se perdió porque vivía en `~/.android`, la 2.9.2 se fijó al proyecto para que todas las compilaciones firmen igual. Eso estabiliza el problema de las huellas de Firebase, pero **no** lo convierte en una firma de producción: cualquiera con el RAR tiene la clave privada, y Google Play la rechazará / no se debe publicar con ella. Además la 2.9.2 no se instala sobre la 2.9.1 (paquete y firma distintos): hay que desinstalar primero y la sesión local se pierde. |
| LOG-01 | Salario mínimo mayor que máximo | **Cerrado en backend y en SQL; verificar en app** | `Code.gs` P4 (1.4.1): valida min ≤ max. El script de migración (`salario()`) borra ambos si min > max y lo registra en el informe. El SQL borrador (`001`, `ofertas` y `perfiles_trabajador`) añade `CHECK (salary_min <= salary_max)`. No encontré la misma validación en los formularios de la app en esta lectura (CreateJobFragment / registros no revisados línea a línea): el servidor la impone, pero el usuario solo se entera tras enviar. |
| CON-01 | La web no usa la API | **Abierto** | `cubapincha-web/js/app.js:40`: `fetch("data/jobs.json")`. `data/jobs.json` son ofertas de demostración (IDs `demo-j1`…). Ningún `fetch` a `/exec`, a Supabase ni a ninguna API en toda la web. La web y la app pueden mostrar ofertas distintas sin que nadie lo note; un enlace `cubapincha.cu/ofertas/{id}` de la web no corresponde a una oferta real. Es también una oportunidad (ver §4, P1). |
| CON-04 | Sheets no escala | **Abierto por diseño — es la razón de la migración** | `Code.gs:673-710`: `readTable_` lee la pestaña entera en cada operación (`getSheet_` + lectura completa) y `findOne_/findAll_` filtran en memoria. `readJobs_` lee `ofertas` + `perfiles_empresa` + `ofertas_guardadas` completas por cada búsqueda. Con 12 ofertas de prueba es instantáneo; con 1.000 ofertas y 500 usuarios, cada búsqueda es un escaneo completo, y Apps Script tiene cuotas de ejecución (6 min por ejecución, cuotas diarias) y `LockService` serializa las escrituras. No es un bug: es el techo arquitectónico del stack actual. La migración a Postgres con índices es la respuesta correcta, no optimizar Sheets. |
| QA-01 | Sin pruebas automatizadas | **Abierto** | Lo único automático es `verify_release.py` (168 comprobaciones **estáticas**: presencia de archivos, IDs, textos, versiones) y las 8 pruebas unitarias del script de migración (`test_transformacion.py`, transformación pura, sin base de datos). No hay pruebas de UI, ni de contrato (34 acciones contra un backend real), ni de la Edge Function desplegada, ni de extremo a extremo. `TEST_LOG.md` lo reconoce: casi todo lo funcional está marcado «Pendiente en teléfono» y depende del reporte de Henry en su Motorola. |

### 2.2 Nuevos hallazgos (observados en el código)

**S-01 — La frase que protege las claves integradas es débil y está en el
código. Severidad: media. Abierto.**
`SecureDefaults.java`: los 6 valores de conexión (URL de la API, clave API
web de Firebase, IDs de FCM y de cliente de Google) van cifrados con
AES-256-GCM y PBKDF2 a 100.000 iteraciones, lo cual está bien hecho. Pero
la frase de la que deriva la clave está partida en 5 trozos legibles en
el propio archivo fuente (palabras comunes, predecibles) y el blob cifrado
también viaja en el APK. El propio archivo lo admite con honestidad: «no
es un secreto frente a quien descompile la app con intención». No reproduzco
la frase ni el blob en este informe. Consecuencia práctica: cualquiera que
descompile el APK puede recuperar la clave API web de Firebase y la URL
`/exec`. Eso **no** da acceso a la hoja (la clave de Firebase solo
identifica al proyecto; el acceso real lo da el ID token verificado por
el backend), pero sí permite llamar a la API como cliente y probar
`login`/`registerProfile` a voluntad, y permite suplantar la app ante
Google. Mitigación real: no intentar esconder mejor la clave; **sacar la
URL y la clave del binario** (configuración remota o Supabase, con la URL
de la Edge Function como único valor público) y endurecer el backend
(límites por correo ya existen en P3, ver S-03). Prioridad P1, no P0,
porque el daño directo es bajo mientras el backend verifique tokens.

**S-02 — La cuenta de servicio de FCM vive en PropertiesService como JSON
completo. Severidad: media. Abierto por diseño, frágil en la práctica.**
`Code.gs:1094-1111` y `FIREBASE_SETUP.md` §7: el JSON completo de la
cuenta de servicio se pega con una función temporal y queda en
`PropertiesService`. Quien tenga acceso de editor al Apps Script (o al
Sheet, según permisos) puede leerlo y enviar push como el proyecto.
No hay rotación documentada ni separación entre la cuenta de servicio
de push y cualquier otro uso. En Supabase, el equivalente (service_role)
debe vivir **solo** como secreto de la Edge Function, nunca en el repo,
y el envío de push debe pasar por una función con `SECURITY DEFINER`
que solo acepte `notificationId`, no un token arbitrario. No es un fallo
de hoy (el acceso al script es solo de Henry), pero es el secreto con
mayor blast radius del proyecto y no tiene plan de rotación.

**S-03 — Rate limiting: bueno en Apps Script, incompleto en la Edge
Function. Severidad: media. Parcial.**
`Code.gs:914-970`: `checkRateLimit_` por usuario/acción en `CacheService`
(1 h) y `checkRateLimitLocked_` (bajo `LockService`) para acciones
públicas — login 10/h, registro 5/h, reportes 10/h, guardados 60/h,
contacto 30/h, intereses 30/h, ofertas 10/h. Correcto y consciente de
sus límites (CacheService no es atómico sin lock; el comentario lo dice).
En la Edge Function, solo `expressInterest` tiene límite
(`consumir_limite`, ver S-04) y `login` **no tiene ninguno**: un atacante
puede bombardear `login` con ID tokens inválidos; Firebase lo frena en
su lado, pero cada intento crea trabajo y logs, y no hay bloqueo por
correo. Además `CacheService` se vacía y no es compartido entre
instancias: el límite de Apps Script es aproximado, no garantizado.
En Supabase, el límite debe vivir en Postgres (tabla `limites_uso`, ya
creada en el borrador) y aplicarse también a `login`/`registerProfile`
por hash de correo, no solo a `expressInterest`.

**S-04 — `consumir_limite()` puede dejar pasar más del máximo bajo
concurrencia. Severidad: media. Abierto (borrador).**
`002_seguridad_y_funciones.sql`: la función inserta una fila en
`limites_uso` y luego cuenta. Dos transacciones concurrentes no ven la
fila sin confirmar de la otra, así que ambas pueden contar 30 y pasar.
Con 30/h y un atacante que paraleliza, el límite real es mayor. Es un
fallo clásico y fácil de corregir: `pg_advisory_xact_lock()` por
(usuario, acción) al inicio de la función, o una tabla de contadores
con `INSERT … ON CONFLICT … DO UPDATE SET n = n + 1 RETURNING n`.
No es P0 (el daño es spam de intereses, no robo de datos), pero es
exactamente el tipo de cosa que en Sheets estaba protegida por
`LockService` y en Postgres hay que proteger de otra forma.

**S-05 — `expresar_interes()` no comprueba que la oferta pertenezca a
una empresa activa ni que el trabajador no sea el dueño. Severidad:
baja-media. Abierto (borrador).**
La función comprueba que la oferta exista, esté `published` y no
caducada, y que el perfil de trabajador exista. No comprueba el estado
de la empresa (`perfiles_empresa.status`), ni el estado del usuario
trabajador (la Edge Function sí comprueba `active`/`incomplete` antes
de llamar, pero la función sola no lo hace), ni que el trabajador no
esté postulándose a su propia oferta (imposible hoy porque un usuario
tiene un solo rol, pero el esquema no lo impide si eso cambia).
Recomendación: añadir esas comprobaciones dentro de la función, no
solo en la Edge Function, porque la función es la última línea de
defensa si alguien la llama directamente.

**S-06 — RLS del borrador: correcto en intención, dormido en la
práctica, y con dos concesiones que revisar. Severidad: media.
Abierto (por diseño, documentado).**
`002` lo dice con claridad: las políticas usan `auth.uid()`, que es
NULL mientras la app se autentique con Firebase, así que el acceso
directo queda cerrado (fail-closed) y todo pasa por la Edge Function
con service_role. Eso es lo correcto **hoy**. Pero hay dos detalles:
(a) `expirar_ofertas()` está concedida
con `GRANT EXECUTE … TO authenticated`: cualquier usuario autenticado
podría llamarla (solo caduca ofertas ya vencidas, daño bajo, pero es
una función de mantenimiento que debería ser solo service_role /
pg_cron); (b) `revocar_sesion(text)` también está concedida a
`authenticated` y solo recibe un hash: es segura por la entropía del
hash (64 hex), pero no comprueba propiedad. Y una advertencia mayor:
cuando se adopte Supabase Auth, las políticas empezarán a aplicarse
**de golpe**; si los UUID de `usuarios.id` no coinciden con
`auth.uid()`, todo el acceso directo seguirá denegado y parecerá un
fallo de la app. Hay que decidir la identidad (ver §4, P0) antes de
abrir el acceso directo, no después.

**S-07 — La vista pública usa `security_invoker = false`. Severidad:
baja, vigilar. Abierto (borrador).**
`v_ofertas_publicas` se ejecuta con los derechos de su dueño y aplica
su propio filtro. Es la decisión correcta para que `anon` lea ofertas
publicadas sin leer la tabla, pero significa que la seguridad de la
vista depende de su filtro, no de RLS: si alguien añade una columna
sensible a la vista (teléfono, CV, notas internas) en el futuro, se
expone sin que RLS lo frene. El borrador lo mitiga bien (la vista no
incluye teléfonos ni CV ni notas), pero debe quedar una regla escrita:
**la vista pública solo expone lo que `publicJob` debe devolver**,
y cualquier cambio en ella se revisa como cambio de seguridad.

**S-08 — Sesiones: buen diseño, un detalle de higiene. Severidad:
baja. Parcial.**
Sesión opaca de 24 h, solo el hash SHA-256 guardado, revocación en
`logout`, purga diaria 03:30 (Apps Script) / `limpiar_sesiones_expiradas()`
(Supabase). Correcto. Dos detalles: (1) en Apps Script, `requireAuth_`
hace `findOne_` sobre **toda** la pestaña `sesiones` en cada petición
(escaneo completo por llamada autenticada, ver CON-04); en Postgres
esto es una búsqueda por PK (`session_hash`) y desaparece el problema.
(2) La Edge Function actualiza `last_seen_at` en cada petición con un
`update` best-effort sin esperar: correcto, pero genera una escritura
por lectura; con tráfico real, considerar actualizarlo como mucho una
vez por hora y sesión.

**S-09 — El archivo de datos de prueba contiene un token de sesión.
Severidad: baja si se queda en staging, alta si llega a producción.
Abierto (borrador).**
`work/supabase/migracion/datos_prueba.sql` incluye un bloque de
«sesión de prueba» con un token en claro (el propio archivo avisa:
borrar con `revocar_sesion()` y no usar en producción). No reproduzco
el token aquí. El riesgo no es el token en sí (es de prueba, revocable),
sino el patrón: un archivo que se aplica con un solo comando y que
siembra una sesión válida. Regla: `datos_prueba.sql` solo se aplica
en staging/local, nunca en producción, y la sesión de prueba se revoca
al final de cada sesión de pruebas. Mejor aún: que el bloque de sesión
viva en un archivo separado (`datos_prueba_sesion.sql`) que no se
aplique por accidente.

**S-10 — `debug.keystore` viaja en el RAR. Severidad: alta para
publicar, baja para beta. Abierto (ver SEC-09).**
El keystore de debug está en la raíz de `jobmatch-android/` y viaja
en el RAR con sus contraseñas estándar en `app/build.gradle`. Para
la beta cerrada de Henry es práctico (todas las máquinas firman igual),
pero es la misma clave con la que se firma la release que se distribuye.
No hay separación entre «clave para probar» y «clave para publicar».
Ver P0 en §4.

**S-11 — La app confía en lo que el usuario pega en Perfil.
Severidad: baja-media. Abierto por diseño.**
`ProfileFragment` permite pegar URL de API, clave de Firebase y IDs.
«Lo que el usuario escriba en Perfil siempre manda» (LEEME_ENTREGA).
Eso es flexible para Henry, pero un valor mal pegado (una URL con
tráfico, una clave de otro proyecto) cambia el backend al que habla la
app sin ninguna validación de origen, y la URL queda guardada en el
almacén cifrado como si fuera de confianza. El cliente ya valida la
redirección (`isTrustedScriptUrl`: solo `script.google.com` /
`script.googleusercontent.com`), pero eso protege contra redirecciones,
no contra una URL base maliciosa pegada a mano. En Supabase, la URL de
la Edge Function debe ser fija en el build (no editable en Perfil) y
los valores editables deben validarse (formato, dominio permitido).

**S-12 — Contacto: el diseño es bueno, la superficie es ancha.
Severidad: baja. Parcial.**
`contactOptions` solo entrega el teléfono completo al propietario o a
quien tiene una candidatura activa para esa oferta concreta
(CONTRACT.md, y `Code.gs` lo aplica). Bien. Pero el contacto por
WhatsApp es un enlace `wa.me` con el número en claro, y una vez
entregado el número, no hay revocación: el trabajador lo tiene para
siempre. No es un fallo (es el producto: hay que poder contactar), pero
hay que decirlo: el número de teléfono es el dato más expuesto del
sistema, y la política `contact_policy` (`in_app_first` vs `direct`)
es la única palanca. Recomendación: `in_app_first` por defecto para
cuentas nuevas y un aviso claro en la app la primera vez que se revela
un número.

### 2.3 Qué NO se pudo verificar (honestidad del alcance)

- **Los `.docx` de auditoría y guía** (`01_Auditoria_CubaPincha.docx`,
  `02_Guia_Migracion_Supabase.docx`): no se extrajo su texto en esta
  auditoría. Los 37 hallazgos (6 altos, 21 medios, 10 bajos) se citan
  solo a través de `LEEME_ENTREGA.md`. Los 31 hallazgos no altos no se
  han verificado uno por uno contra el código.
- **El despliegue real, Firebase Console, Sheets y Supabase**: sin
  acceso, no se puede confirmar qué versión está desplegada, si los
  triggers están instalados, si `FCM_SERVICE_ACCOUNT` está configurado,
  ni si el staging tiene datos.
- **El teléfono**: nada de lo funcional se ha visto correr. `TEST_LOG.md`
  marca casi todo «Pendiente en teléfono».
- **El APK incluido** (`cubapincha.apk`, 7 MB): no se descomprimió ni se
  comparó con las fuentes en esta auditoría.
- **Las 8 pruebas del script de migración**: se leyó el script, no se
  ejecutaron (las pruebas son de transformación pura; la carga real
  contra Postgres está pendiente, como dice el propio LEEME).

---

## 3. Lógica y base de datos

### 3.1 Los flujos, como realmente funcionan

**Registro / login.** La app autentica con Firebase (correo+contraseña
o Google vía `signInWithIdp`) y envía el ID token a `login` /
`registerProfile`. El backend verifica el token con Identity Toolkit,
busca al usuario por `emailHash` (SHA-256 del correo en minúsculas) y,
si no existe, `login` devuelve `NOT_FOUND` y la app pasa al registro
con correo y nombre prellenados. Al registrarse con Google, el token
pendiente que se guarda **debe** ser el de Firebase, no el de Google
(bug real corregido en 2.8.2: el backend rechazaba el token de Google).
`registerProfile` con Google no exige contraseña. En el primer login
tras migrar, el `firebase_uid` se vincula a la cuenta (y después debe
coincidir: nadie puede reclamar una cuenta con otro proveedor). La
sesión dura 24 h; el refresh token de Firebase renueva el ID token sin
pedir la contraseña. **Riesgo principal:** toda la identidad depende
de que el correo no cambie: si un usuario cambia su correo en Firebase,
su `emailHash` ya no coincide y pierde la cuenta (no hay flujo de
cambio de correo documentado). En Supabase, la identidad debe ser el
`firebase_uid` (o el `auth.uid()` si se migra a Supabase Auth), no el
hash del correo; el hash debe ser un índice de búsqueda, no la llave
de identidad.

**Ofertas.** Crear → borrador → publicar (exige `title, category,
description, workMode, contractType`, cuenta `active`) → `published`
→ `paused` / `closed` / `expired` (trigger cada hora, bajo lock) /
`archived` (con `archivedAt` + `archiveReason`; `changeJobStatus`
desde `archived` puede volver: es el Deshacer). Eliminar solo admite
borradores sin candidaturas; lo demás responde `CONFLICT`. Al publicar
se ejecuta el matching **una sola vez** (no en cada lectura). Las
ofertas en caché local son públicas y quedan en claro; todo lo demás,
cifrado.

**Postulaciones / intereses.** `expressInterest` es idempotente por
(job, worker): si ya existe, la reactiva (`status: sent`, sin duplicar).
La unicidad la garantiza `LockService` + búsqueda de duplicado en
Sheets y, en Postgres, la `UNIQUE (oferta_id, trabajador_id)` + `ON
CONFLICT DO NOTHING` de `expresar_interes()`. El trabajador ve sus
candidaturas; la empresa ve y cambia el estado de las de sus ofertas
según una máquina de estados explícita (`sent → reviewing/interview/
rejected`, etc.; `hired` y `rejected` son terminales). `sendReminder`
exige `status = sent` y 3 días desde el envío y desde el último
recordatorio. Retirar es `changeApplicationStatus` a `withdrawn`, solo
desde `sent`/`reviewing` y solo el propio trabajador.

**Filtros y alertas.** Un filtro guardado tiene `filters` (JSON),
`frequency` (`inmediata`/`diaria`/`desactivada`) y `enabled`. Regla de
precedencia que el código respeta en los tres sitios (backend, app y
SQL borrador): `enabled=false` gana siempre. Al publicar, los filtros
`inmediata` se evalúan contra la oferta nueva; los `diaria` se resumen
a las 9:00 con `lastRunAt` avanzando en cada ejecución. Dedupe entre
`new_relevant_job` y `saved_filter_match` por oferta. **Riesgo:** el
digest diario depende de un trigger de Apps Script (o de pg_cron en
Supabase) que, si falla un día, no se reintenta: `lastRunAt` no avanza
y al día siguiente el resumen cubre dos días sin que nadie lo note.
Hay que registrar cada ejecución del cron (tabla o log) y alertar si
falla.

**Contacto.** `contactOptions` devuelve, según quién pregunta, el
teléfono enmascarado o completo y la URL de WhatsApp. `contactEvent`
registra cada intento (canal `whatsapp`/`call`/`copy`/`request`) con
límite 30/h. Es la única telemetría de «interés real» que tiene el
producto hoy: cuántos contactos genera cada oferta. No se usa para
nada más; debería alimentar el ranking (ver §4).

**Notificaciones.** Se persisten antes de intentar el push (nunca
al revés). Dedupe por `type:userId:entityId`. `sent_at` distingue
«guardada» de «enviada»: el borrador de la Edge Function lo deja
pendiente («TODO fase 2: enviar push pendientes fuera de la
transacción»). Si la Edge Function crea la notificación pero el push
falla, la notificación queda en `sent_at IS NULL` para siempre salvo
que alguien la reintente: hace falta un reintentador.

**Sincronización offline.** La cola es `pending_actions` con
`clientActionId` como PK. El servidor reserva cada ID antes de
ejecutarlo. El cliente repite `sync` con `since` hasta agotar
(`hasMore`). Los borradores de empresa no se sincronizan (se guardan
locales y se publican al recuperar la red). **Riesgo principal:**
`updateProfile` acepta `expectedUpdatedAt` (optimista) y el servidor
responde `CONFLICT` si el perfil cambió; pero la mayoría de acciones
offline no tienen control de concurrencia optimista: si el usuario
edita su perfil offline y alguien (o él mismo en otro dispositivo)
lo edita online, la última escritura gana sin avisar. Con un solo
teléfono por usuario es raro; con web + app (cuando la web use la API)
será común. Ver §4, P1.

**Expiración.** `expireJobs_` cada hora, bajo lock, y
`expirar_ofertas()` en Postgres (una sola `UPDATE`, devuelve cuántas
caducó). Correcto y simple. Detalle: en Sheets, la expiración depende
de que el trigger esté instalado; si el despliegue se rehace y el
trigger no se reinstala, las ofertas no caducan y siguen visibles
hasta que alguien las abre. En Supabase, el pg_cron debe crearse como
parte del despliegue (no a mano en el panel) y su ejecución debe
quedar registrada.

### 3.2 Dónde vive la lógica (y qué significa)

| Lógica | Dónde vive hoy | Riesgo |
|---|---|---|
| Validación de campos, enums, salarios | Backend (Code.gs) + SQL borrador (CHECK) | La app no valida antes de enviar (LOG-01): el usuario se entera tarde. |
| Reglas de negocio (transiciones, quién ve qué) | Backend + CONTRACT.md | La app replica parte de la lógica en `Repository`/fragments; si divergen, la UI miente. |
| Matching (umbral 60) | Backend (`computeMatchScore_`, `runMatchingForJob_`) | El algoritmo es opaco: no hay explicación de por qué una oferta «coincide», ni pesos documentados en CONTRACT.md. |
| Búsqueda y filtros | Backend, en memoria sobre la hoja entera | No hay índice, ni ranking, ni paginación por cursor real (es offset disfrazado). |
| Sesiones, rate limits, auditoría | Backend + Sheets | Todo depende de `LockService`/`CacheService` de Apps Script. |
| Caché, borradores, cola offline | App (`LocalDb`) | La app es la única que conoce el estado offline; el servidor no sabe qué tiene pendiente cada teléfono. |

### 3.3 Sheets como base de datos: los riesgos concretos

1. **Sin transacciones.** Cada escritura es una o varias operaciones
   sobre filas. `LockService` serializa, pero un fallo a mitad de una
   operación compuesta (crear oferta + notificar + auditar) deja la
   hoja a medias. No hay rollback.
2. **Lectura completa por operación.** Cada `readTable_` es un escaneo.
   El coste crece linealmente con los datos y con los usuarios
   concurrentes, y las cuotas de Apps Script ponen el techo.
3. **Sin tipos ni restricciones.** Un `salaryMin` con texto, una fecha
   mal formada o un enum con una errata entran en la hoja y solo se
   descubren cuando algo falla. El script de migración existe, en
   parte, para limpiar esto (y lo hace bien: omite o corrige y lo
   registra).
4. **El esquema es posicional.** `readTable_` mapea por posición; añadir
   una columna al final es seguro, reordenar o borrar una columna
   corrompe la lectura. El código lo sabe y lo documenta, pero es una
   trampa permanente.
5. **Duplicados por carrera.** La unicidad depende de «buscar y luego
   escribir bajo lock». Si el lock expira (10 s) o dos ejecuciones se
   solapan, entran duplicados. La migración los limpia (dedupe por
   `emailHash`, por (oferta, trabajador), por `dedupeKey`), pero la
   fuente sigue generándolos.
6. **No hay borrado real ni retención.** `deleted` es un estado, no un
   borrado; no hay política de retención de `auditoria` ni de
   `acciones_sincronizacion`, que crecen sin límite.

### 3.4 Qué debe preservar el diseño Supabase (no negociable)

- El contrato de 34 acciones y sus códigos de error, para que la app
  2.9.2 siga funcionando contra la Edge Function cambiando solo la URL.
- La idempotencia de `expressInterest` y de `syncActions` (reserva de
  `clientActionId`, `already_applied` vs `conflict`).
- La máquina de estados de candidaturas y de ofertas, incluido el
  Deshacer desde `archived`.
- La regla `enabled=false` gana siempre en filtros, y el dedupe entre
  `new_relevant_job` y `saved_filter_match`.
- `contactOptions` con revelado progresivo del teléfono.
- Sesiones opacas de 24 h con solo el hash guardado, y purga diaria.
- Auditoría de solo inserción.
- Los IDs: los UUID de Apps Script se conservan; los legados
  (`job-001`, `demo-j1`) se convierten con UUID5 determinista con el
  namespace fijo del script. Cambiar el namespace rompería los enlaces
  `cubapincha.cu/ofertas/{id}` y los deep links.

### 3.5 Revisión del SQL borrador (001 + 002)

Veredicto: **buen borrador, fiel al script de migración, con 7
desajustes que corregir antes de aplicar en staging.**

1. **Fiel donde importa.** Las 17 tablas del script reproducen
   exactamente sus columnas (snake_case), sus enums (CHECK) y su
   orden de carga. `chk_ofertas_salario` y el de perfil cierran
   LOG-01 en la base. `UNIQUE (oferta_id, trabajador_id)`,
   `(user_id, oferta_id)` en guardadas y `(user_id, client_action_id)`
   en acciones reproducen los dedupes del script. La vista
   `v_ofertas_publicas` no expone teléfonos, CV ni notas internas.
2. **El conteo de «20 tablas» es un artificio honesto.** 17 del script
   + `sesiones` + `archivos` = 19; la vigésima, `limites_uso`, es
   inventada por el borrador para que `consumir_limite()` funcione.
   El archivo lo dice en su cabecera. No es un error, pero la guía
   habla de «20 tablas» sin enumerarlas: hay que fijar la lista
   canónica (17 + sesiones + archivos + limites_uso) en la guía, no
   dejarla implícita.
3. **`archivos` no coincide con Sheets.** La pestaña `archivos` tiene
   `fileId, ownerId, driveFileId, type, mimeType, sizeBytes,
   visibility, createdAt`; el SQL tiene `owner_id, tipo, bucket,
   storage_path, nombre_original…` y **no** tiene `visibility` ni
   `driveFileId`. El script de migración no migra archivos (lo dice:
   «NO se migra aquí»), así que el SQL es un diseño nuevo, no una
   traducción. Falta el mapa explícito: `driveFileId` → `storage_path`,
   `visibility` → política de Storage, y qué pasa con los archivos
   que ya están en Drive (¿se copian a Storage o se dejan con enlace?).
4. **`ofertas_guardadas.ownerType` se pierde.** La pestaña lo tiene;
   ni el script ni el SQL lo usan. Si `ownerType` distinguía algo
   (trabajador vs empresa guardando), se pierde en la migración.
   Verificar contra un CSV real antes de darlo por muerto.
5. **`auditoria` pierde `ipHash` y gana `id`.** La pestaña tiene
   `auditId` + `ipHash` (siempre vacío en Code.gs: Apps Script no
   expone la IP); el SQL usa `id` con default y no tiene `ipHash`.
   El script inserta sin `id`, así que funciona. Decisión correcta,
   pero documentarla: en Supabase la IP sí se puede guardar (cabecera
   `x-forwarded-for` en la Edge Function) y merece una columna.
6. **`reportes.status`: «abierto» vs «open».** El script y el SQL usan
   `abierto/en_revision/resuelto/descartado`; CONTRACT.md dice que
   la API responde `status: "open"` al crear. El SQL lo anota («la
   Edge Function debe traducir»), pero hoy **nadie traduce**: la Edge
   Function no implementa `report` y el borrador no incluye la
   traducción. Es un desajuste de una línea que romperá el primer
   reporte que se cree.
7. **`sesiones` cambia de nombre de columna.** Sheets: `sessionIdHash`;
   SQL y Edge Function: `session_hash`. Correcto para Postgres, pero
   es otro ejemplo de que el SQL no es una traducción literal de
   Sheets sino del contrato nuevo: hay que leerlo así.
8. **Falta búsqueda.** No hay `tsvector`, ni trigram (`pg_trgm`), ni
   índice de texto en `ofertas.title/description/category`. La
   búsqueda actual es `indexOf` en memoria sobre título + categoría +
   descripción + ciudad + empresa. En Postgres, sin índice, será un
   `ILIKE '%…%'` con escaneo completo: el mismo problema de Sheets
   con otro nombre. Ver §4, P1.
9. **Falta `updated_at` en varias tablas que lo tienen en Sheets**
   (`filtros_guardados` lo tiene en el trigger, pero `notificaciones`,
   `dispositivos_fcm` y `reportes` no lo tienen en el SQL aunque el
   script inserta `created_at` y poco más — coherente con el script,
   pero revisar si algún flujo lo espera).
10. **El borrador no tiene `PLAN.md`.** Su propia cabecera remite a
    un `PLAN.md` («ver PLAN.md, apartado de verificación») que no
    existe en `work/supabase/`. Hay que escribirlo o quitar la
    referencia antes de que alguien lo busque.

---

## 4. Mejoras reales para potencializar al máximo

### P0 — Bloqueante para beta / producción (hacer antes de publicar)

**P0-1. Keystore de producción real y rotación de firma.**
Qué: generar un keystore de release nuevo, fuera del repo, con su
contraseña en un gestor de secretos; firmar la release con él;
registrar sus huellas SHA-1/SHA-256 en Firebase (y en Google Play
cuando toque); documentar dónde vive y quién lo custodia, y qué pasa
si se pierde (respuesta: se pierde la capacidad de actualizar la app;
no hay vuelta atrás).
Por qué: SEC-09/S-10. Hoy cualquiera con el RAR puede firmar como
CubaPincha.
Esfuerzo: 1 día (generar, registrar, recompilar, probar en el Moto G).
Desbloquea: publicar en Play, y que Google Sign-In no se rompa cada
vez que cambia la máquina.

**P0-2. Completar la Edge Function: 28 acciones restantes.**
Qué: implementar las 28 acciones que hoy responden `NOT_IMPLEMENTED`
(lecturas `jobs, job, applications, notifications, sync, listFilters,
contactOptions, listCatalogs`; escrituras `registerProfile,
updateProfile, createJob, publishJob, updateJob, changeJobStatus,
archiveJob, deleteJob, sendReminder, changeApplicationStatus, saveJob,
saveCandidate, saveFilter, deleteFilter, syncActions, contactEvent,
registerDevice, unregisterDevice, markNotificationRead, report`), en
el orden: primero las lecturas públicas y `jobs` (sin ellas la app no
arranca), luego `registerProfile`/`updateProfile`, luego las de empresa,
luego `syncActions` y el resto. Cada una con su prueba de contrato
contra staging (ver P0-7).
Por qué: hoy la Edge Function es un esqueleto (6/34). Sin esto no hay
migración, solo un esquema vacío.
Esfuerzo: 2–3 semanas, es el grueso del proyecto. Desbloquea: la app
2.10.0 y el corte a producción.

**P0-3. Decidir la identidad: Firebase Auth o Supabase Auth, por escrito.**
Qué: elegir una de las dos y documentarla con sus consecuencias.
Recomendación de esta auditoría: **mantener Firebase Auth en la
migración (Fase 5–8) y no migrar a Supabase Auth hasta después del
corte**, porque (a) el login, el registro con Google y el refresh ya
funcionan y están probados en la app; (b) la Edge Function ya verifica
el ID token con Identity Toolkit; (c) migrar la identidad a la vez que
la base de datos es cambiar dos cosas críticas a la vez. El coste es
que `auth.uid()` seguirá siendo NULL y RLS directo seguirá dormido
(ver S-06): todo pasa por la Edge Function con service_role, que es
exactamente el modelo actual y funciona. La migración a Supabase Auth
vendría después, como proyecto propio: crear usuarios en
`auth.users` con los mismos UUID, migrar contraseñas (no se puede:
Firebase no exporta hashes utilizables; habría que forzar un
restablecimiento de contraseña a todos), y activar RLS directo.
Trade-off honesto: quedarse con Firebase para siempre es válido, pero
entonces Supabase es «Postgres + Edge Functions», no la plataforma
completa, y se paga el precio de dos proveedores de identidad.
Esfuerzo: 1 día decidirlo; 2–3 semanas si se elige migrar Auth ahora
(no recomendado).
Desbloquea: que RLS, las políticas y el acceso directo tengan un
sentido claro, y que nadie construya sobre una identidad ambigua.

**P0-4. Activar la verificación de correo de forma coordinada.**
Qué: (1) que la app envíe el correo de verificación tras el registro
(Firebase `sendOobCode` / `sendEmailVerification`, ya existe el
endpoint en `FirebaseAuthRest`); (2) poner `REQUIRE_EMAIL_VERIFIED=1`
en la Edge Function **y** en Apps Script a la vez; (3) comunicar a los
usuarios existentes que deberán verificar el correo.
Por qué: SEC-01. Hoy la Edge Function lo exige por defecto y Apps
Script no. Esa divergencia es una trampa.
Esfuerzo: 2–3 días. Desbloquea: cerrar el hallazgo alto más barato
de todos.

**P0-5. Rate limiting en `login`/`registerProfile` en la Edge Function.**
Qué: aplicar `consumir_limite()` por hash de correo a `login` (10/h)
y `registerProfile` (5/h), como ya hace Apps Script (P3), y corregir
`consumir_limite()` con un lock consultivo (ver S-04).
Por qué: S-03/S-04. Sin esto, la Edge Function es más débil que el
backend que sustituye.
Esfuerzo: 1 día. Desbloquea: no retroceder en seguridad al migrar.

**P0-6. Resolver el mapa de archivos (CV y logos) antes de migrar datos.**
Qué: decidir, por escrito, si los CV y logos se copian de Drive a
Storage (bucket privado `archivos`, con la tabla `archivos` y la
columna `visibility` que hoy falta), o si se dejan en Drive con enlace.
Y decidir qué pasa con `cv_path`/`logo_path` (hoy quedan en `""` tras
migrar, según el script).
Por qué: §3.5.3. Es el único dato que el script declara que no migra,
y sin decidirlo la migración de perfiles queda incompleta.
Esfuerzo: 1 día decidirlo; 2–3 días implementarlo. Desbloquea: Fase 6.

**P0-7. Pruebas de contrato T01–T20 contra staging (la matriz de la guía).**
Qué: una suite que, contra `cubapincha-staging`, ejecute las 34
acciones con datos de prueba y compruebe respuestas, códigos de error
y estados. Empezar por las 6 ya implementadas y crecer con cada acción
nueva. Y una prueba en el Moto G de Henry por versión (la matriz
T01–T20 de la guía, Fase 7).
Por qué: QA-01. Hoy la única red de seguridad es `verify_release.py`
(estática) y el reporte manual de Henry.
Esfuerzo: 3–5 días la suite; 1 día por versión la prueba en teléfono.
Desbloquea: confiar en el corte a producción.

### P1 — Alto impacto, esfuerzo medio

**P1-1. Búsqueda con Postgres de verdad.**
Qué: `tsvector` en español sobre `title + category + description +
empresa`, índice GIN, y `pg_trgm` para tolerar erratas y abreviaturas
cubanas; ranking por relevancia + fecha; paginación por cursor
(`published_at, id`) en vez de offset. Conservar los filtros actuales
(provincia, municipio, salario, modalidad, contrato, `verifiedOnly`,
`onlyWithSalary`) como índices parciales.
Por qué: la búsqueda actual es `indexOf` en memoria sobre la hoja
entera. Es el cambio que más notará el usuario al migrar.
Esfuerzo: 2–3 días. Desbloquea: que buscar «cocinero Vedado» funcione
con 10.000 ofertas igual que con 12.

**P1-2. La web con la misma API.**
Qué: que `cubapincha-web/` llame a `publicJob`/`jobs` de la Edge
Function (o a `v_ofertas_publicas` por PostgREST con clave `anon`)
en vez de a `data/jobs.json`, con el mismo contrato y los mismos
enlaces `cubapincha.cu/ofertas/{id}`. Mantener `jobs.json` solo como
respaldo offline.
Por qué: CON-01. Hoy la web miente (muestra demos) y la app y la web
pueden divergir sin que nadie lo note. Además la web es el canal de
captación: si un enlace compartido no abre la oferta real, se pierde
al usuario.
Esfuerzo: 3–5 días. Desbloquea: que la web sea un cliente real y que
Google indexe ofertas reales (SEO).

**P1-3. Storage para CVs y logos con políticas.**
Qué: bucket privado `archivos`, subida con URL firmada (la app pide
a la Edge Function una URL firmada, sube directo a Storage, la Edge
Function registra la fila en `archivos`); lectura con URL firmada de
corta duración, solo para la empresa con candidatura activa o para el
propio trabajador. Límites de tamaño y tipo (PDF / imagen), y
miniatura para logos.
Por qué: hoy los CV y logos son `driveFileId` en Sheets sin control
de acceso propio. Es el dato más sensible después del teléfono.
Esfuerzo: 3–5 días. Desbloquea: perfiles completos en Supabase.

**P1-4. Realtime donde duele, no en todo.**
Qué: Realtime de Supabase solo para `notificaciones` y
`postulaciones` del usuario (canal por usuario). La lista de ofertas
sigue siendo pull con caché (no hace falta realtime ahí).
Por qué: hoy la empresa se entera de una candidatura cuando abre la
app o le llega el push. Con Realtime, la ficha del candidato se
actualiza sola.
Esfuerzo: 2–3 días. Desbloquea: sensación de «app viva» sin coste
de infraestructura.

**P1-5. Sincronización offline con control de concurrencia.**
Qué: `expectedUpdatedAt` en todas las mutaciones que hoy no lo
tienen (no solo `updateProfile`), y una pantalla «Revisar» en la app
que liste los rechazos de sincronización con su motivo y permita
reintentarlo o descartarlo (hoy el contador existe, la pantalla no).
Y un `sync` que devuelva también lo que cambió en el servidor desde
`since` para las entidades que el cliente edita.
Por qué: §3.1. Con web + app, la última escritura ganará sin avisar.
Esfuerzo: 1 semana. Desbloquea: que dos dispositivos no se pisen.

**P1-6. Observabilidad mínima.**
Qué: logs estructurados en la Edge Function (`requestId` ya existe:
aprovecharlo), métricas de latencia y errores por acción, alerta si
un pg_cron no se ejecuta, y un panel con: registros/día, ofertas
publicadas, intereses, contactos, errores 5xx. Nada de telemetría
de usuarios sin consentimiento.
Por qué: hoy, si algo falla en producción, la única señal es que
Henry lo reporte. Con Supabase, el log existe; hay que mirarlo.
Esfuerzo: 2–3 días. Desbloquea: operar el producto en vez de
reaccionar a él.

**P1-7. Sacar los secretos del binario (S-01, S-11).**
Qué: URL de la Edge Function fija en el build (no editable en
Perfil); clave API de Firebase solo como identificador, con
restricciones de API en Google Cloud (solo Identity Toolkit y FCM,
solo paquete `com.cubapincha.job`); y eliminar `SecureDefaults`
como almacén de secretos en la 2.10.0.
Por qué: S-01/S-11. No es urgente porque el daño directo es bajo,
pero es deuda que crece con cada distribución del APK.
Esfuerzo: 2–3 días. Desbloquea: distribuir el APK sin regalar las
claves de cliente.

**P1-8. CI mínima.**
Qué: GitHub Actions (cuando el repo esté disponible): `tsc --strict`
y pruebas de la Edge Function, `python -m pytest` del script de
migración, `gradle assembleRelease` + `verify_release.py` en cada
push, y bloqueo de merge si algo falla. Y un `lintRelease` que no se
cuelgue (o documentar por qué se usa solo `lintVitalRelease`).
Por qué: QA-01. Hoy todo depende de que alguien ejecute los comandos
a mano en el orden correcto.
Esfuerzo: 2–3 días. Desbloquea: que la 2.10.0 no rompa lo que la
2.9.2 hacía bien.

### P2 — Crecimiento (después del corte)

**P2-1. Matching explicable y con aprendizaje.**
Qué: que `computeMatchScore_` (o su equivalente en Postgres) devuelva
no solo un número, sino **por qué**: «coincide en provincia, en
modalidad y en 2 de 3 habilidades». Guardar el desglose y mostrarlo
en la ficha («Por qué te conviene»). Después, aprender de los
contactos reales: si una oferta con score 62 genera contactos y una
con 85 no, el umbral 60 está mal calibrado.
Por qué: el matching es el corazón del producto y hoy es una caja
negra con un umbral fijo.
Esfuerzo: 1–2 semanas. Desbloquea: que el matching sea una ventaja,
no un misterio.

**P2-2. Alertas que no spameen.**
Qué: digest configurable (inmediata / diaria / semanal / nunca por
filtro), límite de notificaciones por día y usuario, y un «silencio»
por oferta (si ya descartaste una oferta, no te alertan de sus
gemelas). Medir la tasa de apertura de cada tipo de alerta y apagar
las que nadie abre.
Por qué: las alertas son el motor de retención, pero también la
forma más rápida de que el usuario silencie la app.
Esfuerzo: 1 semana. Desbloquea: retención sin quemar el canal.

**P2-3. Reputación y verificación de empresas.**
Qué: `verification_level` ya existe (`basica`/`verificada`): usarlo
de verdad (verificación por documento o por referencia), y una
reputación visible (respuesta a candidaturas, tiempo medio de
respuesta, ofertas cerradas sin contratar). Y un distintivo para
empresas que responden.
Por qué: en un mercado con ofertas engañosas (motivo de reporte
`salario_enganoso`, `pide_dinero`), la confianza es el producto.
Esfuerzo: 2 semanas. Desbloquea: que una empresa verificada valga
más que una que no lo es.

**P2-4. Pagos y destacados (cuando haya tracción).**
Qué: oferta destacada de pago, o «contacto prioritario» para empresas.
No antes de tener tracción: monetizar una base vacía mata el producto.
Esfuerzo: por definir. Desbloquea: ingresos.

### Ideas de producto (separadas de los must-dos técnicos)

Estas no son obligaciones técnicas; son apuestas de producto, con la
evidencia que las sostiene, para que Henry decida si las quiere:

1. **«Te conviene» en cada oferta.** Mostrar el score de matching
   desglosado (P2-1) en la tarjeta, no solo en el detalle. Evidencia:
   el matching ya existe y ya se calcula; solo falta enseñarlo.
2. **Alertas por WhatsApp (opt-in).** Muchos usuarios cubanos viven
   en WhatsApp más que en la app. Un resumen diario por WhatsApp (con
   consentimiento explícito) puede valer más que el push. Evidencia:
   `contact_preference` ya contempla WhatsApp como canal.
3. **CV en 2 minutos.** Un constructor de CV guiado en la app (el
   perfil ya tiene `headline`, habilidades, experiencia): genera un
   PDF y lo sube a Storage. Evidencia: `cv_path` existe pero hoy
   queda vacío tras migrar.
4. **Modo «sin datos» real.** Cuba tiene conectividad cara e
   intermitente: un modo que sincronice solo en Wi-Fi, comprima
   imágenes y no descargue logos. La app ya tiene «ahorro de datos»;
   hay que hacerlo visible y medible (MB ahorrados).
5. **Ofertas por municipio, no solo por provincia.** El catálogo ya
   es municipal; la búsqueda por `mi_municipio` ya existe. Falta
   enseñarlo en la portada: «Trabajos en Playa» como entrada principal,
   no como filtro escondido.

---

## 5. Gaps / unknowns — lo que falta para verificar el resto

1. **CSV de Sheets** (18 pestañas, una por archivo): sin ellos no se
   puede probar la migración real, ni saber cuántos usuarios/ofertas
   hay, ni si `ownerType` en `ofertas_guardadas` importa, ni si hay
   duplicados que el script tendrá que limpiar.
2. **Credenciales de Supabase**: token de la CLI (`muse-cli`, que
   según LEEME vence el 27-11-2026) y/o contraseña de la base de
   datos de `cubapincha-staging`, para enlazar la CLI y aplicar el
   SQL. Sin esto, todo lo anterior es local.
3. **Nombre del repositorio de GitHub** (y si el proyecto ya está
   versionado o vive solo en el RAR): sin repo no hay CI (P1-8) ni
   revisión de cambios, y el keystore de producción no tiene dónde
   custodiarse con control de acceso.
4. **Contenido de los `.docx`** (auditoría 01 y guía 02): los 31
   hallazgos no altos no se han verificado contra el código, y la
   guía (fases 0–9, criterios de salida, marcha atrás) es «el
   documento que manda» según LEEME. Hay que extraer su texto y
   cruzar cada fase con el estado real.
5. **Firebase Console**: confirmar qué apps están registradas, qué
   huellas SHA están asociadas a cada una, si el proveedor Google
   está activo y si `FCM_SERVICE_ACCOUNT` está configurado (y quién
   puede leerlo).
6. **El teléfono**: probar la 2.9.2 instalada (desinstalar la 2.9.1
   primero), entrar con Google, completar el registro y ver que
   cargan las 12 ofertas. Sin esto, todo lo funcional es «según el
   código».
7. **`PLAN.md` del SQL borrador**: su cabecera remite a un archivo
   que no existe. Hay que escribirlo o quitar la referencia.
8. **Decisiones pendientes de Henry**: identidad (Firebase vs
   Supabase Auth, P0-3), archivos de Drive (P0-6), y si la web debe
   ser cliente de la API ya en la 2.10.0 o después del corte.

---

*Método: lectura de texto únicamente. No se ejecutó código del
proyecto, no se contactó con ningún servicio remoto y no se
descomprimió el APK incluido. Las citas de archivo son verificables
en el paquete extraído. Lo que no se pudo verificar está listado
en §2.3 y §5, no rellenado con suposiciones.*
