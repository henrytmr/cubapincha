# Auditoría — CubaPincha Android 2.10.0 (ZIP `CubaPincha-Android-2.10_0_c81e.zip`)

**Fecha:** 2026-11-21 · **Auditor:** Muse · **Base de comparación:** guía
`work/IMPLEMENTACION_APK_2.10.0.md` + backend de staging verificado
(Edge Function `api` activa, base con 296 filas, Google habilitado)
**Alcance:** revisión estática del código (265 archivos, 70 Java). No se
compiló nada: la compilación quedó fuera de esta auditoría por decisión
previa. El verificador estático de la otra IA (`tools/verify_supabase_migration.py`)
se re-ejecutó aquí: **14/14 aprobados**.

## Veredicto

**Código bueno, 8/10. Pero NO está listo para publicar como release.**

La parte de Supabase está bien implementada y sigue el contrato del servidor.
Lo que impide una release real es la firma (sigue con el keystore de debug)
y que las claves no van fijas en el build: hay que pegarlas a mano en la app.
Además, nadie ha compilado este código con Gradle hasta un APK: la propia
otra IA lo reconoce en su informe (build Gradle bloqueado en su entorno
ARM64 por AAPT2 x86-64; solo `javac` con stubs + chequeos estáticos).

## Lo que está bien

- **Versión y plataforma:** `versionCode 25`, `versionName "2.10.0"`,
  `compileSdk 34`, `minSdk 24`, `targetSdk 34`, AGP 8.5.2, Gradle 8.9,
  Java 17. Wrapper de Gradle presente.
- **Clases viejas retiradas:** `FirebaseAuthRest.java` y
  `AppsScriptApiClient.java` ya no existen. Creados `SupabaseAuthRest.java`
  (13 KB) y `SupabaseApiClient.java` (38 KB, 35 métodos).
- **GoTrue correcto:** `POST /token?grant_type=password`,
  `grant_type=id_token` (Google), `grant_type=refresh_token`,
  `grant_type=pkce` + intercambio de código, `/signup`, `/recover`, `/user`.
  Cabecera `apikey` en todas y `Authorization: Bearer` cuando hay sesión.
- **Host fijado:** la Edge Function solo acepta
  `https://ogimwehtnhegfoamiwzm.supabase.co/functions/v1/api` (HTTPS,
  puerto 443, sin userinfo). La URL de proyecto va fija en el código.
- **Sin secretos:** no hay `service_role`, ni JWT escrito en el código,
  ni `accessToken`/`idToken`/`password` en el cuerpo (se eliminan antes
  de enviar). Verificador 14/14.
- **Tokens cifrados:** access + refresh + verifier PKCE en
  `EncryptedSharedPreferences`.
- **Contrato respetado:** no se envían `provinceName`/`municipalityName`
  (solo códigos; los nombres los devuelve el servidor), `syncActions`
  con payload anidado y `clientActionId`, la acción `login` no se llama,
  `health` por POST (permitido).
- **Refresh:** ante `AUTH_REQUIRED` refresca una vez y reintenta; si
  vuelve a fallar, cierra la sesión local (correcto).
- **Deep link:** `cubapincha://auth/callback` en el manifiesto y
  `MainActivity` lo entrega a `exchangeAuthCode` (PKCE, sin token en URL).
- **Google:** Play Services con `requestIdToken`.
- **FCM:** solo para push, separado del inicio de sesión.
- **Demo y cola offline:** conservados.

## Lo que se desvía de la guía (ordenado por importancia)

### 1. La release se firma con el keystore de debug — BLOQUEANTE
`app/build.gradle` no cambió: `release { signingConfig signingConfigs.debug }`
con `debug.keystore` (contraseñas `android`). No existe `signingConfig release`,
no se lee `local.properties` y no hay BuildConfig de firma. Una "release"
construida desde este ZIP sale firmada con debug. La guía pedía la firma de
producción (`cubapincha-release.jks`, alias `cubapincha`) desde
`local.properties`. El propio `BUILD_SETUP.md` del ZIP lo advierte: "No
distribuyas una release firmada con la clave debug incluida".

### 2. La clave anon y la URL no van fijas en BuildConfig — BLOQUEANTE para usarla
No hay `BuildConfig.SUPABASE_URL` ni `SUPABASE_ANON_KEY`. La URL sale de
`SessionManager.getApiUrl()` (con valor por defecto correcto) y la clave de
`getSupabaseApiKey()`, que **empieza vacía** y se pega en Perfil > Conexión.
Una instalación nueva arranca en modo demo y el login no funciona hasta pegar
la clave a mano. La guía pedía ambas fijas en BuildConfig, nunca editables
desde Perfil.

### 3. El Google Web Client ID tampoco va en BuildConfig
Sale de `SessionManager.getGoogleClientId()` (Perfil o `SecureDefaults`).
Sin él, `requestIdToken` no se configura y el inicio con Google no funciona
hasta pegarlo en la app.

### 4. `SecureDefaults.java` sigue presente y en uso
La guía pedía retirarlo entero. Sigue como respaldo de `firebaseApiKey`,
`fcmProjectId`, `fcmAppId`, `fcmSenderId` y `googleClientId`. El blob cifrado
antiguo (con la clave web de Firebase) sigue viajando en el APK.

### 5. `SessionManager` conserva claves viejas
Siguen `KEY_FIREBASE_API_KEY`, `KEY_FIREBASE_ID_TOKEN`,
`KEY_FIREBASE_REFRESH_TOKEN`, `KEY_API_URL`, `KEY_GOOGLE_CLIENT_ID` y
`KEY_PENDING_GOOGLE_ID_TOKEN`. La guía pedía retirarlas. (Las nuevas claves
de Supabase sí existen y se usan.)

### 6. Sin refresco proactivo del token
Solo hay refresco reactivo ante 401. La guía pedía refrescar antes de llamar
si el JWT caduca en menos de 5 minutos. Menor: el reactivo cubre el caso,
con una llamada fallida de por medio.

### 7. Falta `androidx.browser:browser`
La guía pedía la dependencia para el inicio con Google por navegador
(Custom Tabs). El flujo PKCE abre el navegador del sistema con Intent.
Menor.

### 8. Nadie ha compilado este código con Gradle hasta un APK
El informe de la otra IA lo reconoce: sin APK 2.10.0 verificado, Gradle
bloqueado en ARM64 por AAPT2 x86-64, solo `javac` con stubs temporales y
chequeos estáticos (14/14) + XML 157/157. En un PC x86-64 o Mac con Android
Studio debería compilar, pero está sin probar. Las pruebas T01–T20 y el
login real en teléfono siguen pendientes.

## Qué falta para compilarla

1. **PC con Android Studio** (x86-64 Windows/Linux o Mac), JDK 17, SDK API 34
   + build-tools 34.0.0. En el entorno ARM64 de la otra IA el build no corre.
2. **Corregir la firma** en `app/build.gradle`: añadir `signingConfig release`
   que lea `storeFile`, `storePassword`, `keyAlias` y `keyPassword` desde
   `local.properties` (guía §1.1–1.2). Sin esto, la APK sale firmada con debug.
3. **Claves:** o se mueven a BuildConfig (según la guía), o se pegan a mano en
   la app en Perfil > Conexión: clave anon de Supabase y Google Web Client ID.
   Sin la anon, la app arranca en demo y no entra.
4. **Compilar:** `./gradlew assembleRelease` (o Build > Generate Signed APK
   en Android Studio). Primera vez descarga dependencias (internet).
5. **Probar en el teléfono:** desinstalar la 2.9.2, instalar la 2.10.0, login
   por correo y por Google, y la matriz T01–T20 de la guía (§13).

## Puntuación

| Aspecto | Nota |
|---|---|
| Código Supabase (Auth + API + contrato) | 9/10 |
| Fidelidad a la guía | 7/10 |
| Seguridad (secretos, tokens, host fijado) | 9/10 |
| Listo para release | 4/10 (firma debug + claves manuales + sin build real) |
| **General** | **8/10** |

## Archivos revisados

- `app/build.gradle`, `build.gradle`, `settings.gradle`,
  `gradle/wrapper/gradle-wrapper.properties`, `app/src/main/AndroidManifest.xml`
- `data/SupabaseAuthRest.java`, `data/SupabaseApiClient.java`,
  `data/SessionManager.java`, `data/Repository.java`, `data/ApiClient.java`,
  `data/SecureDefaults.java`, `ui/LoginFragment.java`, `ui/ProfileFragment.java`,
  `ui/MainActivity.java`, `model/Job.java`
- `BUILD_REPORT.md`, `BUILD_SETUP.md`, `TEST_LOG.md`,
  `tools/verify_supabase_migration.py` (re-ejecutado: 14/14)
