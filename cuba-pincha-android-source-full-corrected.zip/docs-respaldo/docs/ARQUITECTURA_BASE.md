# CubaPincha — Base arquitectónica sólida (a partir de 2.10.0)

**Fecha:** 2026-11-21 · **Estado:** diseño, no código. Esta es la base que manda
para todas las versiones futuras. Si una versión nueva contradice algo de
aquí, se cambia este documento primero, con fecha y motivo, no en silencio.

**Decisiones que ya están tomadas y no se reabren sin el usuario:**
1. Backend único: Supabase (Postgres + Auth + Edge Functions + Storage).
   Apps Script y Sheets quedan como origen de datos histórico, no como
   backend vivo. Firebase Auth queda retirado como identidad.
2. Identidad: Supabase Auth. `public.usuarios.id = auth.users.id`.
3. Firma: keystore de producción `cubapincha-release.jks`, alias
   `cubapincha`, fuera del repo. La release nunca se firma con debug.

---

## 1. Principios (en este orden)

1. **La base de datos manda.** La lógica de negocio que protege datos
   vive en Postgres (RLS, constraints, funciones), no solo en la app.
   Si la app miente, la base dice que no.
2. **Nunca confiar en el cliente.** Todo lo que llega de la app se
   valida en el servidor: identidad, rol, estado, límites, fechas.
3. **Un solo camino para cada cosa.** Una forma de iniciar sesión,
   una forma de llamar al backend, un contrato de respuesta.
   Lo duplicado se borra, no se mantiene "por si acaso".
4. **Nada secreto en la app.** En el APK solo van la URL pública de
   Supabase y la clave `anon`. Todo lo demás (service_role, claves
   de Firebase, contraseñas) vive en el servidor o en el panel.
5. **Cada cambio deja rastro.** Migraciones numeradas, auditoría
   solo-inserción, versiones con changelog. Nada se edita a mano
   en producción sin una migración.
6. **Fallar cerrado.** Si falta un permiso, un token o una
   configuración, la operación se niega. Nunca se abre por defecto.

---

## 2. Estructura

```
cubapincha/
  app/                    Android nativo, Java, 2.10.0 en adelante
    data/                 SupabaseAuthRest, SupabaseApiClient,
                          SessionManager (solo tokens Supabase)
    ui/                   pantallas por rol (trabajador / empresa)
    build.gradle          versionCode/versionName, firma release
                          por local.properties, nunca hardcodeada
  supabase/
    migrations/           001_esquema.sql, 002_seguridad_y_funciones.sql,
                          003_limpieza.sql, ... (una por cambio, en orden)
    functions/api/        Edge Function, una sola: /functions/v1/api
    seed/                 datos de prueba, nunca datos reales
  docs/                   AUDITORIA_PROFUNDA.md, AUTH_SUPABASE.md,
                          SHEETS_ESTUDIO.md, PLAN.md, este archivo
  keystore/               FUERA del repo. .jks + contraseñas en
                          gestor de contraseñas, copia cifrada.
```

Reglas de estructura:
- El original 2.9.2 no se toca. Cada versión nueva es una copia
  con su número y su changelog.
- Una migración SQL nunca se reescribe después de aplicarse en
  staging; se hace otra migración que la corrige.
- La Edge Function es una sola entrada con `action`; no se crean
  funciones nuevas por cada pantalla.
- La web, cuando vuelva, usa la misma API y el mismo contrato
  que la app. No hay un segundo backend para la web.

---

## 3. Seguridad

### Identidad y sesiones
- Supabase Auth: correo/contraseña + Google OAuth (vía Supabase).
- JWT (1 h) en `Authorization: Bearer`, refresh token en
  `EncryptedSharedPreferences`. Nada de tokens en el cuerpo,
  nada de sesiones opacas propias, nada de IDs en URLs para
  decidir quién eres.
- Al cerrar sesión, se revocan los tokens. Al cambiar de
  versión, la sesión vieja se borra y se vuelve a entrar.
- Usuarios migrados: pre-verificados. Usuarios nuevos:
  correo verificado obligatorio.

### Base de datos
- RLS activo en las 20 tablas, sin excepción. Las políticas
  usan `auth.uid()` y el rol/estado de `public.usuarios`.
- `service_role` solo en la Edge Function, solo donde hace
  falta (matching, notificaciones, Storage firmado).
- Auditoría solo-inserción: nadie borra ni edita su rastro.
- Límites atómicos: `consumir_limite()` con bloqueo por
  (usuario, acción), 30/h, sin sobrepaso bajo concurrencia.
- Sin teléfonos ni CVs en vistas públicas (`v_ofertas_publicas`).
  CVs y logos en Storage privado, con URLs firmadas de corta
  duración.

### App y firma
- Release firmada con el keystore de producción. Debug solo
  para desarrollo, nunca para probar con usuarios ni publicar.
- `local.properties` para secretos de firma; ese archivo
  nunca va al repo.
- Sin claves, tokens ni URLs editables desde Perfil. La URL
  de la API y la clave `anon` son valores fijos de BuildConfig.

### Rate limiting y abuso
- Login y registro con límite por hash de correo (10/h y 5/h).
- Acciones de escritura con límite por usuario.
- Reportes con estados cerrados (`abierto`, `en_revision`,
  `resuelto`, `descartado`); nada de estados libres que el
  servidor tenga que adivinar.

---

## 4. Lógica (reglas que no cambian)

- **Roles:** trabajador y empresa, un usuario un rol. El rol se
  lee de `public.usuarios`, no de lo que diga la app.
- **Perfiles:** un perfil incompleto puede entrar, pero no
  publicar ni postular hasta completarlo. La app lo guía,
  no lo bloquea en la puerta.
- **Ofertas:** solo empresas activas publican. Una oferta
  tiene fecha de expiración; `expirar_ofertas()` la archiva.
  Nadie ve ofertas archivadas como si estuvieran vivas.
- **Postulaciones e interés:** un trabajador no puede
  postular a su propia oferta ni una empresa a la suya.
  `expresar_interes()` comprueba empresa activa y que no
  sea el dueño.
- **Matching:** vive en el servidor, con los criterios
  guardados en la base, no en la memoria de la app.
- **Notificaciones:** Realtime solo para avisar (nueva
  postulación, respuesta). El contenido real se lee por API.
- **Borrado:** nada se borra en duro de `usuarios`,
  `ofertas` o `postulaciones`. Se archiva, con motivo y fecha.
- **Datos de prueba:** solo en staging y con un marcador
  claro. La sesión de prueba `token-prueba-sesion-trabajadora-001`
  se revoca antes de cualquier uso real.

---

## 5. Diseño de producto (para que crezca sin romperse)

- **Primero móvil, después web.** La app es el producto;
  la web usa la misma API cuando vuelva.
- **Offline con gracia:** sin conexión, la app muestra lo
  último guardado y dice que está sin conexión. No inventa
  datos ni deja al usuario en una pantalla en blanco.
- **Paginación por cursor** en listados (ofertas, postulaciones),
  nunca "traer todo". Búsqueda con tsvector + trigram en Postgres.
- **Errores que se entienden:** el contrato `{ok, data, error,
  requestId}` se mantiene en todas las versiones. Un error
  nuevo no cambia el formato, solo el código.
- **Accesibilidad y Cuba real:** texto legible, botones
  grandes, funciona con conexión lenta. Nada que dependa de
  estar en un país o tienda concreta para funcionar.

---

## 6. Versiones futuras (cómo se hace una versión nueva)

1. Se abre una rama/copia con el número nuevo (2.11.0, 2.12.0…).
2. Se escribe qué cambia y qué no, en el changelog, antes de
   tocar código.
3. Cambios de base de datos: migración nueva, probada en local
   y en staging, nunca a mano en producción.
4. Cambios de identidad o de contrato: se avisa en la versión
   anterior y se mantiene compatibilidad una versión, luego
   se retira lo viejo.
5. Pruebas antes de dar el APK: contrato T01–T20 contra
   staging, login con correo y con Google, RLS (un usuario
   no ve lo de otro), y prueba en el teléfono real.
6. Release: firmado con producción, huellas registradas,
   APK con su changelog. El usuario lo prueba y confirma
   antes de publicar.

---

## 7. Qué queda por cerrar (no se olvida)

- Acceso a Supabase (token CLI o contraseña de base) para
  aplicar las migraciones en staging.
- Clave `anon` de Supabase para la app (pública, no es secreto).
- Huellas SHA-1/SHA-256 del keystore de producción registradas
  en Firebase y en Google Cloud OAuth.
- CSVs de "CubaPincha DB" (18 pestañas) para la carga real,
  con los 3 desajustes ya documentados resueltos.
- Migración de identidad por enlace mágico (no hay export
  de Firebase Auth).
- Completar las 28 acciones que faltan en la Edge Function.
