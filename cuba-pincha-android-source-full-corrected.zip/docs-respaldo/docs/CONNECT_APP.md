# CubaPincha — Cómo conectar la app a Supabase (para tu compilación)

**Fecha:** 2026-11-21 · **Proyecto:** cubapincha-staging, ref `ogimwehtnhegfoamiwzm`
**Estado en staging (verificado en el panel):** SQL 001 y 002 aplicados sin
errores, 20 tablas en `public` con 0 filas, vista `v_ofertas_publicas`,
bucket `archivos` privado creado. Edge Function **no** desplegada todavía.
Datos reales **no** cargados todavía. Google Auth **apagado** todavía.

---

## 1. Datos de conexión (copiar del panel, no inventar)

| Dato | Valor / dónde copiarlo |
|---|---|
| Project URL | `https://ogimwehtnhegfoamiwzm.supabase.co` |
| API base (PostgREST) | `https://ogimwehtnhegfoamiwzm.supabase.co/rest/v1/` |
| Clave anon | Settings › API Keys › View legacy API keys › `anon` / `public` › Copy. **No va en el chat ni en el repo público, solo en BuildConfig.** |
| Clave publicable | Settings › API Keys › clave `default` (publishable). Supabase dice que las claves legacy se retiran a principios de 2027: usa la publicable cuando la app lo soporte. |
| Edge Function | `https://ogimwehtnhegfoamiwzm.supabase.co/functions/v1/api` (cuando se despliegue; hoy no existe) |
| Región / plan | us-east-1, Free, NANO, Postgres 17.12 |

En la app, estos valores van **fijos en BuildConfig**, nunca editables
desde Perfil y nunca en `SecureDefaults` (ese archivo se borra en 2.10.0).

```java
// BuildConfig (ejemplo, valores fijos)
SUPABASE_URL = "https://ogimwehtnhegfoamiwzm.supabase.co"
SUPABASE_ANON_KEY = "<la que copies del panel>"
EDGE_FUNCTION_URL = "https://ogimwehtnhegfoamiwzm.supabase.co/functions/v1/api"
```

---

## 2. Cómo inicia sesión la app (2.10.0)

1. La app llama a Supabase Auth (GoTrue), no a Firebase:
   - Correo/contraseña: `POST /auth/v1/token?grant_type=password`
   - Registro: `POST /auth/v1/signup`
   - Google: Play Services → ID token de Google →
     `POST /auth/v1/token?grant_type=id_token {provider:"google"}`
   - Restablecer: `POST /auth/v1/recover`
   - Refresh: `POST /auth/v1/token?grant_type=refresh_token`
2. Supabase devuelve access token (JWT, 1 h) + refresh token.
   Se guardan en `EncryptedSharedPreferences`, nada más.
3. Cada llamada a la Edge Function lleva:
   `Authorization: Bearer <jwt>` y cuerpo `{action, ...campos}`.
   **Sin `accessToken` en el cuerpo, sin sesión opaca.**
4. Respuesta siempre: `{ok, data, error, requestId}`.
5. Al abrir la 2.10.0 por primera vez, la sesión vieja de Firebase
   se borra y se pide entrar de nuevo (contraseña nueva por enlace
   de restablecimiento, enlace mágico, o Google).

---

## 3. Qué hay en staging y qué falta antes de probar el login

**Ya está:**
- 20 tablas: acciones_sincronizacion, archivos, auditoria,
  candidatos_guardados, configuracion, contacto_preferencias,
  dispositivos_fcm, filtros_guardados, limites_uso, municipios,
  notificaciones, ofertas, ofertas_guardadas, perfiles_empresa,
  perfiles_trabajador, postulaciones, provincias, reportes,
  sesiones, usuarios. Todas con 0 filas.
- RLS en las 20, 22 políticas, funciones `expresar_interes`,
  `consumir_limite`, `expirar_ofertas`, `crear_sesion`,
  `revocar_sesion`, `limpiar_sesiones_expiradas`,
  `limpiar_limites_antiguos`.
- Bucket `archivos` privado, límite 50 MB, 0 políticas.
- Auth: solo Email activado, registro permitido, Confirm email ON.

**Falta (en este orden, no saltarse pasos):**
1. **Migración 003 — identidad.** El SQL aplicado todavía crea
   `usuarios.id` con `gen_random_uuid()`. Para que el RLS funcione
   con Supabase Auth hay que cambiarlo a
   `usuarios.id REFERENCES auth.users(id) ON DELETE CASCADE`
   y poner `ON UPDATE CASCADE` en las FK que apuntan a
   `usuarios(id)`. Sin esto, `auth.uid()` no coincide con ningún
   usuario y el acceso directo queda negado (fail-closed, a
   propósito). La Edge Function ya está escrita esperando este cambio.
2. **Desplegar la Edge Function** `api` (código en
   `work/edge-function-2.10.0/index.ts`, 34/34 acciones).
   Secretos por nombre (nunca en el chat): `SUPABASE_URL`,
   `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` (los pone
   Supabase), `ALLOWED_ORIGIN` (obligatorio), `FCM_SERVICE_ACCOUNT`
   (opcional, solo push), `CRON_SECRET` (opcional, resumen diario).
3. **Google Auth.** Hoy está DISABLED. Para activarlo: crear el
   cliente OAuth Android en Google Cloud con la huella SHA-1 de
   producción `0D:C9:E9:A4:2A:BB:12:17:69:9F:55:3F:98:DF:D1:96:DD:63:6D:C5`,
   registrar el callback
   `https://ogimwehtnhegfoamiwzm.supabase.co/auth/v1/callback`,
   y activar Google en Supabase › Auth › Providers.
4. **Cargar datos reales.** CSVs de "CubaPincha DB" (18 pestañas)
   con el script `migrar_sheets_a_supabase.py`, después de resolver
   los 3 desajustes documentados en `SHEETS_ESTUDIO.md` (9 columnas
   que faltan en `ofertas`, `contactPreference` en
   `perfiles_trabajador`, reporte con status `open` → `abierto`).
5. **Usuarios.** No hay export de Firebase Auth, así que la
   migración de identidad es por enlace mágico: cada usuario entra
   con su correo y pone contraseña nueva. Los 14 usuarios vivos
   no se pueden crear solo con la hoja (solo hay `email_hash`).
6. **pg_cron (panel):** `expirar-ofertas-cada-hora`,
   `purga-sesiones-03-30`, `purga-limites-03-35`. Ver 002.
7. **Probar:** contrato T01–T20 contra staging (ver README de la
   Edge Function), login con correo y con Google, y comprobar que
   un usuario no ve lo de otro.

---

## 4. Firma de la app para tu compilación

- Keystore de producción: `work/keystore/cubapincha-release.jks`,
  alias `cubapincha`, RSA 2048, válido hasta 2051-11-14.
- SHA-1: `0D:C9:E9:A4:2A:BB:12:17:69:9F:55:3F:98:DF:D1:96:DD:63:6D:C5`
- SHA-256: `BB:D8:06:1D:C0:FF:F0:19:FE:1B:3C:ED:7B:A0:60:EC:AF:74:9F:4B:FE:48:37:5F:47:F0:DD:2D:C8:2E:21:A0`
- Contraseñas: en `work/keystore/contrasenas.txt` (0600), cópialas
  a tu gestor de contraseñas. Nunca en el repo ni en el chat.
- En `app/build.gradle`, la firma `release` lee el almacén y las
  contraseñas desde `local.properties` (ver `keystore/README.md`).
  Desinstala la 2.9.2 firmada con debug antes de instalar la
  2.10.0 firmada con producción: no se puede actualizar encima.

---

## 5. Documentos que mandan (léelos en este orden)

1. `work/ARQUITECTURA_BASE.md` — principios y proceso de versiones.
2. `work/AUTH_SUPABASE.md` — diseño de Supabase Auth y migración de identidad.
3. `work/edge-function-2.10.0/README.md` — Edge Function, secretos y pruebas T01–T20.
4. `work/supabase/PLAN.md` — plan de migración y verificación.
5. `work/SHEETS_ESTUDIO.md` — datos vivos y desajustes antes de cargar CSVs.
6. `work/AUDITORIA_PROFUNDA.md` — auditoría de la 2.9.2.
