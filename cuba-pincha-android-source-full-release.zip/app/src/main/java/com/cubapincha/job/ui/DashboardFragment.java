package com.cubapincha.job.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.cubapincha.job.R;
import com.cubapincha.job.adapter.CandidateAdapter;
import com.cubapincha.job.data.JobFilter;
import com.cubapincha.job.data.Repository;
import com.cubapincha.job.data.SessionManager;
import com.cubapincha.job.model.Application;

import java.util.ArrayList;
import java.util.List;

/** Panel de la empresa: indicadores, atajos y candidatos recientes. */
public class DashboardFragment extends Fragment implements CandidateAdapter.Listener {
    private CandidateAdapter recentAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MainActivity activity = (MainActivity) requireActivity();
        SessionManager session = SessionManager.get(requireContext());
        TextView greeting = view.findViewById(R.id.greeting);
        greeting.setText(getString(R.string.hello_name, session.getDisplayName()));

        boolean pending = "pending_verification".equals(session.getStatus());
        view.findViewById(R.id.card_pending).setVisibility(pending ? View.VISIBLE : View.GONE);

        // Borradores guardados en el teléfono, pendientes de publicar.
        int drafts = Repository.get(requireContext()).draftCount();
        View cardDrafts = view.findViewById(R.id.card_drafts);
        cardDrafts.setVisibility(drafts > 0 ? View.VISIBLE : View.GONE);
        if (drafts > 0) {
            ((TextView) view.findViewById(R.id.drafts_text)).setText(
                    getString(R.string.pending_publish) + ": " + drafts
                            + (drafts == 1 ? " borrador" : " borradores") + " en tu teléfono.");
            cardDrafts.setOnClickListener(v -> activity.selectTab(R.id.nav_jobs));
        }

        RecyclerView recentList = view.findViewById(R.id.list_recent);
        recentList.setLayoutManager(new LinearLayoutManager(requireContext()));
        recentAdapter = new CandidateAdapter(this);
        recentList.setAdapter(recentAdapter);

        view.findViewById(R.id.btn_publish).setOnClickListener(v -> activity.openCreateJob(null));
        SwipeRefreshLayout refresh = view.findViewById(R.id.swipe_refresh);
        refresh.setOnRefreshListener(() -> { loadStats(view); refresh.setRefreshing(false); });

        loadStats(view);
    }

    private void loadStats(View view) {
        Repository repo = Repository.get(requireContext());
        TextView active = view.findViewById(R.id.stat_active);
        TextView interests = view.findViewById(R.id.stat_interests);
        TextView reviewing = view.findViewById(R.id.stat_reviewing);
        TextView interviews = view.findViewById(R.id.stat_interviews);

        JobFilter filter = new JobFilter();
        filter.status = "published";
        repo.getJobs(filter, null, result -> {
            if (isAdded() && result.ok && result.data != null) {
                active.setText(String.valueOf(result.data.total));
            }
        });
        repo.getApplications(null, result -> {
            if (!isAdded() || !result.ok || result.data == null) return;
            int inReview = 0, inInterview = 0;
            for (Application a : result.data) {
                if ("reviewing".equals(a.status)) inReview++;
                if ("interview".equals(a.status)) inInterview++;
            }
            interests.setText(String.valueOf(result.data.size()));
            reviewing.setText(String.valueOf(inReview));
            interviews.setText(String.valueOf(inInterview));
            List<Application> recent = new ArrayList<>(result.data.subList(0, Math.min(3, result.data.size())));
            recentAdapter.setItems(recent);
        });
        repo.getNotifications(true, result -> {
            if (!isAdded() || !result.ok || result.data == null) return;
            // La campanita y su insignia viven en la navegación inferior.
        });
    }

    @Override
    public void onCandidateClick(Application app) {
        ((MainActivity) requireActivity()).openCandidates(null);
    }

    @Override
    public void onStatusClick(Application app, String newStatus) {
        Repository.get(requireContext()).changeApplicationStatus(app.applicationId, newStatus, null, result -> {
            if (isAdded() && getView() != null) loadStats(getView());
        });
    }

    @Override
    public void onNoteClick(Application app) {
        ((MainActivity) requireActivity()).openCandidates(null);
    }

    @Override
    public void onSaveClick(Application app) {
        Repository.get(requireContext()).saveCandidate(app.workerId, app.applicationId, true, result -> {
        });
    }

    @Override
    public void onDeleteClick(Application app) {
        new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Eliminar candidatura")
                .setMessage("¿Quieres eliminar esta candidatura recibida? Esta acción no se puede deshacer.")
                .setPositiveButton(R.string.delete, (dialog, which) ->
                        Repository.get(requireContext()).deleteApplication(app.applicationId, result -> {
                            if (isAdded() && getView() != null && !result.ok) {
                                com.google.android.material.snackbar.Snackbar.make(getView(),
                                        result.friendlyMessage(), com.google.android.material.snackbar.Snackbar.LENGTH_LONG).show();
                            }
                        }))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    @Override
    public void onRateClick(Application app) {
        RatingUi.promptForApplication(this, app);
    }
}
