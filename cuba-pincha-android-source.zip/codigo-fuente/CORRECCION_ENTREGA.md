# CubaPincha 2.11.0 — entrega de corrección

## Corregido en esta fuente
- `RatingUi.promptForApplication`: elimina la comparación incorrecta entre `usuarios.id` y los IDs de perfil; decide el sentido según `worker`/`company`.
- `CONTRACT.md`: describe la API Supabase/Edge realmente incluida y documenta que `getRatings` y `rateApplication` faltan en el Edge Function adjunto.
- `TEST_LOG.md` y `BUILD_REPORT.md`: registran el cambio y las pruebas no ejecutadas.
- `app/build.gradle`: `checkReleaseBuilds` no está desactivado en esta fuente.

## Pendiente / no verificable aquí
- Backend: falta implementar/verificar `getRatings` y `rateApplication` en la Edge Function desplegada, y adjuntar/verificar la migración SQL de valoraciones. No se inventó el esquema ni se desplegó nada.
- Build: no hay Android SDK en este entorno; no se generó APK.
- Dispositivo: faltan instalación limpia, Google login, permiso Android 13+, push FCM, persistencia de token tras reinicio, sincronización offline y valoración de candidatura hired.
- Lint: no se pudo ejecutar; la configuración fuente no desactiva `checkReleaseBuilds`.
- Keystore: requiere corregir la entrada de `keyPassword` en el gestor de contraseñas del propietario.

## Para compilar localmente
1. Instalar Android SDK 34 y JDK 21.
2. Crear `local.properties` desde `local.properties.example` con la ruta SDK, `supabaseUrl`, `supabaseAnonKey` y `googleWebClientId`.
3. Ejecutar `./gradlew assembleDebug lintDebug`.
4. Configurar el keystore de producción y sus contraseñas fuera del repositorio antes de `./gradlew assembleRelease lintRelease`.
5. No distribuir hasta completar pruebas en teléfono real y validar Edge Function contra un registro de candidatura de prueba.

No incluir nunca `service_role` en Android. La contraseña privada de firma no se ha leído ni modificado.
