# CubaPincha — contrato Android ↔ Supabase Edge Function

**Fuente de verdad inspeccionada:** `backend/edge-function/index.ts` incluido en este paquete.
**API declarada por esa fuente:** `2.0.0-supabase`.
**Transporte:** Supabase Edge Function `api` (`/functions/v1/api`).
**Autenticación:** Supabase Auth JWT.

> Este documento describe el código de Edge Function que acompaña a esta entrega. No demuestra qué versión está desplegada remotamente. La fuente incluida NO contiene `getRatings` ni `rateApplication`; por tanto, no se debe afirmar que esas operaciones están disponibles en producción sin verificar el despliegue.

## 1. Envoltorio y transporte

La API devuelve siempre un objeto con esta forma:

```json
{ "ok": true, "data": {}, "error": null, "requestId": "..." }
```

En error:

```json
{ "ok": false, "data": null, "error": { "code": "ERROR_CODE", "message": "..." }, "requestId": "..." }
```

- `health` admite GET o POST y es público.
- Las acciones restantes usan POST con JSON.
- El JWT Supabase del usuario se envía en `Authorization: Bearer <jwt>`.
- `health`, `login` (stub de compatibilidad), `publicJob` y `listCatalogs` figuran como públicas en la fuente.
- Las acciones de escritura/lectura protegidas validan el contexto del usuario autenticado.
- El cliente Android usa `BuildConfig.EDGE_FUNCTION_URL`, derivada de `SUPABASE_URL + /functions/v1/api`.

## 2. Acciones presentes en la fuente suministrada

La tabla de despacho de `index.ts` incluye:

`health`, `login`, `logout`, `registerProfile`, `me`, `jobs`, `job`, `applications`, `notifications`, `listFilters`, `sync`, `contactOptions`, `publicJob`, `listCatalogs`, `updateProfile`, `createJob`, `publishJob`, `updateJob`, `changeJobStatus`, `archiveJob`, `deleteJob`, `expressInterest`, `sendReminder`, `changeApplicationStatus`, `saveJob`, `saveCandidate`, `saveFilter`, `deleteFilter`, `syncActions`, `contactEvent`, `registerDevice`, `unregisterDevice`, `markNotificationRead` y `report`.

La fuente declara `READ_ACTIONS`, `WRITE_ACTIONS` y `PUBLIC_ACTIONS`; el comportamiento efectivo se implementa en el despacho de acciones y sus manejadores.

## 3. Identidad y candidaturas

- `usuarios.id` representa la identidad del usuario autenticado.
- `workerId` y `companyId` de una candidatura son identificadores de perfiles, no identificadores de sesión.
- Por tanto, Android no debe comparar `SessionManager.getUserId()` con `Application.workerId` ni con `Application.companyId`.
- La lista `applications` debe estar filtrada y autorizada por el servidor; la app usa el rol de sesión (`worker`/`company`) para decidir qué contraparte mostrar y el servidor debe volver a autorizar cualquier escritura.

Estados de candidatura declarados en la fuente: `sent`, `reviewing`, `interview`, `hired`, `rejected`, `withdrawn`.

## 4. Valoraciones: bloqueo detectado

El cliente Android incluido invoca:
- `getRatings` mediante lectura pública con `userId`, `limit` y `cursor`.
- `rateApplication` mediante POST autenticado con `applicationId`, `stars` y `comment` opcional.

Sin embargo, ninguna de esas dos acciones aparece en:
- `READ_ACTIONS`,
- `WRITE_ACTIONS`,
- `PUBLIC_ACTIONS`, ni
- el `switch` de despacho de `backend/edge-function/index.ts`.

Tampoco se incluye en este ZIP la migración SQL `006_valoraciones.sql`. En consecuencia, la fuente entregada no permite verificar ni ejecutar el contrato de valoraciones extremo a extremo. No se debe desplegar una implementación especulativa sin confirmar el esquema real de tablas, columnas, claves foráneas, políticas RLS y reglas de autorización en Supabase.

**Contrato esperado por Android (cliente):**
- `getRatings`: `{ action: "getRatings", userId, limit, cursor }`.
- `rateApplication`: `{ action: "rateApplication", applicationId, stars, comment? }`, con JWT.
- La valoración solo debe aceptarse para una candidatura `hired`, por una de las dos partes de esa candidatura, con una valoración por autor/candidatura y estrellas de 1 a 5. Estas reglas deben imponerse en el servidor, no solo en la UI.

## 5. Errores que el cliente debe manejar

La fuente define `ApiError` con códigos como `AUTH_REQUIRED`, `FORBIDDEN_ROLE`, `VALIDATION_ERROR`, `NOT_FOUND`, `DUPLICATE`, `CONFLICT`, `RATE_LIMITED` e `INTERNAL_ERROR`. La respuesta conserva `requestId` para trazabilidad.

## 6. Secretos y seguridad

- `SUPABASE_SERVICE_ROLE_KEY` es secreto exclusivo del servidor y nunca debe incluirse en Android.
- La app solo debe contener la clave pública/anon de Supabase.
- No guardar tokens en texto plano ni enviarlos en URLs.
- No registrar JWT, claves privadas, contraseñas de keystore ni valores de service role en informes.

## 7. Estado de verificación

La inspección de este paquete es estática. No se hizo llamada remota, no se desplegó Edge Function, no se insertó ninguna valoración y no se verificó la versión actualmente desplegada. La validación en vivo requiere un entorno Supabase autorizado y una candidatura de prueba `hired`.
